"""
04b_graph_context_passing.py — Requirement: passing context between agents.

This is the actual apples-to-apples equivalent of CrewAI's
`Task(context=[extract_task])`: strands.multiagent.Graph wires nodes
(each backed by an Agent) with edges, and the graph's own executor
automatically builds each downstream node's input from its predecessors'
outputs — no manual string-stitching required, unlike 04_context_passing.py.

Confirmed straight from the Strands source (graph.py _build_node_input):
the graph feeds the reviewer node a prompt shaped like:

    Original Task: <the task text>

    Inputs from previous nodes:

    From extractor:
      - Agent: <extractor's full output>

Run:
    python 04b_graph_context_passing.py
"""
from strands import Agent
from strands.models import BedrockModel
from strands.multiagent import GraphBuilder

MODEL_ID = "anthropic.claude-3-5-sonnet-20241022-v2:0"
REGION = "us-east-1"
model = BedrockModel(model_id=MODEL_ID, region_name=REGION)

extractor = Agent(
    name="intake_extractor",
    description="Pulls structured facts out of raw practitioner notes.",
    system_prompt="You turn messy intake notes into clean, listed facts.",
    model=model,
)

reviewer = Agent(
    name="credentialing_reviewer",
    description="Flags missing or risky items from extracted practitioner facts.",
    system_prompt="You review extracted facts for completeness before approval.",
    model=model,
)

builder = GraphBuilder()
builder.add_node(extractor, "extractor")
builder.add_node(reviewer, "reviewer")
builder.add_edge("extractor", "reviewer")   # <- this edge IS the context wiring
builder.set_entry_point("extractor")
graph = builder.build()

if __name__ == "__main__":
    task = (
        "Extract the practitioner facts from this note as a bullet list, then "
        "review them for anything missing or risky for credentialing: "
        "'Dr. John Nake, MD, orthopaedic surgeon, TN license active until "
        "10/31/2026, NPI 5555180777, no board certification on file.'"
    )
    graph_result = graph(task)

    print("--- STATUS ---")
    print(graph_result.status, "| nodes completed:", [n.node_id for n in graph_result.completed_nodes])

    print("\n--- EXTRACTOR OUTPUT ---")
    print(graph_result.results["extractor"].result)

    print("\n--- REVIEWER OUTPUT (received extractor's output automatically) ---")
    print(graph_result.results["reviewer"].result)
