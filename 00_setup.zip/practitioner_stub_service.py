"""
practitioner_stub_service.py — a local stand-in for the real practitioner
HTTP service. Lets 01_http_tool.py (and any other example) run without
network access or hitting a public test API.

Zero extra dependencies — uses only the Python standard library.

Run:
    python practitioner_stub_service.py            # listens on port 8000
    python practitioner_stub_service.py 9000        # or a custom port

Try it directly in a browser or with curl while it's running:
    curl http://localhost:8000/practitioners/1
    curl http://localhost:8000/practitioners/999    # -> 404, not seeded
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PRACTITIONERS = {
    1: {
        "id": 1,
        "first_name": "John",
        "last_name": "Nake",
        "npi": "5555180777",
        "license_state": "TN",
        "license_status": "Active",
        "email": "john.nake@example-clinic.test",
    },
    2: {
        "id": 2,
        "first_name": "Priya",
        "last_name": "Rao",
        "npi": "1122334455",
        "license_state": "CA",
        "license_status": "Active",
        "email": "priya.rao@example-clinic.test",
    },
    3: {
        "id": 3,
        "first_name": "Miguel",
        "last_name": "Santos",
        "npi": "9988776655",
        "license_state": "NV",
        "license_status": "Expired",
        "email": "miguel.santos@example-clinic.test",
    },
}


class PractitionerHandler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        parts = self.path.strip("/").split("/")
        if len(parts) == 2 and parts[0] == "practitioners":
            try:
                practitioner_id = int(parts[1])
            except ValueError:
                practitioner_id = None
            record = PRACTITIONERS.get(practitioner_id)
            if record is not None:
                self._send_json(200, record)
                return
        self._send_json(404, {"error": f"No practitioner at {self.path}"})

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args) -> None:  # noqa: A002 - matches base signature
        print(f"[stub] {self.address_string()} - {format % args}")


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    server = ThreadingHTTPServer(("localhost", port), PractitionerHandler)
    print(f"Practitioner stub service running at http://localhost:{port}")
    print(f"Seeded IDs: {list(PRACTITIONERS.keys())}")
    print("Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()
