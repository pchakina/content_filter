"""
02_a2a_delegation.py — Requirement: agent-to-agent (A2A) communication.

Strands' native pattern: `agent.as_tool()` turns any Agent into a tool
another Agent can call. The manager calls the researcher exactly like any
other tool — Strands handles the request/response round-trip between the
two agents. `delegate=False` (the default) lets the manager keep
reasoning after getting the researcher's answer back.

Run:
    python 02_a2a_delegation.py
"""
from strands import Agent
from strands.models import BedrockModel

MODEL_ID = "anthropic.claude-3-5-sonnet-20241022-v2:0"
REGION = "us-east-1"
model = BedrockModel(model_id=MODEL_ID, region_name=REGION)

researcher = Agent(
    name="credentialing_researcher",
    description="Researches medical licensing requirements by state. Give it a state name.",
    system_prompt="You are meticulous about state medical licensing rules.",
    model=model,
)

manager = Agent(
    name="credentialing_manager",
    description="Produces final, checked answers for the credentialing team.",
    system_prompt=(
        "You coordinate specialists. For research-heavy questions, call the "
        "credentialing_researcher tool instead of answering from memory."
    ),
    tools=[researcher.as_tool()],   # <- this IS the A2A wiring
    model=model,
)

if __name__ == "__main__":
    result = manager(
        "Determine what is generally required for a physician to hold an "
        "active medical license in Tennessee. Delegate the research, then "
        "confirm and summarize the answer in 3 bullet points."
    )
    print("\n--- RESULT ---")
    print(result)
