"""
05a_mcp_server.py — a minimal MCP server exposing one tool.

This stands in for a real practitioner-service MCP server. It's launched
automatically by 05b_mcp_client_agent.py over stdio — you don't run this
file directly.
"""
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("practitioner-lookup")


@mcp.tool()
def get_practitioner_status(practitioner_id: str) -> str:
    """Return the credentialing status for a practitioner ID."""
    return f"Practitioner {practitioner_id} status: ACTIVE, license current."


if __name__ == "__main__":
    mcp.run()   # stdio transport by default
