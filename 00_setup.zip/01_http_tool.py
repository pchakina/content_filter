"""
01_http_tool.py — Requirement: agents call existing HTTP services.

A @tool-decorated function wraps a REST call. Swap PRACTITIONER_API_URL
for your real practitioner service. Model: Amazon Bedrock (Anthropic Claude).

This points at a LOCAL stub service instead of a public test API, so the
demo has no external network dependency — deterministic, works offline,
and doesn't send anything outside your machine.

Setup:
    pip install strands-agents boto3 requests
    (configure AWS credentials — see 00_setup.py)

Run (two terminals):
    Terminal 1:  python practitioner_stub_service.py
    Terminal 2:  python 01_http_tool.py
"""
import requests
from strands import Agent, tool
from strands.models import BedrockModel

MODEL_ID = "anthropic.claude-3-5-sonnet-20241022-v2:0"
REGION = "us-east-1"
PRACTITIONER_API_URL = "http://localhost:8000/practitioners/{id}"


@tool
def get_practitioner_record(practitioner_id: int) -> str:
    """Fetch a practitioner's record by ID from the practitioner HTTP service."""
    response = requests.get(PRACTITIONER_API_URL.format(id=practitioner_id), timeout=10)
    response.raise_for_status()
    return response.json()


model = BedrockModel(model_id=MODEL_ID, region_name=REGION)

lookup_agent = Agent(
    name="lookup_agent",
    description="Looks up practitioner details using the practitioner service",
    system_prompt="You retrieve and summarize practitioner records for credentialing staff.",
    tools=[get_practitioner_record],
    model=model,
)

if __name__ == "__main__":
    result = lookup_agent("Fetch practitioner #3 and summarize their name and contact email in one sentence.")
    print("\n--- RESULT ---")
    print(result)
