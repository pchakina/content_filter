"""
03_context_memory.py — Requirement: agents with context management.

A Strands Agent keeps its own message history across calls on the same
object — that IS its short-term memory, no vector DB required. The
`conversation_manager` controls what happens as that history grows:
SlidingWindowConversationManager keeps the most recent N messages in
context (with older ones truncated/summarized) instead of growing forever.

Unlike some frameworks, this has no hidden dependency on a third-party
embedding API — it's pure in-process message-history management.

Run:
    python 03_context_memory.py
"""
from strands import Agent
from strands.agent.conversation_manager import SlidingWindowConversationManager
from strands.models import BedrockModel

MODEL_ID = "anthropic.claude-3-5-sonnet-20241022-v2:0"
REGION = "us-east-1"
model = BedrockModel(model_id=MODEL_ID, region_name=REGION)

assistant = Agent(
    name="credentialing_assistant",
    description="Tracks details about the practitioner being onboarded.",
    system_prompt="You track details about the practitioner you're helping onboard.",
    model=model,
    conversation_manager=SlidingWindowConversationManager(window_size=40),
)

if __name__ == "__main__":
    first = assistant("Remember this fact: Dr. Jane Doe's NPI number is 1234567890.")
    print("--- CONFIRMATION ---")
    print(first)

    second = assistant("What is Dr. Jane Doe's NPI number? Answer from memory only.")
    print("\n--- RECALL ---")
    print(second)
