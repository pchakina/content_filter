"""
05b_mcp_client_agent.py — Requirement: MCP integration.

Strands has a native MCP client (strands.tools.mcp.MCPClient) — no
extra adapter package needed (unlike CrewAI, which needs "mcpadapt").
It launches the MCP server (05a_mcp_server.py) over stdio, discovers its
tools, and hands them to a Strands Agent as regular tools.

Run:
    python 05b_mcp_client_agent.py
"""
import sys
from pathlib import Path

from mcp import StdioServerParameters
from mcp.client.stdio import stdio_client
from strands import Agent
from strands.models import BedrockModel
from strands.tools.mcp import MCPClient

MODEL_ID = "anthropic.claude-3-5-sonnet-20241022-v2:0"
REGION = "us-east-1"
SERVER_SCRIPT = str(Path(__file__).parent / "05a_mcp_server.py")

model = BedrockModel(model_id=MODEL_ID, region_name=REGION)

mcp_client = MCPClient(
    lambda: stdio_client(StdioServerParameters(command=sys.executable, args=[SERVER_SCRIPT]))
)

with mcp_client:
    tools = mcp_client.list_tools_sync()
    print(f"Discovered MCP tools: {[t.tool_name for t in tools]}")

    agent = Agent(
        name="credentialing_status_checker",
        description="Checks practitioner credentialing status via the MCP server.",
        system_prompt="You use the practitioner-lookup MCP service to check status.",
        tools=tools,
        model=model,
    )

    if __name__ == "__main__":
        result = agent("Check the credentialing status of practitioner ID 10810155 and report it in one sentence.")
        print("\n--- RESULT ---")
        print(result)
