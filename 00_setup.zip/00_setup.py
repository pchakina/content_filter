"""
00_setup.py — run this first to confirm your environment is wired up.

Strands Agents is AWS's own open-source agent SDK. Working against Bedrock
uses standard AWS credential resolution (the usual boto3 chain) — there is
no separate "STRANDS_API_KEY"; if you can already call Bedrock with boto3,
Strands can too.

Setup (one time):
    python -m venv .venv
    .venv\\Scripts\\activate          (Windows)
    pip install strands-agents strands-agents-tools mcp boto3 requests

Credentials — any ONE of:
    setx AWS_ACCESS_KEY_ID "..."
    setx AWS_SECRET_ACCESS_KEY "..."
    setx AWS_DEFAULT_REGION "us-east-1"
  or an AWS_PROFILE, or an IAM role if running on EC2/Lambda/ECS.

Model access: in the Bedrock console, request access to the Anthropic
model(s) you plan to use in your target region before running these
examples — Bedrock model access is opt-in per account/region.

Verified against strands-agents 1.54.0.
"""
import boto3

MODEL_ID = "anthropic.claude-3-5-sonnet-20241022-v2:0"
REGION = "us-east-1"

try:
    identity = boto3.client("sts", region_name=REGION).get_caller_identity()
    print(f"AWS credentials OK — account {identity['Account']}")
except Exception as exc:  # noqa: BLE001 — this is a diagnostic script
    raise SystemExit(f"AWS credentials not configured: {exc}")

print(f"Examples will use Bedrock model: {MODEL_ID} in {REGION}")
