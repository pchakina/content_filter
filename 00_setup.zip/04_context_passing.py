"""
04_context_passing.py — Requirement: passing context between agents.

Strands has no automatic "task graph" wiring context between agents for
you (that's what the Graph/Workflow multiagent constructs are for on more
complex pipelines) — for a simple two-step handoff, you just capture one
agent's AgentResult and pass its text into the next agent's prompt. This
is the explicit, code-first equivalent of CrewAI's `Task(context=[...])`.

Run:
    python 04_context_passing.py
"""
from strands import Agent
from strands.models import BedrockModel

MODEL_ID = "anthropic.claude-3-5-sonnet-20241022-v2:0"
REGION = "us-east-1"
model = BedrockModel(model_id=MODEL_ID, region_name=REGION)

extractor = Agent(
    name="intake_extractor",
    description="Pulls structured facts out of raw practitioner notes.",
    system_prompt="You turn messy intake notes into clean, listed facts.",
    model=model,
)

reviewer = Agent(
    name="credentialing_reviewer",
    description="Flags missing or risky items from extracted practitioner facts.",
    system_prompt="You review extracted facts for completeness before approval.",
    model=model,
)

if __name__ == "__main__":
    extracted = extractor(
        "Extract the practitioner facts from this note as a bullet list: "
        "'Dr. John Nake, MD, orthopaedic surgeon, TN license active until "
        "10/31/2026, NPI 5555180777, no board certification on file.'"
    )
    print("--- EXTRACTED ---")
    print(extracted)

    # explicit context hand-off: extractor's output becomes part of reviewer's prompt
    review = reviewer(
        f"Review the extracted facts and flag anything missing or risky for "
        f"credentialing:\n\n{extracted}"
    )
    print("\n--- REVIEW ---")
    print(review)
