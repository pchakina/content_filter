# poc-strands

A Strands Agents + AWS Bedrock port of **Pattern 2 (A2A)** from `../poc`. This
is a sibling project, not a modification of `../poc` -- nothing in `../poc`
was touched. **Fully self-contained**: `spayer-backend/` and `mcp/` are copied
in (not referenced from `../poc`), so this directory can run standalone.

## What's ported vs. copied vs. not-yet-ported

| Piece | Status |
|---|---|
| `spayer-backend/` (Provider REST API) | **Copied in, self-contained**, with three real bugs fixed (see "Bugs found and fixed" below). No Strands/Bedrock code lives here -- it's the same plain FastAPI + pyodbc/SQLAlchemy data layer as `../poc`, just no longer a cross-project dependency. |
| `mcp/` (REST tool proxy + NL2SQL schemas/prompts) | **Copied in, self-contained**, with encoding damage and one truncated JSON file fixed (see below). Still has the same functional gap as `../poc`: the `query_provider_database` tool's implementation (`nl2sql/tool.py`) was never committed to either repo, so that one tool 404s at call time -- everything else works. |
| `a2a/contract.py` | **Ported**, re-saved as clean UTF-8 (the `poc/` copy is cp1252-damaged and fails `py_compile`). No behavior change. |
| `agents/prompts.py` | **Ported**, re-saved as clean UTF-8 (the `poc/` copy is UTF-16 and fails `py_compile`). No text change. |
| `agents/_internal/mcp_tools.py` | **New** -- dynamic Strands tool loader bridging the custom REST "MCP" shape (see caveat below). |
| `agents/_internal/agent_runtime.py` | **Ported to Strands** -- `Agent(tools=..., model=BedrockModel(...))` replaces the hand-wired LangGraph `StateGraph`/`ToolNode`/`MemorySaver`. |
| `agents/practitioner/`, `agents/practice/`, `agents/facility/` | **Ported** -- all three specialist agents, same `create_agent_app()` runtime, each with its own manifest + system prompt + `extract_context_updates()`. |
| `agents/nl2sql/`, `agents/synthesis/` | **Not yet ported.** Both deliberately don't need an agentic loop at all (see the original POC's own design notes, and the chat history that led to this port) -- port them as plain FastAPI handlers, not `Agent` objects. |
| `master/orchestrator.py` | **Ported** -- same routing LLM, same sticky-follow-up guard, same nl2sql-explicit guard, same `SessionStore`. Registry lookup replaced by a static `AGENT_URLS` dict (env-configured). One deliberate fix: `context_updates` from an agent are now filtered to known `SessionContext` fields before being applied (the original's blind `setattr` could crash a session permanently on an unexpected key -- see review notes). |
| `master/web_ui.py` | **Ported** -- same Gradio UI. One deliberate fix: the logo SVG load is now optional (the original crashes on startup in `../poc` too, since the referenced file doesn't exist there either). |
| `registry/` | **Dropped by design** -- static env-configured URLs replace it (see `.env.example`). |

## Why this differs from a "real" A2A migration

Two decisions were made explicitly before writing any code:
1. **Keep the existing custom A2A REST contract** (`a2a/contract.py`, header-based `SessionContext` propagation) rather than migrating to Strands' native `A2AServer`/`A2AClientToolProvider` (the real Google/Linux-Foundation A2A protocol -- JSON-RPC, Agent Cards). That's a bigger, separate migration if you want it later; nothing here blocks it.
2. **No capability-search registry.** Agent discovery is a static dict of URLs from env vars (`master/orchestrator.py:AGENT_URLS`), not a lookup service.

## The MCP caveat (read before relying on `query_provider_database`)

`mcp/server_http.py` exposes `GET /mcp/v1/tools` / `POST /mcp/v1/tools/call`
-- a **custom REST shape**, not the real Model Context Protocol (JSON-RPC 2.0).
Strands' own `strands.tools.mcp.MCPClient` expects the real protocol, so it
can't point at this server directly. `agents/_internal/mcp_tools.py` is the
bridge: it fetches that REST catalogue and generates real Strands tools from
it (see that file's docstring for why it uses `exec()` rather than an
internal Strands class). If `mcp/server_http.py` is ever upgraded to a
genuine MCP transport, swap `mcp_tools.py` for `strands.tools.mcp.MCPClient`
and nothing else changes.

## Bugs found and fixed while copying spayer-backend/ and mcp/ in

These all pre-exist in `../poc` too (confirmed by diffing against the
original before fixing) -- none of this was introduced by the port. Fixed
here since the point of copying these in was to have something that actually
runs.

1. **`spayer-backend/main.py:4` and all three `routes/*.py` files** import
   `from errors import (...)`, but the module on disk is `error.py` (no "s").
   All four occurrences import `ModuleNotFoundError` as committed in `../poc`.
   Fixed: changed to `from error import ...` everywhere.
2. **Encoding corruption**, same cp1252/UTF-16 damage pattern as `adk/`/`master/`
   in `../poc` (see earlier review), also present in the backend/MCP layer:
   `spayer-backend/database.py`, `mcp/n2sql/prompts/{facility,practice,practitioner}_prompt.py`,
   and `mcp/n2sql/schemas/{facility,practice}_domain.json` all failed
   `py_compile`/`json.load` with `SyntaxError: Non-UTF-8 code` or
   `UnicodeDecodeError`. Fixed: re-encoded each to clean UTF-8, verified by
   re-running `py_compile`/`json.load` and spot-checking that the special
   character in each is genuinely U+2014 (em dash), not further mangled.
3. **`mcp/n2sql/schemas/reference_schema.json` is truncated** in `../poc` --
   confirmed via brace-counting (482 `{` vs 481 `}`, brackets balanced) that
   exactly one closing `}` for the top-level object is missing, consistent
   with a generation script that got cut off. Fixed: appended the missing
   `}`; the file now parses and contains all 42 reference tables including
   the last one (`PracticeTypes`), which was previously unparseable.

Everything above was re-verified end-to-end after fixing: every `.py` file
passes `py_compile`, every `.json` file parses, and `spayer-backend/main.py`
plus `mcp/server_http.py` were both actually imported (with `fastapi`/
`sqlalchemy`/`requests` stubbed, since this session has neither installed) to
confirm the full route-registration and tool-registry wiring resolves with no
remaining import errors.

## Running the full stack end-to-end

```bash
pip install -r requirements.txt
cp .env.example .env   # edit as needed, then export/source it

# 1. Data layer (now self-contained, no ../poc dependency)
cd spayer-backend && pip install -r requirements.txt && uvicorn main:app --port 8000 --app-dir . &
cd ../mcp && pip install -r requirements.txt && python server_http.py &   # :8080

# 2. Specialist agents
cd ..
uvicorn agents.practitioner.main:app --port 8001 --app-dir . &
uvicorn agents.practice.main:app     --port 8003 --app-dir . &
uvicorn agents.facility.main:app     --port 8004 --app-dir . &

# 3. Master orchestrator UI
python -m master.web_ui   # :7860
```

Practitioner, Practice, and Facility queries (including follow-ups like
"their specialties" or "does this practice have duplicate billing locations")
will route correctly and hit real Bedrock-backed Strands agents. NL2SQL
queries ("how many practitioners across all states") will get "No agent
available" until that service is ported. The Synthesis Agent isn't ported
yet either -- `orchestrator.chat()` degrades gracefully to the specialist's
raw summary text if the synthesis call fails (same fallback behavior as the
original), so all three specialist slices still work without it, just
without the nice markdown tables.

## Verified before delivery

Nothing here was run against a live Bedrock endpoint (no credentials in this
session), but the logic that doesn't require one was:
- `agents/_internal/mcp_tools.py`: the dynamic tool-generation code path was
  smoke-tested directly (stubbing only `strands`/`requests`) -- confirmed it
  builds a correctly-named, correctly-typed, correctly-documented tool
  function that calls the MCP endpoint with the right arguments and records
  `{tool, arguments, data, duration_ms}`, including the optional-parameter and
  zero-parameter edge cases.
- `master/orchestrator.py`: the sticky-follow-up guard, the nl2sql-explicit
  guard, the clarify short-circuit, and the `context_updates` field-filtering
  fix were all exercised directly (stubbing `strands`/`boto3`/`httpx`) against
  six scenarios, including a regression test proving the original's
  session-corruption bug (unknown `context_updates` key -> crash on next
  turn) does not reproduce here.
- Every file passes `py_compile`.
- `agents/practice/main.py` and `agents/facility/main.py`: imported directly
  (stubbing only `strands`/`requests`/`httpx`) and their `extract_context_updates()`
  functions verified to correctly pull `PracticeID`/`FacilityID` out of tool
  results and ignore malformed/irrelevant data.

Also worth knowing: the original `poc/agents/facility/main.py` reads
`"manifest.json"`, but the file actually committed there is misspelled
`maifest.json` -- that service crashes with `FileNotFoundError` on startup in
`poc/` as it stands today. Fixed here (this port's file is correctly spelled).

Not verified (would need real credentials/services): an actual Bedrock model
call, an actual run against `../poc/mcp/server_http.py`, or Gradio actually
rendering.
