# certs/

Drop your corporate root CA certificate here (for example `combined.pem`) if you
build behind a TLS-inspecting proxy. Every Dockerfile copies this folder into
the image and runs `update-ca-certificates`; `.pem` files are renamed to `.crt`
automatically.

Leave it empty if you don't need it. The build works either way.

Certificate files here are git-ignored.
