# poc-strands-docker

The Pattern 2 (A2A) multi-agent system from `../poc`, rebuilt on **Strands Agents + AWS Bedrock** and packaged as **8 containers** you start with one command.

It is `../poc-strands` plus:
- the two agents that folder was missing (**NL2SQL** and **Synthesis**), so the full A2A stack is present
- a Dockerfile per service and a `docker-compose.yml` that wires them together

`../poc` and `../poc-strands` are separate folders and don't depend on this one.

## Quick start

Prerequisites: Docker Desktop, a reachable MS-SQL database, and AWS credentials with Bedrock access in the region you set.

```bash
cd poc-strands-docker
cp .env.example .env        # fill in DB_* and AWS settings (see comments inside)
docker compose up --build
```

Open **http://localhost:7860** and ask *"Can you find the provider with the name James Fenton?"*, then a follow-up like *"Can I get their speciality and license information?"*

Behind a corporate TLS-inspecting proxy? Put your root CA (e.g. `combined.pem`) in `certs/` before building. See `certs/README.md`.

## The containers

```mermaid
flowchart TB
    User(["Browser :7860"]) --> Master

    subgraph Front["front door"]
        Master["master :7860<br/>Gradio UI + orchestrator"]
    end

    subgraph Agents["specialist agents"]
        Prac["practitioner-agent :8001"]
        NL2["nl2sql-agent :8002"]
        Pra["practice-agent :8003"]
        Fac["facility-agent :8004"]
        Syn["synthesis-agent :8005"]
    end

    subgraph Data["data layer"]
        MCP["mcp :8080<br/>tool proxy"]
        API["spayer-backend :8000<br/>REST API + ODBC 18"]
    end

    DB[("MS-SQL")]
    Bedrock{{"AWS Bedrock"}}

    Master -->|"route by entity"| Prac & Pra & Fac & NL2
    Master -->|"format results"| Syn
    Prac & Pra & Fac & NL2 --> MCP
    MCP --> API --> DB
    Master -.-> Bedrock
    Prac & Pra & Fac -.-> Bedrock
    Syn -.->|"non-JSON fallback only"| Bedrock
```

| Service | Port | Image built from | Uses Bedrock | Starts after |
|---|---|---|---|---|
| `spayer-backend` | 8000 | `spayer-backend/Dockerfile` | no | — |
| `mcp` | 8080 | `mcp/Dockerfile` | no | backend healthy |
| `practitioner-agent` | 8001 | `agents/practitioner/Dockerfile` | yes | mcp healthy |
| `nl2sql-agent` | 8002 | `agents/nl2sql/Dockerfile` | no | mcp healthy |
| `practice-agent` | 8003 | `agents/practice/Dockerfile` | yes | mcp healthy |
| `facility-agent` | 8004 | `agents/facility/Dockerfile` | yes | mcp healthy |
| `synthesis-agent` | 8005 | `agents/synthesis/Dockerfile` | fallback only | — |
| `master` | 7860 | `master/Dockerfile` | yes (routing) | all agents healthy |

The order matters: the three LLM agents download their tool list from `mcp` when they start, so compose waits for `mcp`'s healthcheck first. There's no registry container. The master finds agents by the service names set in `docker-compose.yml`.

## Useful commands

```bash
docker compose up --build -d              # run in background
docker compose ps                         # health of every container
docker compose logs -f practitioner-agent # follow one agent's logs
docker compose up --build practice-agent  # rebuild/restart just one agent
docker compose down                       # stop everything
```

Call an agent directly, bypassing the master:

```bash
curl http://localhost:8001/health
curl -X POST http://localhost:8001/a2a/task -H "Content-Type: application/json" -d "{\"prompt\": \"find practitioner James Fenton\"}"
```

## Differences from `../poc`'s Dockerfiles

| `../poc` | here |
|---|---|
| `combined.pem` must exist or every build fails | `certs/` is optional; drop the cert in only if you need it |
| `python:3.11-slim` (now Debian 13) with Microsoft's Debian 12 ODBC repo | pinned `python:3.11-slim-bookworm` so the repo matches |
| ODBC install turns off TLS verification (`Verify-Peer false`, `curl -k`) | normal verified install |
| botocore (Bedrock) doesn't trust the corporate cert | `AWS_CA_BUNDLE` set alongside `REQUESTS_CA_BUNDLE` / `SSL_CERT_FILE` |
| `spayer-backend/Docker`, `master/Dockerfile.txt` | all named `Dockerfile` |
| master image copies a logo file that doesn't exist | logo is optional |
| registry container | removed; the master uses static service URLs |
| no compose file | `docker-compose.yml` with healthchecks and startup order |

## Known limitations

- **`query_provider_database` doesn't work yet.** Its implementation (`mcp/n2sql/tool.py`) was never committed to `../poc`. Questions routed to the NL2SQL agent return an error, and specialist agents that fall back to that tool get an error for that call. Everything backed by the REST API works.
- **Model IDs**: `.env.example` uses the IDs from `../poc` (`mistral.ministral-3-14b-instruct`). If your account uses different Bedrock IDs or inference profiles, change `BEDROCK_DEFAULT_MODEL`.
- **AWS SSO**: `~/.aws` is mounted read-only. Run `aws sso login` on the host before starting; containers can't refresh an expired SSO token.
- **Sessions are in-memory** unless you set `SESSION_TABLE` to a DynamoDB table, so restarting `master` forgets conversations.

## What was verified before handover

Docker isn't installed on the machine this was built on, so **no image has been built or run yet**. Checked instead, using the real `strands-agents` 1.56.0, FastAPI and `gradio==6.11.0` packages, with Bedrock and the database faked:

- A specialist agent served its real FastAPI endpoints and ran a full Strands tool-calling loop: model → MCP tool call → `tool_results` + `context_updates` in the A2A response. The `a2a-practitioner-id` header reached the model's prompt.
- All 33 tools in the real `spayer-tools-registry.json` convert to valid Strands tools for each agent that uses them. This check found and fixed a bug: a required parameter after an optional one generated invalid Python. The same fix went into `../poc-strands`.
- Synthesis builds tables in code for JSON results and falls back to a Strands agent for other text. NL2SQL calls its tool directly.
- The master's Gradio UI starts and serves the page on Gradio 6.11.0.
- `docker-compose.yml` matches the Dockerfiles on disk: every Dockerfile path and `COPY` source exists, ports match `EXPOSE` and the healthchecks, every `depends_on` target has a healthcheck, and every URL the master uses points to a real service and port.

The first real `docker compose up` is still the test for the parts that couldn't be checked here: the ODBC driver install, your cert, your DB connection and real Bedrock calls.
