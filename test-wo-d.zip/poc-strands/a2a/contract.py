"""A2A Protocol Contract -- shared models only.

Ported byte-for-byte (just re-saved as clean UTF-8 -- the poc/ copy of this file
is corrupted with cp1252 em-dashes and fails py_compile) from poc/a2a/contract.py.
This is the contract every A2A agent in poc-strands implements. No behavior
changes vs the original POC.
"""
import uuid
from dataclasses import dataclass
from typing import Optional

from pydantic import BaseModel, Field


@dataclass
class SessionContext:
    """Mutable context passed between agents via HTTP headers."""
    context_id: str
    session_id: str
    user_id: str = "anonymous"
    # Discovered entity IDs -- agents update these as they find data
    practitioner_id: Optional[str] = None
    practice_id: Optional[str] = None
    facility_id: Optional[str] = None

    def to_headers(self) -> dict[str, str]:
        return {
            "a2a-context-id": self.context_id,
            "a2a-session-id": self.session_id,
            "a2a-user-id": self.user_id,
            "a2a-practitioner-id": self.practitioner_id or "",
            "a2a-practice-id": self.practice_id or "",
            "a2a-facility-id": self.facility_id or "",
        }

    @classmethod
    def from_headers(cls, headers: dict) -> "SessionContext":
        return cls(
            context_id=headers.get("a2a-context-id") or str(uuid.uuid4()),
            session_id=headers.get("a2a-session-id") or str(uuid.uuid4()),
            user_id=headers.get("a2a-user-id", "anonymous"),
            practitioner_id=headers.get("a2a-practitioner-id") or None,
            practice_id=headers.get("a2a-practice-id") or None,
            facility_id=headers.get("a2a-facility-id") or None,
        )

    @classmethod
    def new(cls) -> "SessionContext":
        return cls(context_id=str(uuid.uuid4()), session_id=str(uuid.uuid4()))


class ToolResult(BaseModel):
    """Raw result from a single tool call. Agents MUST populate this for multi-tool responses."""
    tool: str           # tool name
    data: str           # raw JSON string returned by the tool
    status: str = "ok"  # "ok" | "error"
    arguments: dict = Field(default_factory=dict)  # tool call arguments
    duration_ms: int = 0  # tool execution time


class A2ATaskRequest(BaseModel):
    task_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    prompt: str
    context_snapshot: dict = Field(default_factory=dict)


class A2ATaskResponse(BaseModel):
    task_id: str
    status: str  # "completed" | "failed"
    result: Optional[dict] = None        # agent summary text (optional, for simple single-result agents)
    tool_results: list[ToolResult] = Field(default_factory=list)  # per-tool raw results -- REQUIRED for multi-tool agents
    context_updates: dict = Field(default_factory=dict)
    error: Optional[str] = None
    metadata: dict = Field(default_factory=dict)
