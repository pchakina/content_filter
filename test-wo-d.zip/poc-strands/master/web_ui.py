"""Gradio web front-end for the Strands-ported Master Orchestrator. Same UI/UX
as poc/master/web_ui.py (status-streaming chat, sticky session state), with one
fix: the original unconditionally `open()`s ../adk/healthspring_logo_dark.svg,
which doesn't exist in poc/ either -- both versions currently crash on startup
before Gradio even launches. Here the logo is optional: set LOGO_SVG_PATH to a
real file if you have one, otherwise it just renders the title text.

Run with (from poc-strands/ root):
    python -m master.web_ui
"""
import logging
import os
import re
import threading
import time
import uuid

import gradio as gr

from master.orchestrator import MasterOrchestrator

theme = gr.themes.Base(
    primary_hue=gr.themes.Color(c50="#f5eaf8", c100="#ecd4f0", c200="#e2bfe9", c300="#d8a9e1",
                                 c400="#cf94da", c500="#9E28B5", c600="#8a23a0", c700="#761e8b",
                                 c800="#621976", c900="#4e1461", c950="#3a0f4c"),
    secondary_hue=gr.themes.Color(c50="#e9e8ed", c100="#d2d0da", c200="#bcb9c8", c300="#a5a2b5",
                                   c400="#8f8ba3", c500="#797391", c600="#625c7e", c700="#4c456c",
                                   c800="#352d59", c900="#1f1647", c950="#1f1647"),
    neutral_hue=gr.themes.Color(c50="#f4eff4", c100="#e6e1e6", c200="#c9c5ca", c300="#aeaaaf",
                                 c400="#939094", c500="#79767b", c600="#605d62", c700="#48464a",
                                 c800="#313034", c900="#1c1b1f", c950="#0f0e11"),
    font=["Open Sans", "sans-serif"],
    font_mono=["monospace"],
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

orchestrator = MasterOrchestrator()


def add_user_message(message, history, session_id):
    if not session_id:
        session_id = str(uuid.uuid4())
    history.append({"role": "user", "content": message})
    return "", history, session_id


def get_agent_response(history, session_id):
    user_message = history[-1]["content"]
    logger.info("Chat request [session=%s]: %s", session_id, user_message)

    status = {"text": "🧠 Thinking...", "done": False, "response": None, "error": None, "updated": False}
    history.append({"role": "assistant", "content": status["text"]})
    yield history, session_id

    def on_status(msg):
        status["text"] = msg
        status["updated"] = True

    def run():
        try:
            status["response"] = orchestrator.chat(user_message, session_id=session_id, status_callback=on_status)
        except Exception as e:
            logger.error("Orchestrator error [session=%s]: %s", session_id, e)
            status["error"] = str(e)
        finally:
            status["done"] = True

    t = threading.Thread(target=run)
    t.start()

    while not status["done"]:
        time.sleep(0.3)
        if status["updated"]:
            status["updated"] = False
            history[-1]["content"] = status["text"]
            yield history, session_id

    t.join()
    history[-1]["content"] = status["response"] if not status["error"] else "Sorry, an error occurred."
    logger.info("Final response [session=%s]: %d chars", session_id, len(status["response"] or ""))
    yield history, session_id


css = """
.gradio-container { max-width: 100% !important; padding: 0 !important; }
#chatbot { height: calc(100vh - 260px) !important; }
#chatbot table { display: block; overflow-x: auto; white-space: nowrap; }
#logo-row { display: flex; align-items: center; gap: 12px; padding: 8px 0 0 0; }
#logo-row svg { height: 40px; width: auto; }
#logo-row .st0 { fill: #1f1647; }
#logo-row .title-text { font-size: 2em; font-weight: 600; color: #1f1647; white-space: nowrap; line-height: 40px; }
#subtitle { font-size: 1.2em; color: #48464a; margin: 2px 0 0 0; }
.dark #logo-row .st0 { fill: #ffffff; }
.dark #logo-row .title-text { color: #f4eff4; }
.dark #subtitle { color: #c9c5ca; }
textarea, input[type="text"] { background: #ffffff !important; }
.dark textarea, .dark input[type="text"] { background: #1c1b1f !important; color: #e6e1e6 !important; }
button[aria-label="Use light theme"], button[aria-label="Use dark theme"],
button[aria-label="Use system theme"], .theme-toggle,
[class*="theme"] select, .built-with { display: none !important; }
"""

# Logo is optional -- see module docstring. Falls back to plain title text.
LOGO_SVG = None
_logo_path = os.getenv("LOGO_SVG_PATH")
if _logo_path and os.path.isfile(_logo_path):
    try:
        with open(_logo_path, encoding="utf-8") as f:
            _svg = f.read()
        _svg = re.sub(r"<\?xml.*?\?>", "", _svg)
        _svg = re.sub(r"<metadata>.*?</metadata>", "", _svg, flags=re.DOTALL)
        LOGO_SVG = _svg.strip()
    except Exception as e:
        logger.warning("Could not load logo SVG from %s: %s", _logo_path, e)

head = """<script>
if (!new URL(window.location).searchParams.has('__theme')) {
    window.location.search = '?__theme=light';
}
</script>"""

with gr.Blocks(title=" | sPayer Provider Assistant (Strands)", fill_height=True) as demo:
    logo_html = f'<div style="height:40px">{LOGO_SVG}</div>' if LOGO_SVG else ""
    gr.HTML(f'''<div id="logo-row">
        {logo_html}
        <span class="title-text"> | sPayer Provider Assistant</span>
    </div>
    <p id="subtitle">Ask me about Provider (Practitioners, Practices and Facilities) in sPayer. (Strands + Bedrock port)</p>''')

    session_state = gr.State(value=None)
    chatbot = gr.Chatbot(elem_id="chatbot")

    with gr.Row():
        msg = gr.Textbox(placeholder="Type your question here...", show_label=False, scale=9, container=False)
        send_btn = gr.Button("Send", variant="primary", scale=1, min_width=80)
        new_chat_btn = gr.Button("New Chat", variant="secondary", scale=1, min_width=100)

    with gr.Row():
        gr.Examples(
            examples=[
                "Can you find the provider with the name James Fenton?",
                "Can I get their speciality and license information?",
                "What are the locations they serve?",
            ],
            inputs=msg,
        )

    def new_chat(session_id):
        return "", [], None

    msg.submit(add_user_message, [msg, chatbot, session_state], [msg, chatbot, session_state]).then(
        get_agent_response, [chatbot, session_state], [chatbot, session_state]
    )
    send_btn.click(add_user_message, [msg, chatbot, session_state], [msg, chatbot, session_state]).then(
        get_agent_response, [chatbot, session_state], [chatbot, session_state]
    )
    new_chat_btn.click(new_chat, [session_state], [msg, chatbot, session_state])

if __name__ == "__main__":
    logger.info("Starting sPayer Provider Assistant (Strands + Bedrock port)")
    demo.queue(default_concurrency_limit=10)
    demo.launch(server_name="0.0.0.0", server_port=7860, share=False, ssr_mode=False,
                theme=theme, css=css, head=head, max_threads=10)
