"""Master Orchestrator -- Strands + Bedrock port of poc/master/orchestrator.py.

Per the two calls made when planning this port:
  1. Keep the existing custom A2A REST contract (a2a/contract.py) as-is --
     no migration to the real Google/Linux-Foundation A2A protocol.
  2. Drop registry/ -- specialist agent URLs are static, env-configured
     (AGENT_URLS below) instead of looked up by capability from a registry
     service.

Everything else -- the LLM-based intent classification, the code-level
sticky-follow-up guard, the nl2sql-explicit guard, the session store, the
synthesis call -- is unchanged in behavior from the original. Only the LLM
client (ChatBedrockConverse -> Strands BedrockModel/Agent) and the agent
lookup (registry HTTP call -> dict lookup) changed.

One deliberate fix vs the original: context_updates from a specialist agent
are now only applied to known SessionContext fields (practitioner_id /
practice_id / facility_id). The original did a blind `setattr(context, k, v)`
for whatever keys came back, which meant an unexpected key would raise
TypeError on `SessionContext(**context_data)` on the *next* turn and
permanently break that session -- see the review note this was ported from.
"""
import json
import logging
import os
import time
import uuid
from typing import Optional

import boto3
import httpx
from strands import Agent
from strands.models import BedrockModel

from a2a.contract import A2ATaskRequest, SessionContext

logger = logging.getLogger(__name__)

SYNTHESIS_URL = os.getenv("SYNTHESIS_AGENT_URL", "http://localhost:8005")

# Static agent directory -- replaces the registry/ lookup-by-capability.
# Ports match poc/start-local-a2a.sh's local defaults.
AGENT_URLS = {
    "practitioner": os.getenv("PRACTITIONER_AGENT_URL", "http://localhost:8001"),
    "practice": os.getenv("PRACTICE_AGENT_URL", "http://localhost:8003"),
    "facility": os.getenv("FACILITY_AGENT_URL", "http://localhost:8004"),
    "nl2sql": os.getenv("NL2SQL_AGENT_URL", "http://localhost:8002"),
}

CAPABILITY_MAP = {
    "practitioner": "search_practitioner",
    "practice": "search_practice",
    "facility": "search_facility",
    "nl2sql": "execute_sql_query",
}

# Only these keys are ever accepted from a specialist agent's context_updates.
_VALID_CONTEXT_FIELDS = {"practitioner_id", "practice_id", "facility_id"}


class SessionStore:
    """Session state backed by DynamoDB (if SESSION_TABLE set) or in-memory.
    Unchanged from poc/master/orchestrator.py.
    """

    def __init__(self):
        table_name = os.getenv("SESSION_TABLE")
        if table_name:
            self._table = boto3.resource(
                "dynamodb", region_name=os.getenv("AWS_REGION", "us-east-1")
            ).Table(table_name)
            self._backend = "dynamodb"
            logger.info("Session store: DynamoDB (%s)", table_name)
        else:
            self._mem: dict[str, dict] = {}
            self._backend = "memory"
            logger.info("Session store: in-memory")

    def get(self, session_id: str) -> dict:
        if self._backend == "dynamodb":
            resp = self._table.get_item(Key={"session_id": session_id})
            item = resp.get("Item")
            if not item:
                return {}
            return json.loads(item.get("data", "{}"))
        return self._mem.get(session_id, {})

    def put(self, session_id: str, data: dict):
        if self._backend == "dynamodb":
            self._table.put_item(
                Item={
                    "session_id": session_id,
                    "data": json.dumps(data, default=str),
                    "ttl": int(time.time()) + 86400,  # 24h TTL
                }
            )
        else:
            self._mem[session_id] = data


ROUTING_PROMPT = """You are a routing classifier for a healthcare provider data system.
Given a user message, determine which specialist agent should handle it.

ENTITY TYPES:
- practitioner: individual providers (doctors, nurses). Capability: search_practitioner
- practice: practice groups, medical groups. Capability: search_practice
- facility: hospitals, clinics, dialysis centers. Capability: search_facility
- nl2sql: cross-entity aggregate/analytics queries ("how many total", "across all"). Capability: execute_sql_query

IDENTIFIER RULES:
- NPI (National Provider ID) is a 10-digit number. There are TWO types:
    - Type 1 (PNPI): Practitioner NPI -- for an individual provider
    - Type 2 (GNPI): Group/Location NPI -- for a practice location or facility
- TIN (Tax ID Number) is a 9-digit number. It can belong to a Practice (group) or a Facility.
- Internal IDs (PractitionerID, PracticeID, FacilityID) are shorter numbers (typically 7-8 digits).
- If the user provides ANY numeric identifier and the entity type is CLEAR from context (e.g. "practitioner NPI 1234567890", "facility with TIN 123456789", "group NPI", "practitioner 56649720") -> route directly.
- If the user provides a numeric identifier but the entity type is AMBIGUOUS (e.g. just "NPI 1234567890", "TIN 123456789", "look up ID 56649720" with no entity context) -> ask for clarification. Ask what type of identifier it is and what entity it belongs to.

FOLLOW-UP DETECTION:
- Messages like "their specialties", "show locations", "what is their NPI", "their products", "their contracts" are follow-ups to the previous entity. Set action=route with the SAME entity type as previous_entity.
- When the user references a value from a previous response (e.g. a TIN or GNPI that was just shown in group affiliations, or a location from a previous result), this is a FOLLOW-UP -- route to the SAME entity type as previous_entity.
- "products and contracts for TIN X" or "products at this group" in a practitioner session -> still practitioner (NOT nl2sql).
- Examples: "give me locations for 3305553344" after practitioner affiliations -> still practitioner. "show practitioners at that location" after practice search -> still practice.
- Only route to nl2sql for genuinely cross-entity aggregate queries like "how many practitioners across all practices" or "total count by state".
- Only set action=clarify when there is genuinely ambiguous NEW identifier with no entity context.

Respond with ONLY a JSON object (no markdown, no explanation):
{"action": "route", "capability": "<capability_name>", "entity": "<entity_type>"}
OR
{"action": "clarify", "question": "<clarification question to ask the user>"}
"""


class MasterOrchestrator:
    def __init__(self):
        self._sessions = SessionStore()
        self.http = httpx.Client(timeout=300)
        model_id = os.getenv("BEDROCK_DEFAULT_MODEL", "mistral.ministral-3-14b-instruct")
        self._router_model = BedrockModel(model_id=model_id, region_name=os.getenv("AWS_REGION", "us-east-1"))

    # -- Agent directory ---------------------------------------------------

    def _agent_url(self, entity: str) -> Optional[str]:
        return AGENT_URLS.get(entity)

    # -- LLM-based routing ---------------------------------------------------

    def _classify_intent(self, message: str, previous_entity: str = None) -> dict:
        """Use the router LLM to classify intent, detect entity type, and ask
        clarification if needed. A fresh Agent per call -- this is single-shot
        classification, not a conversation, so no reason to carry state.
        """
        context_hint = f"\nPrevious entity type in this session: {previous_entity}" if previous_entity else ""
        user_msg = f"{context_hint}\nUser message: {message}"
        try:
            router = Agent(model=self._router_model, system_prompt=ROUTING_PROMPT, callback_handler=None)
            text = str(router(user_msg)).strip()
            if text.startswith("```"):
                text = text.split("\n", 1)[1].rsplit("```", 1)[0].strip()
            start = text.find("{")
            end = text.rfind("}") + 1
            if start >= 0 and end > start:
                text = text[start:end]
            return json.loads(text)
        except Exception as e:
            logger.warning("Router LLM failed, defaulting to practitioner: %s", e)
            return {"action": "route", "capability": "search_practitioner", "entity": "practitioner"}

    # -- A2A calls ---------------------------------------------------

    def _call_agent(self, base_url: str, prompt: str, context: SessionContext) -> dict:
        request = A2ATaskRequest(prompt=prompt)
        resp = self.http.post(
            f"{base_url}/a2a/task",
            json=request.model_dump(),
            headers=context.to_headers(),
        )
        resp.raise_for_status()
        return resp.json()

    def _call_synthesis(self, question: str, response: dict, context: SessionContext) -> str:
        tool_results = response.get("tool_results", [])
        if tool_results:
            sections = "\n\n".join(f"[{tr['tool']}]\n{tr['data']}" for tr in tool_results)
            prompt = f"question: {question}\n\ntool_results:\n{sections}"
        else:
            raw_text = response.get("result", {}).get("text", "")
            prompt = f"question: {question}\n\ntool_results:\n{raw_text}"
        request = A2ATaskRequest(prompt=prompt)
        resp = self.http.post(
            f"{SYNTHESIS_URL}/a2a/task",
            json=request.model_dump(),
            headers=context.to_headers(),
        )
        resp.raise_for_status()
        return resp.json().get("result", {}).get("text", "No response from synthesis agent.")

    # -- Main chat ---------------------------------------------------

    def chat(self, message, session_id: str = None, status_callback=None) -> str:
        if not session_id:
            session_id = str(uuid.uuid4())

        def _status(msg):
            if status_callback:
                status_callback(msg)

        if isinstance(message, list):
            message = " ".join(p.get("text", "") for p in message if isinstance(p, dict))

        session = self._sessions.get(session_id)
        context_data = session.get("context")
        if context_data and isinstance(context_data, dict):
            context = SessionContext(**context_data)
        else:
            context = SessionContext.new()
        context.session_id = session_id
        previous_entity = session.get("entity")

        # If there's a pending clarification, combine the original question with the user's answer
        pending = session.get("pending_clarification")
        if pending:
            message = f"{pending} (user clarified: {message})"
            session.pop("pending_clarification", None)

        # LLM-based intent classification + disambiguation
        _status("🧠 Understanding your request...")
        intent = self._classify_intent(message, previous_entity)
        logger.info("Router intent [session=%s]: %s", session_id[-8:], intent)

        if intent.get("action") == "clarify":
            self._sessions.put(
                session_id, {**session, "pending_clarification": message, "context": context.__dict__}
            )
            return intent["question"]

        capability = intent.get("capability", "search_practitioner")
        entity = intent.get("entity", previous_entity or "practitioner")

        # Guard: if we have a previous entity and the message looks like a follow-up,
        # stick with the previous entity regardless of what the router LLM says.
        if previous_entity and entity != previous_entity:
            msg_lower = message.lower()
            FOLLOW_UP_SIGNALS = {
                "their", "they", "this", "that", "its", "those", "the same",
                "can i get", "can you get", "show me", "give me", "what about",
            }
            is_follow_up = any(sig in msg_lower for sig in FOLLOW_UP_SIGNALS)

            if is_follow_up and capability != "execute_sql_query":
                logger.info(
                    "Overrode %s -> %s (follow-up detected) [session=%s]",
                    entity, previous_entity, session_id[-8:],
                )
                capability = CAPABILITY_MAP.get(previous_entity, capability)
                entity = previous_entity

        # Guard: if routed to nl2sql, only allow if explicitly asked for SQL or cross-entity.
        if previous_entity and capability == "execute_sql_query":
            msg_lower = message.lower()
            NL2SQL_EXPLICIT = {
                "sql query", "sql to", "write a query", "write a sql", "create a query",
                "create a sql", "generate sql", "give me a query", "give me a sql",
                "how many total", "across all", "count of all", "compare", "aggregate",
            }
            if not any(kw in msg_lower for kw in NL2SQL_EXPLICIT):
                capability = CAPABILITY_MAP.get(previous_entity, "search_practitioner")
                entity = previous_entity
                logger.info("Overrode nl2sql -> %s (follow-up) [session=%s]", entity, session_id[-8:])

        _status("🔍 Discovering agent...")
        agent_url = self._agent_url(entity)
        if not agent_url:
            return f"No agent available for this request (capability: {capability})."

        logger.info("Routing to entity=%s at %s [session=%s]", entity, agent_url, session_id[-8:])
        _status(f"⚙️ {entity.title()}Agent is processing your query...")

        try:
            response = self._call_agent(agent_url, message, context)
        except Exception as e:
            logger.error("Agent call failed: %s", e)
            return "Sorry, an error occurred processing your request."

        # Only accept known SessionContext fields -- see module docstring for why.
        for k, v in response.get("context_updates", {}).items():
            if k in _VALID_CONTEXT_FIELDS:
                setattr(context, k, v)
            else:
                logger.warning("Ignoring unknown context_updates key from %s: %s", entity, k)
        self._sessions.put(
            session_id, {"last_agent_url": agent_url, "context": context.__dict__, "entity": entity}
        )

        try:
            _status("📝 Formatting results...")
            logger.info(
                "Calling synthesis with %d tool_results [session=%s]",
                len(response.get("tool_results", [])), session_id[-8:],
            )
            return self._call_synthesis(message, response, context)
        except Exception as e:
            logger.warning("Synthesis failed, returning raw: %s", e)
            return response.get("result", {}).get("text", "")

    def create_session(self) -> str:
        return str(uuid.uuid4())
