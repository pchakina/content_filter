"""NL2SQL Agent -- single-tool A2A service (port of poc/agents/nl2sql/main.py).

Deliberately NOT a Strands Agent: it always calls query_provider_database
directly, with no LLM deciding whether to call it. The original POC found
that wrapping one tool in an agent loop let the model write SQL from memory
instead of calling the tool.

Known gap (same as poc/): mcp/n2sql/tool.py, the code behind
query_provider_database, was never committed, so this agent's task calls
return status="failed" until that module exists. The service itself starts
and answers /health normally.
"""
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path

import requests
from fastapi import FastAPI

from a2a.contract import A2ATaskRequest, A2ATaskResponse, ToolResult

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

_dir = Path(__file__).parent
MANIFEST = json.loads((_dir / "manifest.json").read_text())
MANIFEST["spec"]["service"]["baseUrl"] = os.getenv("AGENT_BASE_URL", MANIFEST["spec"]["service"]["baseUrl"])

MCP_URL = os.getenv("MCP_URL", "http://localhost:8080")

app = FastAPI(title="NL2SQLAgent", version=MANIFEST["metadata"]["version"])
prefix = os.getenv("ROOT_PATH", "")


@app.get(f"{prefix}/a2a/discover")
def discover():
    return {
        "agent": MANIFEST["metadata"],
        "capabilities": MANIFEST["spec"]["capabilities"],
        "service_info": {"protocol": "http+json", "base_url": MANIFEST["spec"]["service"]["baseUrl"]},
    }


@app.post(f"{prefix}/a2a/task", response_model=A2ATaskResponse)
def run_task(request: A2ATaskRequest):
    start = datetime.now(timezone.utc)
    try:
        resp = requests.post(
            f"{MCP_URL}/mcp/v1/tools/call",
            json={"name": "query_provider_database", "arguments": {"question": request.prompt}},
            timeout=180,
        )
        resp.raise_for_status()
        data = resp.json()["content"][0]["text"]
        logger.info("NL2SQL tool returned %d chars", len(data))
        return A2ATaskResponse(
            task_id=request.task_id,
            status="completed",
            result={"text": data},
            tool_results=[ToolResult(tool="query_provider_database", data=data,
                                     status="error" if '"error"' in data else "ok")],
            metadata={"duration_ms": int((datetime.now(timezone.utc) - start).total_seconds() * 1000)},
        )
    except Exception as e:
        logger.exception("NL2SQL task failed")
        return A2ATaskResponse(task_id=request.task_id, status="failed", error=str(e))


@app.get(f"{prefix}/health")
@app.get("/health")
def health():
    return {"status": "healthy", "agent": "NL2SQLAgent", "tools": 1}
