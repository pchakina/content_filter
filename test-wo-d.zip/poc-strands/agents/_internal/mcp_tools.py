"""Dynamic Strands tool loader for the existing custom REST "MCP" server
(poc/mcp/server_http.py) -- lets poc-strands run against that server UNMODIFIED.

Important caveat: poc/mcp/server_http.py does NOT speak the real Model Context
Protocol (JSON-RPC over stdio/Streamable-HTTP). It's a custom REST shape --
`GET /mcp/v1/tools` / `POST /mcp/v1/tools/call` -- inspired by MCP naming. Strands'
own `strands.tools.mcp.MCPClient` expects the real protocol, so it can't point at
this server as-is. This module is the bridge: it fetches that REST tool catalogue
and turns it into real Strands tools.

If poc/mcp/server_http.py is ever upgraded to a genuine MCP transport (e.g. via
the `mcp` SDK's FastMCP), swap this whole module for:

    from strands.tools.mcp import MCPClient
    from mcp.client.streamable_http import streamablehttp_client
    mcp_client = MCPClient(lambda: streamablehttp_client(f"{mcp_url}/mcp"))
    with mcp_client:
        tools = mcp_client.list_tools_sync()

...and nothing else in agent_runtime.py or the specialist agents needs to change.

Why exec() instead of Strands' documented dynamic-tool APIs
-------------------------------------------------------------
Strands' public, documented way to define a tool is the `@tool` decorator, which
builds the input schema the model sees by introspecting a *real* function's type
hints and docstring -- there's no publicly documented "give me a raw JSON-Schema
dict" constructor equivalent to LangChain's `create_model()` trick the original
POC used (see poc/agents/_internal/agent_runtime.py:28-56). So for each MCP tool
definition we generate real Python source with named, typed parameters and
exec() it, then apply the *decorator* to the resulting function. This keeps tool
loading dependent only on the stable, documented @tool API rather than any
internal class whose constructor signature might change between Strands
versions.
"""
import logging
import time

import requests
from strands import tool

logger = logging.getLogger(__name__)

_JSONSCHEMA_TO_PY = {"integer": "int", "number": "float", "boolean": "bool"}


def _call_mcp_tool(mcp_url: str, name: str, arguments: dict) -> str:
    resp = requests.post(
        f"{mcp_url}/mcp/v1/tools/call",
        json={"name": name, "arguments": arguments},
        timeout=180,
    )
    resp.raise_for_status()
    return resp.json()["content"][0]["text"]


def fetch_tool_definitions(mcp_url: str, agent_name: str) -> list[dict]:
    """Fetch the tool catalogue once and filter to this agent's tools (same
    'agents' tag filtering as poc/agents/_internal/agent_runtime.py:66). Call
    this once at service startup -- it's the only network call in this module;
    building the actual callables (build_tools, below) is pure/local and cheap
    enough to redo per request.
    """
    resp = requests.get(f"{mcp_url}/mcp/v1/tools", timeout=30)
    resp.raise_for_status()
    all_tools = resp.json()["tools"]
    filtered = [t for t in all_tools if agent_name in t.get("agents", [])]
    logger.info("Fetched %d tool definitions for agent=%s", len(filtered), agent_name)
    return filtered


def _build_one_tool(mcp_tool_def: dict, mcp_url: str, call_log: list):
    """Turn one MCP tool definition into a real Strands tool bound to `call_log`
    (a plain list the caller appends nothing to directly -- the generated tool
    function appends its own {tool, arguments, data, duration_ms} entry on every
    call, which is exactly the ToolResult shape a2a/contract.py needs). Passing
    a *fresh* call_log per request (see agent_runtime.py) keeps this
    concurrency-safe across simultaneous requests.
    """
    name = mcp_tool_def["name"]
    description = (mcp_tool_def.get("description") or name).replace('"""', "'").replace("\\", "/")
    props = mcp_tool_def.get("inputSchema", {}).get("properties", {})
    required = set(mcp_tool_def.get("inputSchema", {}).get("required", []))

    params, doc_args, build_pairs = [], [], []
    for pname, pinfo in props.items():
        ptype = _JSONSCHEMA_TO_PY.get(pinfo.get("type"), "str")
        params.append(f"{pname}: {ptype}" if pname in required else f"{pname}: {ptype} = None")
        doc_args.append(f"    {pname}: {pinfo.get('description', pname)}")
        build_pairs.append(f'"{pname}": {pname}')

    # Keyword-only ("*, ..."): MCP schemas can list a required param after an
    # optional one, which is a SyntaxError for positional params. Strands
    # always passes tool input as keyword arguments, so nothing else changes.
    signature = ("*, " + ", ".join(params)) if params else ""
    docstring = description if not doc_args else description + "\n\nArgs:\n" + "\n".join(doc_args)
    build_args = ", ".join(build_pairs)

    # mcp_url/name/call_log are passed through the exec namespace below as
    # plain identifiers (_mcp_url, _name, _log) rather than string-interpolated
    # into the source -- avoids any quoting hazard from special characters in
    # tool names/descriptions/URLs.
    #
    # Built line-by-line (not textwrap.dedent on one big f-string): `docstring`
    # can itself contain newlines with zero leading whitespace (the "Args:"
    # block), and dedent() computes common indentation across the WHOLE
    # resulting text -- including lines that came from inside the docstring --
    # so a flush-left docstring line silently defeats dedent for the entire
    # source and produces "unexpected indent" on `def`.
    lines = [
        f"def _tool_fn({signature}) -> str:",
        f'    """{docstring}"""',
        f"    _args = {{{build_args}}}",
        '    _args = {k: v for k, v in _args.items() if v is not None and v != ""}',
        "    _start = _time.time()",
        "    _data = _call(_mcp_url, _name, _args)",
        '    _log.append({"tool": _name, "arguments": _args, "data": _data,',
        '                  "duration_ms": int((_time.time() - _start) * 1000)})',
        "    return _data",
    ]
    src = "\n".join(lines)

    namespace = {"_time": time, "_call": _call_mcp_tool, "_log": call_log,
                 "_mcp_url": mcp_url, "_name": name}
    exec(compile(src, f"<mcp_tool:{name}>", "exec"), namespace)
    fn = namespace["_tool_fn"]
    fn.__name__ = name
    fn.__qualname__ = name
    return tool(fn)


def build_tools(tool_defs: list[dict], mcp_url: str, call_log: list) -> list:
    """Build ready-to-use Strands tools from cached tool_defs, bound to a
    caller-supplied call_log list. Cheap (no network I/O) -- safe to call once
    per request so each request gets its own isolated call_log.
    """
    return [_build_one_tool(t, mcp_url, call_log) for t in tool_defs]
