"""Shared Strands-based runtime for A2A specialist agents.

Strands port of poc/agents/_internal/agent_runtime.py. Same external contract
(A2A endpoints, request/response shape) and same deliberate design decisions:

  - loads only this agent's MCP tools, filtered by the `agents` tag on each
    tool definition (agents/_internal/mcp_tools.py mirrors this).
  - builds a *fresh* Strands `Agent` for every single request rather than
    reusing one across turns. This is carried over on purpose: the original
    POC discovered that a shared, checkpointed conversation thread made the
    LLM start skipping tool calls once it saw prior results in history
    (poc/agents/_internal/agent_runtime.py:157-159 has the original comment).
    Strands Agent objects accumulate their own conversation history the same
    way, so the fix applies just as much here -- new Agent() per request,
    with discovered entity IDs injected into the prompt as a
    "[Session context: PractitionerID=X]" prefix instead of relying on memory.
  - returns tool_results[] populated per call (not just a summary string) so
    the Synthesis Agent can format each data type as its own table, per the
    A2A contract's own requirement (a2a/contract.py: ToolResult docstring).

What's simpler than the LangGraph version, concretely:
  - no StateGraph/ToolNode/conditional-edge wiring -- Agent(tools=[...]) already
    implements the reason<->act loop.
  - no MemorySaver/thread_id bookkeeping -- statelessness is just "make a new
    Agent".
  - tool-call timing/arguments are captured directly inside each generated
    tool function (see mcp_tools.py) instead of via a langchain_tool closure
    list threaded through a separate _make_langchain_tool factory.
"""
import logging
import os
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone

import httpx
from fastapi import FastAPI, Header
from strands import Agent
from strands.models import BedrockModel

from a2a.contract import A2ATaskRequest, A2ATaskResponse, SessionContext, ToolResult
from agents._internal.mcp_tools import build_tools, fetch_tool_definitions

logger = logging.getLogger(__name__)

DEFAULT_MODEL = os.getenv("BEDROCK_DEFAULT_MODEL", "mistral.ministral-3-14b-instruct")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")

# Registry is optional now (poc-strands uses static, env-configured agent URLs
# in master/orchestrator.py -- see that file's AGENT_URLS). Self-registration
# here is best-effort and silently skipped unless REGISTRY_URL is explicitly
# set, so no registry service needs to be running for this to work.
REGISTRY_URL = os.getenv("REGISTRY_URL")


def _make_model() -> BedrockModel:
    """BedrockModel builds its own boto3 client under the hood, so AWS_PROFILE/
    AWS_REGION/credentials already work via boto3's normal default credential
    chain -- no need to thread an explicit profile kwarg through here. If you
    need something more specific (assumed roles, custom boto3 Session, a
    non-default endpoint), check strands.models.BedrockModel's current
    constructor in your installed version -- it has grown extra kwargs across
    releases.
    """
    return BedrockModel(model_id=DEFAULT_MODEL, region_name=AWS_REGION)


def _extract_text(result) -> str:
    """Strands' Agent.__call__ returns an AgentResult; every example in the
    Strands docs treats it as directly printable/str-able for the final
    assistant text. Fall back to digging through .message if a future version
    changes that -- keeps this one call site as the single place to patch.
    """
    try:
        return str(result)
    except Exception:
        message = getattr(result, "message", None)
        if isinstance(message, dict):
            for block in message.get("content", []):
                if isinstance(block, dict) and "text" in block:
                    return block["text"]
        return repr(result)


def create_agent_app(
    manifest: dict,
    system_prompt: str,
    agent_name: str,
    mcp_url: str,
    extract_context_updates=None,
) -> FastAPI:
    """Create a FastAPI app implementing the A2A contract endpoints.

    extract_context_updates(call_log) -> dict, where call_log is the same list
    of {"tool", "arguments", "data", "duration_ms"} dicts used to build
    tool_results -- simpler than the original's message-scanning version since
    the raw tool JSON is right there, not buried in LangChain message objects.
    """
    name = manifest["metadata"]["name"]
    version = manifest["metadata"]["version"]
    capabilities = manifest["spec"]["capabilities"]
    base_url = manifest["spec"]["service"]["baseUrl"]

    state = {"tool_defs": []}
    prefix = os.getenv("ROOT_PATH", "")

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Fetch the tool catalogue once at startup (the only network call in
        # tool loading); actual Strands tool objects are (re)built fresh per
        # request in run_task below, see mcp_tools.build_tools docstring.
        state["tool_defs"] = fetch_tool_definitions(mcp_url, agent_name)
        if REGISTRY_URL:
            try:
                httpx.post(f"{REGISTRY_URL}/agents", json=manifest, timeout=10).raise_for_status()
                logger.info("%s registered with registry at %s", name, REGISTRY_URL)
            except Exception as e:
                logger.warning("Registry registration failed: %s", e)
        yield

    app = FastAPI(title=name, version=version, lifespan=lifespan)

    @app.get(f"{prefix}/a2a/discover")
    def discover():
        return {
            "agent": manifest["metadata"],
            "capabilities": capabilities,
            "service_info": {"protocol": "http+json", "base_url": base_url, "health_check": "/health"},
        }

    @app.post(f"{prefix}/a2a/task", response_model=A2ATaskResponse)
    def run_task(
        request: A2ATaskRequest,
        a2a_context_id: str = Header(default=""),
        a2a_session_id: str = Header(default=""),
        a2a_user_id: str = Header(default="anonymous"),
        a2a_practitioner_id: str = Header(default=""),
        a2a_practice_id: str = Header(default=""),
        a2a_facility_id: str = Header(default=""),
    ):
        context = SessionContext(
            context_id=a2a_context_id or str(uuid.uuid4()),
            session_id=a2a_session_id or str(uuid.uuid4()),
            user_id=a2a_user_id,
            practitioner_id=a2a_practitioner_id or None,
            practice_id=a2a_practice_id or None,
            facility_id=a2a_facility_id or None,
        )
        start = datetime.now(timezone.utc)
        try:
            # Inject discovered entity IDs so the LLM can resolve "their"/"this"
            # -- same mechanism as the LangGraph version, unrelated to the
            # framework swap.
            ctx_parts = []
            if context.practitioner_id:
                ctx_parts.append(f"PractitionerID={context.practitioner_id}")
            if context.practice_id:
                ctx_parts.append(f"PracticeID={context.practice_id}")
            if context.facility_id:
                ctx_parts.append(f"FacilityID={context.facility_id}")
            prompt = request.prompt
            if ctx_parts:
                prompt = f"[Session context: {', '.join(ctx_parts)}]\n{prompt}"

            # Fresh call_log + fresh tools + fresh Agent every request: keeps
            # concurrent requests isolated from each other (no shared mutable
            # state) and keeps each request's conversation stateless, per the
            # module docstring above.
            call_log: list = []
            tools = build_tools(state["tool_defs"], mcp_url, call_log)
            agent = Agent(model=_make_model(), tools=tools, system_prompt=system_prompt,
                          callback_handler=None)  # no token streaming to stdout

            result = agent(prompt)
            text = _extract_text(result)

            tool_results = [
                ToolResult(
                    tool=c["tool"],
                    data=c["data"],
                    status="error" if '"error"' in c["data"] else "ok",
                    arguments=c["arguments"],
                    duration_ms=c["duration_ms"],
                )
                for c in call_log
            ]
            updates = extract_context_updates(call_log) if extract_context_updates else {}
            return A2ATaskResponse(
                task_id=request.task_id,
                status="completed",
                result={"text": text},
                tool_results=tool_results,
                context_updates=updates,
                metadata={"duration_ms": int((datetime.now(timezone.utc) - start).total_seconds() * 1000)},
            )
        except Exception as e:
            logger.exception("Task failed: %s", request.task_id)
            return A2ATaskResponse(task_id=request.task_id, status="failed", error=str(e))

    @app.get(f"{prefix}/health")
    @app.get("/health")
    def health():
        return {"status": "healthy", "agent": name, "tools": len(state["tool_defs"])}

    return app
