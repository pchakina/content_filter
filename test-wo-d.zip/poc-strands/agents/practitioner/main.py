"""Practitioner Agent -- A2A service for practitioner data (Strands + Bedrock port
of poc/agents/practitioner/main.py). Run with:

    uvicorn agents.practitioner.main:app --port 8001 --app-dir .

(from the poc-strands/ root, or set PYTHONPATH to it.)
"""
import json
import logging
import os
from pathlib import Path

from agents._internal.agent_runtime import create_agent_app
from agents.prompts import PRACTITIONER_SYSTEM_PROMPT as SYSTEM_PROMPT

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

_dir = Path(__file__).parent
MANIFEST = json.loads((_dir / "manifest.json").read_text())
# Override baseUrl from env so it works in any deployment
MANIFEST["spec"]["service"]["baseUrl"] = os.getenv("AGENT_BASE_URL", MANIFEST["spec"]["service"]["baseUrl"])


def extract_context_updates(call_log: list) -> dict:
    """Scan this request's tool results for a discovered PractitionerID to
    propagate back to the orchestrator's session context. Simpler than the
    original: call_log entries already carry the raw tool JSON directly
    (mcp_tools.py), no LangChain message objects to unwrap.
    """
    for c in call_log:
        try:
            data = json.loads(c["data"])
        except (json.JSONDecodeError, TypeError):
            continue
        results = data.get("results", [data] if "PractitionerID" in data else [])
        if results and "PractitionerID" in results[0]:
            return {"practitioner_id": str(results[0]["PractitionerID"])}
    return {}


app = create_agent_app(
    MANIFEST,
    SYSTEM_PROMPT,
    "PractitionerAgent",
    os.getenv("MCP_URL", "http://localhost:8080"),
    extract_context_updates,
)
