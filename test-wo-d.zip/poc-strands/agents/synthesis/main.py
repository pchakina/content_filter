"""Synthesis Agent -- turns raw tool results into markdown (port of
poc/agents/synthesis/main.py).

Hybrid, same as the original: structured JSON results are formatted in code
(every row rendered, no output-token truncation); only text that isn't JSON
goes to the LLM. The LLM call now uses a tool-less Strands Agent instead of
LangChain's ChatBedrockConverse. The formatting code is unchanged.
"""
import json
import logging
import os
import re
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI
from strands import Agent
from strands.models import BedrockModel

from a2a.contract import A2ATaskRequest, A2ATaskResponse

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

_dir = Path(__file__).parent
MANIFEST = json.loads((_dir / "manifest.json").read_text())
MANIFEST["spec"]["service"]["baseUrl"] = os.getenv("AGENT_BASE_URL", MANIFEST["spec"]["service"]["baseUrl"])

MODEL_ID = os.getenv("BEDROCK_SYNTHESIS_MODEL",
                     os.getenv("BEDROCK_DEFAULT_MODEL", "mistral.ministral-3-14b-instruct"))
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")

SYSTEM_PROMPT = """You are a response formatter for HealthSpring provider data.
You receive raw tool results and format them into clean, readable markdown.

CRITICAL: NEVER invent, fabricate, or assume any data. Only format what is provided in the tool results. If data is missing, say "No information found" -- do NOT generate fake records, SQL queries, or JSON.

FORMATTING RULES:
- Tool results are provided as labeled sections: [tool_name] followed by the raw data
- Present each [tool_name] section as a SEPARATE table with a heading derived from the tool name
  Example: [get_practitioner_specialties] -> ### Specialties
           [get_practitioner_education]   -> ### Education
           [get_practitioner_languages]   -> ### Languages
- NEVER merge different data types into one wide table
- If a section has no data or an error, write "No [section] information found." in plain text
- If results contain a "sql" field, show it in: <details><summary>SQL Query</summary>\\n\\n```sql\\n...\\n```\\n</details>
- Do NOT add advice, disclaimers, or suggestions beyond the data
- Do NOT add horizontal rules (---) between sections
- Do NOT add blank lines between sections -- just ### heading then table immediately

DATA CLEANUP:
- Replace null/None values with empty string
- Use human-readable column headers (e.g. SpecialtyName -> Specialty, BoardCertified -> Board Certified, PrimarySpecialty -> Primary)
- Drop columns that are entirely null/empty across all rows

TABLE FORMAT (CRITICAL -- follow exactly):
- ALWAYS use HORIZONTAL tables: field names as column headers in row 1, values in row 2+

CORRECT (horizontal -- use this even when there is only ONE record):
### Practitioner
| FirstName | LastName | NPI | Gender | Status |
|-----------|----------|-----|--------|--------|
| JAMES | FENTON | 1851395305 | Male | Active |
### Specialties
| Specialty | Primary | Board Certified | Expiration |
|-----------|---------|-----------------|------------|
| Pulmonary Disease | Y | Y | 2025-04-01 |

WRONG (vertical -- NEVER do this, not even for a single record):
| Field | Value |
|-------|-------|
| FirstName | JAMES |
| LastName | FENTON |
"""

_LIST_KEYS = ("results", "groups", "affiliations", "specialties", "licenses", "education",
              "languages", "locations", "products", "credentialing", "qi_activities",
              "location_services")
_EMPTY = (None, "", "None")


def _heading(tool_name: str) -> str:
    return (tool_name.replace("get_", "").replace("search_", "").replace("query_", "")
            .replace("_", " ").title())


def _rows_to_table(rows: list[dict]) -> str:
    if not rows:
        return "No data found."
    headers = [k for k in rows[0].keys() if any(r.get(k) not in _EMPTY for r in rows)]
    display = [h.replace("ID", " ID").replace("Name", " Name").strip() for h in headers]
    lines = ["| " + " | ".join(display) + " |",
             "| " + " | ".join("---" for _ in headers) + " |"]
    for r in rows:
        lines.append("| " + " | ".join(str(r.get(h, "") or "") for h in headers) + " |")
    return "\n".join(lines)


def _format_json_table(tool_name: str, raw: str):
    """Format structured JSON into a markdown table, or return None to fall back to the LLM."""
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return None

    sql_block = ""
    if isinstance(data, dict) and data.get("sql"):
        sql_block = f"\n\n<details><summary>SQL Query</summary>\n\n```sql\n{data['sql']}\n```\n</details>"

    rows = None
    if isinstance(data, dict):
        for key in _LIST_KEYS:
            if isinstance(data.get(key), list):
                rows = data[key]
                break
        if rows is None:
            rows = next((v for v in data.values() if isinstance(v, list)), None)
    elif isinstance(data, list):
        rows = data

    heading = _heading(tool_name)
    if not rows:
        if sql_block:
            return f"### {heading}\nNo results found.{sql_block}"
        return f"### {heading}\nNo {heading.lower()} information found."

    rows = [r for r in rows if isinstance(r, dict) and any(v not in _EMPTY for v in r.values())]
    # NL2SQL only: a LEFT JOIN that matched nothing yields base rows whose joined columns are all null.
    if tool_name == "query_provider_database" and rows and len(rows[0]) > 4:
        non_null = [k for k in rows[0] if any(r.get(k) not in _EMPTY for r in rows)]
        if len(non_null) < len(rows[0]) / 2:
            rows = []
    if not rows:
        return f"### {heading}\nNo {heading.lower()} information found."

    count_info = ""
    total = (data.get("count") or data.get("total") or len(rows)) if isinstance(data, dict) else len(rows)
    if total > len(rows):
        count_info = f"\n*Showing {len(rows)} of {total} results.*\n"

    # Nested structures, e.g. group affiliations with locations inside each group.
    if "locations" in rows[0]:
        parts = [f"### {heading}"]
        for group in rows:
            locs = group.pop("locations", [])
            parts.append(f"\n**{group.get('PracticeName', '')}** (TIN: {group.get('GroupTIN', '')})")
            parts.append(_rows_to_table(locs) if locs else "No locations found.")
        return "\n".join(parts) + sql_block

    return f"### {heading}{count_info}\n{_rows_to_table(rows)}{sql_block}"


def _llm_format(content: str) -> str:
    agent = Agent(
        model=BedrockModel(model_id=MODEL_ID, region_name=AWS_REGION),
        system_prompt=SYSTEM_PROMPT,
        callback_handler=None,  # don't stream tokens to stdout
    )
    return str(agent(content))


def format_results(question: str, tool_results: list[str]) -> str:
    programmatic, for_llm = [], []
    for tr in tool_results:
        if tr.startswith("[") and "]\n" in tr:
            end = tr.index("]")
            table = _format_json_table(tr[1:end], tr[end + 2:])
            if table:
                programmatic.append(table)
                continue
        for_llm.append(tr)

    # Drop consecutive duplicate sections (e.g. several empty location-service results).
    deduped = []
    for part in programmatic:
        if not deduped or part != deduped[-1]:
            deduped.append(part)

    if deduped and not for_llm:
        return "\n\n".join(deduped)
    if for_llm:
        llm_output = _llm_format(f"User question: {question}\n\nTool results:\n" + "\n\n".join(for_llm))
        return "\n\n".join(deduped + [llm_output]) if deduped else llm_output
    return _llm_format(f"User question: {question}\n\nNo tool results were returned.")


app = FastAPI(title="SynthesisAgent", version=MANIFEST["metadata"]["version"])
prefix = os.getenv("ROOT_PATH", "")


@app.get(f"{prefix}/a2a/discover")
def discover():
    return {
        "agent": MANIFEST["metadata"],
        "capabilities": MANIFEST["spec"]["capabilities"],
        "service_info": {"protocol": "http+json", "base_url": MANIFEST["spec"]["service"]["baseUrl"]},
    }


@app.post(f"{prefix}/a2a/task", response_model=A2ATaskResponse)
def run_task(request: A2ATaskRequest):
    start = datetime.now(timezone.utc)
    try:
        # Prompt format from master/orchestrator.py: "question: ...\n\ntool_results:\n[tool]\n{json}\n\n[tool]\n..."
        parts = request.prompt.split("\n\ntool_results:\n", 1)
        question = parts[0].replace("question: ", "", 1)
        raw = parts[1] if len(parts) > 1 else ""
        sections = [s.strip() for s in re.split(r"\n\n(?=\[)", raw) if s.strip()]
        text = format_results(question, sections)
        return A2ATaskResponse(
            task_id=request.task_id,
            status="completed",
            result={"text": text},
            metadata={"duration_ms": int((datetime.now(timezone.utc) - start).total_seconds() * 1000)},
        )
    except Exception as e:
        logger.exception("Synthesis failed")
        return A2ATaskResponse(task_id=request.task_id, status="failed", error=str(e))


@app.get(f"{prefix}/health")
@app.get("/health")
def health():
    return {"status": "healthy", "agent": "SynthesisAgent"}
