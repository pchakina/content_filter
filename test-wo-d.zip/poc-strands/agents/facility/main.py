"""Facility Agent -- A2A service for facility data (Strands + Bedrock port of
poc/agents/facility/main.py). Note: the poc/ original's main.py reads
"manifest.json" but the file actually on disk there is misspelled
"maifest.json" -- that service crashes on startup with FileNotFoundError.
Fixed here: this file is correctly spelled "manifest.json".

Run with:
    uvicorn agents.facility.main:app --port 8004 --app-dir .

(from the poc-strands/ root, or set PYTHONPATH to it.)
"""
import json
import logging
import os
from pathlib import Path

from agents._internal.agent_runtime import create_agent_app
from agents.prompts import FACILITY_SYSTEM_PROMPT as SYSTEM_PROMPT

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

_dir = Path(__file__).parent
MANIFEST = json.loads((_dir / "manifest.json").read_text())
MANIFEST["spec"]["service"]["baseUrl"] = os.getenv("AGENT_BASE_URL", MANIFEST["spec"]["service"]["baseUrl"])


def extract_context_updates(call_log: list) -> dict:
    """Scan this request's tool results for a discovered FacilityID."""
    for c in call_log:
        try:
            data = json.loads(c["data"])
        except (json.JSONDecodeError, TypeError):
            continue
        results = data.get("results", [data] if "FacilityID" in data else [])
        if results and "FacilityID" in results[0]:
            return {"facility_id": str(results[0]["FacilityID"])}
    return {}


app = create_agent_app(
    MANIFEST,
    SYSTEM_PROMPT,
    "FacilityAgent",
    os.getenv("MCP_URL", "http://localhost:8080"),
    extract_context_updates,
)
