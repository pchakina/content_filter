import json
import logging
import os
import requests
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

REGISTRY_PATH = os.path.join(os.path.dirname(__file__), "spayer-tools-registry.json")
with open(REGISTRY_PATH) as f:
    registry = json.load(f)

API_BASE_URL = os.getenv("API_BASE_URL", registry.get("baseUrl", "http://localhost:8000"))
logger.info(f"Loaded registry with {len(registry['tools'])} tools, API base URL: {API_BASE_URL}")

app = FastAPI(title="Provider MCP Server", version="1.0.0")

class ToolCall(BaseModel):
    name: str
    arguments: dict

def build_tool_schema(tool_def):
    properties = {}
    required = []
    
    for name, param in tool_def["parameters"].items():
        properties[name] = {
            "type": param["type"],
            "description": param["description"]
        }
        if param.get("required"):
            required.append(name)
    
    return {
        "name": tool_def["name"],
        "description": tool_def["description"],
        "inputSchema": {
            "type": "object",
            "properties": properties,
            "required": required
        }
    }

@app.get("/mcp/v1/tools")
def list_tools():
    tools = []
    for t in registry["tools"]:
        if t["name"] == "health_check":
            continue
        if t.get("type") == "nl2sql":
            props = {k: {"type": v["type"], "description": v["description"]}
                     for k, v in t["parameters"].items()}
            req = [k for k, v in t["parameters"].items() if v.get("required")]
            tools.append({"name": t["name"], "description": t["description"],
                          "agents": t.get("agents", []),
                          "inputSchema": {"type": "object", "properties": props, "required": req}})
        else:
            schema = build_tool_schema(t)
            schema["agents"] = t.get("agents", [])
            tools.append(schema)
    logger.info(f"Listed {len(tools)} tools")
    return {"tools": tools}

@app.post("/mcp/v1/tools/call")
def call_tool(request: ToolCall):
    logger.info(f"Tool called: {request.name} with arguments: {request.arguments}")
    
    # Handle NL2SQL tool
    tool_reg = next((t for t in registry["tools"] if t["name"] == request.name), None)
    if tool_reg and tool_reg.get("type") == "nl2sql":
        from nl2sql.tool import query_provider_database
        question = request.arguments.get("question") or request.arguments.get("Query") or request.arguments.get("query", "")
        result = query_provider_database(question)
        return {"content": [{"type": "text", "text": result}]}

    if not tool_reg:
        raise HTTPException(status_code=404, detail=f"Tool {request.name} not found")
    
    try:
        path = tool_reg["path"]
        params = {}
        
        # Normalize argument names to match expected parameter names
        expected_params = tool_reg["parameters"]
        PARAM_ALIASES = {
            "npi": "NationalProviderID",
            "tin": "TaxIDNumber",
            "id": "PractitionerID",
        }
        normalized_args = {}
        for key, value in request.arguments.items():
            if key in expected_params:
                normalized_args[key] = value
            elif key.lower() in PARAM_ALIASES and PARAM_ALIASES[key.lower()] in expected_params:
                normalized_args[PARAM_ALIASES[key.lower()]] = value
            else:
                normalized_args[key] = value

        for key, value in normalized_args.items():
            param_def = expected_params.get(key, {})
            if param_def.get("in") == "path":
                path = path.replace(f"{{{key}}}", str(value))
            else:
                params[key] = value
        
        url = f"{API_BASE_URL}{path}"
        logger.info(f"Making {tool_reg['method']} request to {url}")
        
        response = requests.request(tool_reg["method"], url, params=params, timeout=30)
        
        if response.status_code >= 400:
            logger.error(f"API error: {response.status_code}")
            return {"content": [{"type": "text", "text": response.text}]}
        
        return {"content": [{"type": "text", "text": response.text}]}
        
    except requests.exceptions.Timeout:
        raise HTTPException(status_code=504, detail="Request timeout")
    except requests.exceptions.ConnectionError:
        raise HTTPException(status_code=503, detail=f"Cannot connect to API at {API_BASE_URL}")
    except Exception as e:
        logger.error(f"Error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
def health():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8080))
    uvicorn.run(app, host="0.0.0.0", port=port)