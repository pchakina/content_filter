# Provider API MCP Server

MCP (Model Context Protocol) server that exposes the Provider API as tools for AI agents.

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Ensure the Provider API is running:
```bash
cd ../spayer-backend
uvicorn main:app --reload
```

## Running the MCP Server

### Stdio Mode (for MCP clients)

```bash
python server.py
```

The server runs in stdio mode and communicates via standard input/output, making it compatible with MCP clients.

### HTTP Mode (for direct API access)

```bash
python server_http.py
```

The HTTP server runs on `http://localhost:8080` by default and exposes REST endpoints:
- `GET /mcp/v1/tools` - List all available tools
- `POST /mcp/v1/tools/call` - Execute a tool
- `GET /health` - Health check

Set the `PORT` environment variable to use a different port.

## Testing with MCP Inspector

Install the MCP Inspector:
```bash
npx @modelcontextprotocol/inspector python server.py
```

This opens a web interface where you can:
- View all available tools
- Test tool calls with different parameters
- See request/response payloads

## Available Tools

The server exposes 21 tools covering:
- **Practitioner**: Search, demographics, NPI lookup, specialties, licenses, locations, products
- **Practice**: Search, demographics, TIN lookup, locations, services, licenses
- **Facility**: Search, demographics, NPI lookup, licenses, locations, products

## Integration with AI Agents

Add this server to your MCP client configuration (e.g., Claude Desktop, Kiro CLI):

```json
{
  "mcpServers": {
    "provider-api": {
      "command": "python",
      "args": ["/path/to/mcp/server.py"]
    }
  }
}
```

## Configuration

Edit `API_BASE_URL` in `server.py` to point to your Provider API instance (default: `http://localhost:8000`).