import pyodbc
import json
import os
from dotenv import load_dotenv

load_dotenv()

def extract_schema(provider_type='practitioner'):
    """Extract schema for a specific provider type"""
    
    conn_str = (
        f"DRIVER={{{os.getenv('DB_DRIVER')}}};"
        f"SERVER={os.getenv('DB_SERVER')},{os.getenv('DB_PORT')};"
        f"DATABASE={os.getenv('DB_NAME')};"
        f"UID={os.getenv('DB_USER')};"
        f"PWD={os.getenv('DB_PASSWORD')}"
    )
    
    conn = pyodbc.connect(conn_str)
    cursor = conn.cursor()
    
    # Read table names
    base_dir = os.path.join(os.path.dirname(__file__), '..')
    tables = []
    with open(os.path.join(base_dir, f'schemas/tables/{provider_type}_tables.txt'), 'r') as f:
        tables.extend([line.strip() for line in f if line.strip()])
    
    with open(os.path.join(base_dir, 'schemas/tables/reference_tables.txt'), 'r') as f:
        tables.extend([line.strip() for line in f if line.strip()])
    
    schema = {}
    print(f"Extracting schema for {provider_type} ({len(tables)} tables)...\n")
    
    for table in tables:
        print(f"Extracting schema for {table}...")
        
        # Get columns
        cursor.execute(f"""
            SELECT 
                c.COLUMN_NAME,
                c.DATA_TYPE,
                c.CHARACTER_MAXIMUM_LENGTH,
                c.IS_NULLABLE,
                CASE WHEN pk.COLUMN_NAME IS NOT NULL THEN 'YES' ELSE 'NO' END AS IS_PRIMARY_KEY
            FROM INFORMATION_SCHEMA.COLUMNS c
            LEFT JOIN (
                SELECT ku.TABLE_NAME, ku.COLUMN_NAME
                FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
                JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE ku
                    ON tc.CONSTRAINT_NAME = ku.CONSTRAINT_NAME
                WHERE tc.CONSTRAINT_TYPE = 'PRIMARY KEY'
            ) pk ON c.TABLE_NAME = pk.TABLE_NAME AND c.COLUMN_NAME = pk.COLUMN_NAME
            WHERE c.TABLE_NAME = ?
            ORDER BY c.ORDINAL_POSITION
        """, table)
        
        columns = []
        for row in cursor.fetchall():
            col = {
                'name': row[0],
                'type': row[1],
                'max_length': row[2],
                'nullable': row[3],
                'primary_key': row[4]
            }
            columns.append(col)
        
        # Get foreign keys
        cursor.execute(f"""
            SELECT 
                fk.name AS FK_NAME,
                OBJECT_NAME(fk.parent_object_id) AS TABLE_NAME,
                COL_NAME(fkc.parent_object_id, fkc.parent_column_id) AS COLUMN_NAME,
                OBJECT_NAME(fk.referenced_object_id) AS REFERENCED_TABLE,
                COL_NAME(fkc.referenced_object_id, fkc.referenced_column_id) AS REFERENCED_COLUMN
            FROM sys.foreign_keys fk
            JOIN sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
            WHERE OBJECT_NAME(fk.parent_object_id) = ?
        """, table)
        
        foreign_keys = []
        for row in cursor.fetchall():
            fk = {
                'name': row[0],
                'column': row[2],
                'referenced_table': row[3],
                'referenced_column': row[4]
            }
            foreign_keys.append(fk)
        
        schema[table] = {
            'columns': columns,
            'foreign_keys': foreign_keys
        }
    
    # Save schema
    output_file = os.path.join(base_dir, f'schemas/{provider_type}_schema.json')
    with open(output_file, 'w') as f:
        json.dump(schema, f, indent=2)
    
    print(f"\nSchema extracted successfully to {output_file}!")
    print(f"Total tables: {len(schema)}")
    
    conn.close()
    return schema

if __name__ == "__main__":
    import sys
    for provider_type in ['practitioner', 'practice', 'facility', 'reference']:
        extract_schema(provider_type)