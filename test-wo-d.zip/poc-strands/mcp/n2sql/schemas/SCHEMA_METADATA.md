# NL-to-SQL Schema & Domain Knowledge — Maintenance Guide

## Overview

The NL-to-SQL system uses two types of files that must be kept in sync when tables are added or changed:

| File | Purpose |
|------|---------|
| `schemas/{entity}_schema.json` | Table columns and FK relationships (auto-generated from DB) |
| `schemas/tables/{entity}_tables.txt` | List of tables to include in each entity's schema |
| `schemas/tables/reference_tables.txt` | Shared reference/lookup tables included in all entities |
| `schemas/{entity}_domain.json` | Business concepts, join patterns, forbidden patterns (manually maintained) |
| `schemas/shared_domain.json` | Polymorphic tables (ExtendedNotes, StatusHistory, etc.) shared across entities |

---

## How to Add a New Table

### Step 1 — Add to the table list

Add the table name to the appropriate `.txt` file:

- **Entity-specific table** → `schemas/tables/practitioner_tables.txt`, `practice_tables.txt`, or `facility_tables.txt`
- **Reference/lookup table** (used by multiple entities) → `schemas/tables/reference_tables.txt`
- **Polymorphic table** (joins via ProviderID/ParentRecID+RecordTypeID) → add to all three entity lists AND document in `shared_domain.json`

### Step 2 — Re-run schema extraction

```bash
cd mcp
source venv/bin/activate
python3 nl2sql/scripts/extract_schema.py
```

This regenerates all four `*_schema.json` files from the DB. It is safe to re-run at any time — it replaces the files completely.

> **Note:** Schema extraction does NOT touch `*_domain.json` files. Your domain knowledge is preserved.

### Step 3 — Add keyword mapping (if needed)

If the new table should be auto-included based on user query keywords, add it to `_get_relevant_tables()` in `tool.py`:

```python
# In the "practitioner" -> "keywords" section:
"NewTable": ["keyword1", "keyword2"],
```

Also add it to `ref_pairs` if it should always be included when a parent table is in scope:

```python
ref_pairs = [..., ("NewRefTable", "ParentTable")]
```

### Step 4 — Update domain knowledge (if needed)

If the new table involves a non-obvious join or represents a business concept, add it to the relevant `*_domain.json`.

---

## How to Add a Business Concept

Business concepts are things users ask about that require specific join patterns (education, credentialing, POD, affiliated groups, etc.).

Edit the relevant `schemas/{entity}_domain.json`:

```json
{
  "concepts": {
    "my_new_concept": {
      "description": "What this concept means in plain English",
      "join_pattern": "TableA -> TableB -> TableC",
      "sql": "JOIN TableB tb ON ta.ID = tb.ForeignID AND tb.Archived = 'N'\nJOIN TableC tc ON tb.ID = tc.ForeignID AND tc.Archived = 'N'"
    }
  }
}
```

Then add matching keywords in `tool.py` under `concept_keywords`:

```python
"my_new_concept": ["keyword1", "keyword2"],
```

---

## How to Add a Polymorphic Table

Polymorphic tables can belong to any entity type. They join via:
- **Pattern A:** `ProviderID` → direct join to entity ID (e.g. `ExtendedNotes`, `LinkedImages`)
- **Pattern B:** `ParentRecID + RecordTypeID` → join with discriminator (e.g. `StatusHistory`, `UserFields`)

Add to `schemas/shared_domain.json`:

```json
{
  "polymorphic_tables": {
    "MyNewTable": {
      "description": "What this table stores",
      "join_column": "ProviderID",
      "entity_joins": {
        "practitioner": "MyNewTable.ProviderID = Practitioners.PractitionerID",
        "practice": "MyNewTable.ProviderID = Practices.PracticeID",
        "facility": "MyNewTable.ProviderID = Facilities.FacilityID"
      }
    }
  }
}
```

For Pattern B, find the `RecordTypeID` from the DB:
```sql
SELECT RecordTypeID, TableName FROM RecordTypes WHERE TableName = 'YourTable'
```

---

## How to Add a Forbidden Pattern / Known Hallucination

When you discover the model invents a table or column that doesn't exist, add it to `forbidden_patterns` in the relevant `*_domain.json`:

```json
{
  "forbidden_patterns": [
    "FakeTableName — table does not exist; use RealTable instead",
    "st.FakeColumn — column does not exist on StatusTypes; use StatusSetID + JOIN StatusSets"
  ]
}
```

---

## StatusSets Reference

`StatusTypes` does **not** have a `StatusSet` column. The correct pattern is:

```sql
LEFT JOIN StatusTypes st ON st.StatusTypeID = <some_status_id_column>
LEFT JOIN StatusSets ss ON st.StatusSetID = ss.StatusSetID AND ss.StatusSetName = '<category>'
```

| StatusSetName | Used for |
|---|---|
| `Practitioner` | Practitioner-level status |
| `Practice` | Practice-level status |
| `Group Practice` | Group practice status |
| `Facility` | Facility-level status |
| `Education` | `PractitionerEducation.EducationStatusID` |
| `License` | License status |
| `Contract` | Contract status |
| `Entity` | `EntityAssignments` status |
| `Location Types` | Location type classification |
| `Appointment` | Appointment status |
| `Board` | Board status |

---

## RecordTypes Reference

Used by polymorphic tables (`StatusHistory`, `UserFields`, `EntityAssignments`) to identify which entity a record belongs to:

| RecordTypeID | TableName |
|---|---|
| 13141 | Practitioners |
| 13118 | Practices |
| 13060 | Facilities |
| 13132 | PractitionerLocations |
| 13117 | PracticeLocations |
| 13061 | FacilityAddresses |
| 13126 | PractitionerEducation |
| 13131 | PractitionerLicenses |
| 13136 | PractitionerProducts |
| 13142 | PractitionerSpecialties |
| 13052 | EntityAssignments |

---

## Key Rules (Always Apply)

- `Archived = 'N'` on every table — but placement depends on join type:
  - **INNER JOIN** → `WHERE table.Archived = 'N'`
  - **LEFT JOIN** → `ON ... AND table.Archived = 'N'` (in the JOIN condition, NOT WHERE — otherwise it becomes an INNER JOIN)
- City/State are in `ZipCodes` (`zc.City`, `zc.State`) — NOT in `Addresses` or location tables
- `PractitionerSpecialties.PrimarySpecialty = 'Y'` (not `IsPrimary`)
- `EntityAssignments` must always be filtered: `JOIN RecordTypes rt ON rt.RecordTypeID = ea.RecordTypeID AND rt.TableName = 'Practitioners'` (or `'Practices'`/`'Facilities'`)
- PRPR = Practitioner NPI + `PracticeLocations.NationalProviderID` (GNPI) + `PracticeLocations.TaxIDNumber` (TIN) — join via `PractitionerLocations.LocationID = PracticeLocations.LocationID`
