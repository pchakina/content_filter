FACILITY_PROMPT = """
{schema_context}

CRITICAL SCHEMA RULES - READ CAREFULLY:

1. StatusTypes Join:
   - StatusTypes does NOT have a "StatusSet" column — never use st.StatusSet
   - To filter by status category, join StatusSets: LEFT JOIN StatusSets ss ON st.StatusSetID = ss.StatusSetID AND ss.StatusSetName = 'Facility'
   - NEVER write: st.StatusSet = '...' — that column does not exist

2. Common Tables (shared across Practitioner/Practice/Facility):
   - UserDefinedFields, ExtendedNotes, Addresses, ZipCodes, Phones, Emails
   - Products, Contracts
   - These are NOT facility-specific

3. Geographic Data Location:
   - City: ONLY in ZipCodes.City (NOT in Addresses or FacilityAddresses)
   - State: ONLY in ZipCodes.State (NOT in Addresses or FacilityAddresses)
   - Always join through: ... -> Addresses -> ZipCodes to get City/State

CRITICAL Rules:
1. ALWAYS check the schema above for exact column names before writing SQL
2. Use ONLY tables and columns listed in schema - NEVER guess or invent names
3. Use simple JOINs - DO NOT use subqueries unless absolutely necessary
4. This is MS SQL Server - use TOP not LIMIT
5. LIMIT keyword does NOT exist in SQL Server - never use it
6. Use UNIQUE table aliases - never reuse the same alias
7. ALWAYS add "Archived = 'N'" — but placement depends on join type:
   - INNER JOIN tables: put Archived = 'N' in the WHERE clause
   - LEFT JOIN tables: put Archived = 'N' in the JOIN condition (ON clause), NOT in WHERE
   - CORRECT:   LEFT JOIN Products p ON fp.ProductID = p.ProductID AND p.Archived = 'N'
   - INCORRECT: LEFT JOIN Products p ON fp.ProductID = p.ProductID ... WHERE p.Archived = 'N'
8. Y/N fields use 'Y' or 'N' values, NOT 1 or 0
9. Return ONLY the SQL query with no explanations or comments
10. Each table can only be joined ONCE unless necessary like reference table
11. Products and Contracts in FacilityProducts is also called as Network information
12. Use LEFT JOIN for the reference table joins
13. StatusTypes does NOT have a StatusSet column. To filter by category use:
    LEFT JOIN StatusSets ss ON st.StatusSetID = ss.StatusSetID AND ss.StatusSetName = 'Facility'
14. WHERE clause must come AFTER all JOINs, never in the middle
15. Generated SQL should not have any syntax errors
16. Active records filtering - CHECK THE SCHEMA for actual date column names:
    - FacilityAddresses: DateFrom <= GETDATE() AND (DateTo IS NULL OR DateTo > GETDATE())
    - FacilityProducts: DateFrom <= GETDATE() AND (DateTo IS NULL OR DateTo > GETDATE())
    - Always verify column names in schema before using them

Join Patterns (MUST FOLLOW EXACTLY):
- Locations: Facilities -> FacilityAddresses -> Addresses -> ZipCodes
  IMPORTANT: City and State are in ZipCodes (zc.City, zc.State), NOT in other tables
- Products: Facilities -> FacilityProducts -> Products
- Network: Facilities -> FacilityProducts -> Products
- Contracts: FacilityProducts -> Contracts

FORBIDDEN:
- DO NOT use subqueries - use simple JOINs only
- DO NOT use tables not in schema
- DO NOT reuse table aliases
- DO NOT add comments in SQL

Example Query:

select TOP 10 f.FacilityID , f.NationalProviderID , f.TaxIDNumber , f.FacilityName , f.WebSite , ft.FacilityTypeName 
, fa.FacilityAddressRecID , fa.LocationName , fa.TaxIDNumber , fa.NationalProviderID , aty.AddressTypeName 
, addr.LineNumber1 , addr.LineNumber2 , zc.City , zc.County , zc.State, zc.ZipCode 
, pne.PhoneNumber , st.ServiceTypeName , prd.ProductName , prdt.ProductTypeName , ctr.ContractName 
from Facilities f 
	left join FacilityTypes ft on ft.FacilityTypeID = f.FacilityTypeID and ft.Archived = 'N'
join FacilityAddresses fa on (fa.FacilityID = f.FacilityID and fa.Archived = 'N')
	join AddressTypes aty on aty.Addresstypeid = fa.Addresstypeid and aty.Archived = 'N'
	join Addresses addr on addr.AddressID = fa.AddressID 
	join ZipCodes zc on zc.ZipCodeID = addr.ZipCodeID 
Join FacilityPhones fp on fp.FacilityAddressRecID = fa.FacilityAddressRecID and fp.Archived = 'N'
	join Phones pne on fp.PhoneID = pne.PhoneID 
	left join PhoneTypes pt on pt.PhoneTypeID = fp.PhoneTypeID and pt.Archived = 'N'
join FacilityLocationServices fls on fls.FacilityAddressRecID = fa.FacilityAddressRecID and fls.Archived = 'N'
	left join ServiceTypes st on st.ServiceTypeID = fls.ServiceTypeID and st.Archived = 'N'
join FacilityProducts fprd on fprd.FacilityAddressID = fa.FacilityAddressRecID and fprd.Archived = 'N'
	left join Products prd on prd.ProductID = fprd.ProductID and prd.Archived = 'N'
		left join ProductTypes prdt on prdt.ProductTypeID = prd.ProductTypeID and prdt.Archived = 'N'
	left join Contracts ctr on ctr.ContractID = fprd.ContractID and ctr.Archived = 'N';

SELECT TOP 2 
    f.FacilityID,
    f.FacilityName,
    a.City,
    z.ZipCode
FROM Facilities AS f
    JOIN FacilityAddresses AS fa ON f.FacilityID = fa.FacilityID
        JOIN Addresses AS a ON fa.AddressID = a.AddressID
        JOIN ZipCodes AS z ON a.ZipCodeID = z.ZipCodeID
WHERE 
    z.City = 'Austin' AND 
    z.State = 'TX' AND 
    f.Archived = 'N';



BUSINESS RULES:
- Duplicate records (locations, contracts, products): Records of the same type where DateFrom and DateTo overlap. Detect using a self-join: t1.DateFrom < t2.DateTo AND t2.DateFrom < t1.DateTo AND t1.PrimaryKeyID <> t2.PrimaryKeyID. Apply the appropriate type filter (e.g. AddressTypeName = 'Billing' for billing locations).
- Duplicate facility: More than one Facility record with the same NationalProviderID. Use GROUP BY NationalProviderID HAVING COUNT(*) > 1.
- Active record: DateFrom <= GETDATE() AND (DateTo IS NULL OR DateTo > GETDATE())

Now generate SQL for: {question}

SQL Query:"""