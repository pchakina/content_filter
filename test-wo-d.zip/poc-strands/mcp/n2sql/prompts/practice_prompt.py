PRACTICE_PROMPT = """
{schema_context}

CRITICAL SCHEMA RULES - READ CAREFULLY:

1. StatusTypes Join:
   - StatusTypes does NOT have a "StatusSet" column — never use st.StatusSet
   - To filter by status category, join StatusSets: LEFT JOIN StatusSets ss ON st.StatusSetID = ss.StatusSetID AND ss.StatusSetName = 'Practice'
   - NEVER write: st.StatusSet = '...' — that column does not exist

2. Common Tables (shared across Practitioner/Practice/Facility):
   - UserDefinedFields, ExtendedNotes, Addresses, ZipCodes, Phones, Emails
   - Products, Contracts
   - These are NOT practice-specific

3. Geographic Data Location:
   - City: ONLY in ZipCodes.City (NOT in Addresses or PracticeLocations)
   - State: ONLY in ZipCodes.State (NOT in Addresses or PracticeLocations)
   - Always join through: ... -> Addresses -> ZipCodes to get City/State

CRITICAL Rules:
1. ALWAYS check the schema above for exact column names before writing SQL
2. Use ONLY tables and columns listed in schema - NEVER guess or invent names
3. Use simple JOINs - DO NOT use subqueries unless absolutely necessary
4. This is MS SQL Server - use TOP not LIMIT
5. Use UNIQUE table aliases - never reuse the same alias
6. ALWAYS add "Archived = 'N'" — but placement depends on join type:
   - INNER JOIN tables: put Archived = 'N' in the WHERE clause
   - LEFT JOIN tables: put Archived = 'N' in the JOIN condition (ON clause), NOT in WHERE
   - CORRECT:   LEFT JOIN Products p ON pp.ProductID = p.ProductID AND p.Archived = 'N'
   - INCORRECT: LEFT JOIN Products p ON pp.ProductID = p.ProductID ... WHERE p.Archived = 'N'
7. Return ONLY the SQL query with no explanations or comments

Join Patterns (MUST FOLLOW EXACTLY):
- Locations: Practices -> PracticeLocations -> Addresses -> ZipCodes
- Products: Practices -> PracticeProducts -> Products
- Contracts: PracticeProducts -> Contracts

BUSINESS RULES:
- Duplicate records (locations, contracts, products): Records of the same type where DateFrom and DateTo overlap. Detect using a self-join: t1.DateFrom < t2.DateTo AND t2.DateFrom < t1.DateTo AND t1.PrimaryKeyID <> t2.PrimaryKeyID. Apply the appropriate type filter (e.g. LocationTypeName = 'Billing' for billing locations).
- Duplicate practice: More than one Practice record with the same TaxIDNumber. Use GROUP BY TaxIDNumber HAVING COUNT(*) > 1.
- Active record: DateFrom <= GETDATE() AND (DateTo IS NULL OR DateTo > GETDATE())

Now generate SQL for: {question}

SQL Query:"""