PRACTITIONER_PROMPT = """
{schema_context}

CRITICAL SCHEMA RULES - READ CAREFULLY:

1. StatusTypes Join:
   - StatusTypes does NOT have a "StatusSet" column — never use st.StatusSet
   - To filter by status category, join StatusSets: LEFT JOIN StatusSets ss ON st.StatusSetID = ss.StatusSetID AND ss.StatusSetName = 'Education'
   - StatusSetName values: 'Practitioner', 'Practice', 'Facility', 'Education', 'License', 'Contract', 'Entity'
   - NEVER write: st.StatusSet = '...' — that column does not exist

2. Common Tables (shared across Practitioner/Practice/Facility):
   - UserDefinedFields, ExtendedNotes, Addresses, ZipCodes, Phones, Emails
   - Products, Contracts
   - These are NOT practitioner-specific

3. Geographic Data Location:
   - City: ONLY in ZipCodes.City (NOT in Addresses or PracticeLocations)
   - State: ONLY in ZipCodes.State (NOT in Addresses or PracticeLocations)
   - Always join through: ... -> Addresses -> ZipCodes to get City/State

4. Primary Flags (exact column names):
   - PractitionerSpecialties.PrimarySpecialty = 'Y' (column is "PrimarySpecialty" NOT "IsPrimary")

CRITICAL Rules:
1. ALWAYS check the schema above for exact column names before writing SQL
2. Use ONLY tables and columns listed in schema - NEVER guess or invent names
3. Use simple JOINs - DO NOT use subqueries unless absolutely necessary
4. This is MS SQL Server - use TOP not LIMIT (e.g., SELECT TOP 100 * FROM...)
5. LIMIT keyword does NOT exist in SQL Server - never use it
6. Use UNIQUE table aliases - never reuse the same alias
7. ALWAYS add "Archived = 'N'" — but placement depends on join type:
   - INNER JOIN tables: put Archived = 'N' in the WHERE clause
   - LEFT JOIN tables: put Archived = 'N' in the JOIN condition (ON clause), NOT in WHERE
   - Reason: putting LEFT JOIN table filters in WHERE converts it to an INNER JOIN, returning no rows when the left-joined record is NULL
   - CORRECT:   LEFT JOIN Institutions inst ON pe.InstitutionID = inst.InstitutionID AND inst.Archived = 'N'
   - INCORRECT: LEFT JOIN Institutions inst ON pe.InstitutionID = inst.InstitutionID ... WHERE inst.Archived = 'N'
8. Y/N fields use 'Y' or 'N' values, NOT 1 or 0
9. Return ONLY the SQL query with no explanations or comments
10. Each table can only be joined ONCE unless necessary like reference table
11. Products and Contracts in PractitionerProducts is also called as Network information
12. Use LEFT JOIN for the reference table joins
13. StatusTypes does NOT have a StatusSet column. To filter by category use:
    LEFT JOIN StatusSets ss ON st.StatusSetID = ss.StatusSetID AND ss.StatusSetName = 'Education'
    (replace 'Education' with the relevant category from: Practitioner, Practice, Facility, License, Contract, Entity)
14. WHERE clause must come AFTER all JOINs, never in the middle
15. Generated SQL should not have any syntax errors
16. Active records date filtering — ONLY apply to these specific tables, DO NOT add date filters to any other table:
    - PractitionerLocations: DateFrom <= GETDATE() AND (DateTo IS NULL OR DateTo > GETDATE())
    - PractitionerProducts: DateFrom <= GETDATE() AND (DateTo IS NULL OR DateTo > GETDATE())
    - PractitionerSpecialties: ExpirationDate IS NULL OR ExpirationDate > GETDATE()
    - DO NOT add date filters to PractitionerEducation, PractitionerLicenses, EntityAssignments, or any other table unless the user explicitly asks for active/current records

Join Patterns (MUST FOLLOW EXACTLY):
- Specialties: Practitioners -> PractitionerSpecialties -> Specialties
  IMPORTANT: Primary specialty filter uses ps.PrimarySpecialty = 'Y' (NOT IsPrimary)
- Languages: Practitioners -> PractitionerLanguages -> Languages  
- Education Institution: Practitioners -> PractitionerEducation -> Institutions (inst.InstitutionName)
- Education Degree: Practitioners -> PractitionerEducation -> Degrees (deg.DegreeName)
- Locations: Practitioners -> PractitionerLocations -> PracticeLocations -> Addresses -> ZipCodes
  IMPORTANT: City and State are in ZipCodes (zc.City, zc.State), NOT in other tables
- Products: PractitionerLocations -> PractitionerProducts -> Products (pr.ProductName)
- Contracts: PractitionerLocations -> PractitionerProducts -> Contracts (on ContractID)
- Network: PractitionerLocations -> PractitionerProducts -> Products (pr.ProductName)
- EntityAssignments: Practitioners.PractitionerID = EntityAssignments.ProviderID AND EntityAssignments.ParentRecID = Practitioners.PractitionerID, JOIN RecordTypes rt ON rt.RecordTypeID = EntityAssignments.RecordTypeID AND rt.TableName = 'Practitioners'

FORBIDDEN:
- DO NOT use subqueries - use simple JOINs only
- DO NOT use tables not in schema
- DO NOT reuse table aliases
- DO NOT add comments in SQL

Example Query:
SELECT 
  p.PractitionerID, p.LastName, p.FirstName,
  s.SpecialtyName,
  lang.LanguageName,
  inst.InstitutionName, deg.DegreeName,
  plc.LocationName, ad.LineNumber1, zc.City, zc.State, zc.ZipCode,
  pr.ProductName,
  c.ContractNumber
FROM Practitioners p 
JOIN PractitionerSpecialties ps ON p.PractitionerID = ps.PractitionerID AND ps.Archived = 'N'
  LEFT JOIN Specialties s ON ps.SpecialtyID = s.SpecialtyID AND s.Archived = 'N'
JOIN PractitionerLanguages pLang ON p.PractitionerID = pLang.PractitionerID AND pLang.Archived = 'N'
  LEFT JOIN Languages lang ON pLang.LanguageID = lang.LanguageID AND lang.Archived = 'N'
JOIN PractitionerEducation ed ON p.PractitionerID = ed.PractitionerID AND ed.Archived = 'N'
  LEFT JOIN Institutions inst ON ed.InstitutionID = inst.InstitutionID AND inst.Archived = 'N'
  LEFT JOIN Degrees deg ON ed.DegreeID = deg.DegreeID AND deg.Archived = 'N'
JOIN PractitionerLocations pracLoc ON p.PractitionerID = pracLoc.PractitionerID AND pracLoc.Archived = 'N'
  JOIN PracticeLocations plc ON pracLoc.LocationID = plc.LocationID AND plc.Archived = 'N'
    LEFT JOIN Addresses ad ON plc.AddressID = ad.AddressID AND ad.Archived = 'N'
      LEFT JOIN ZipCodes zc ON ad.ZipCodeID = zc.ZipCodeID AND zc.Archived = 'N'
  JOIN PractitionerProducts pp ON pracLoc.PractitionerLocationRecID = pp.PractitionerLocationRecID AND pp.Archived = 'N'
    LEFT JOIN Products pr ON pp.ProductID = pr.ProductID AND pr.Archived = 'N'
    LEFT JOIN Contracts c ON pp.ContractID = c.ContractID AND c.Archived = 'N'
LEFT JOIN PractitionerEmails peml ON p.PractitionerID = peml.PractitionerID AND peml.Archived = 'N'
  LEFT JOIN Emails eml ON eml.EmailID = peml.EmailID AND eml.Archived = 'N'
  LEFT JOIN EmailTypes emlt ON emlt.EmailTypeID = peml.EmailTypeID AND emlt.Archived = 'N'
WHERE p.Archived = 'N'
AND p.NationalProviderID = '1234567890'

BUSINESS RULES:
- Duplicate records (locations, contracts, products): Records of the same type where DateFrom and DateTo overlap. Detect using a self-join: t1.DateFrom < t2.DateTo AND t2.DateFrom < t1.DateTo AND t1.PrimaryKeyID <> t2.PrimaryKeyID. Apply the appropriate type filter (e.g. LocationTypeName = 'Billing' for billing locations).
- Duplicate practitioner: More than one Practitioner record with the same NationalProviderID. Use GROUP BY NationalProviderID HAVING COUNT(*) > 1.
- Active record: DateFrom <= GETDATE() AND (DateTo IS NULL OR DateTo > GETDATE())

Now generate SQL for: {question}

SQL Query:"""