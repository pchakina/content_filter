Provider API
FastAPI application for querying provider data from MS-SQL Server.

Setup
Copy .env.example to .env and configure database credentials
Install dependencies: pip install -r requirements.txt
Run: uvicorn main:app --reload
Endpoints
Root
GET / - Health check
Practitioner
GET /practitioner/search - Search practitioners by FirstName, LastName, or NationalProviderID
GET /practitioner/demographics/{PractitionerID} - Get demographics by ID
GET /practitioner/by-npi/{NationalProviderID} - Get practitioner by NPI
GET /practitioner/specialties/{PractitionerID} - Get practitioner specialties
GET /practitioner/licenses/{PractitionerID} - Get practitioner licenses
GET /practitioner/locations/{PractitionerID} - Get practitioner locations (paginated)
GET /practitioner/locations/search - Search practitioner locations by PractitionerID/NPI, State, City, ZipCode, etc. (paginated)
GET /practitioner/products/search - Search practitioner products by PractitionerID/NPI, LocationName, ProductName, ContractName, etc. (paginated)
Practice
GET /practice/search - Search practices by PracticeName or TaxIDNumber
GET /practice/demographics/{PracticeID} - Get demographics by ID
GET /practice/by-tin/{TaxIDNumber} - Get practice by TIN
GET /practice/locations/search - Search practice locations by PracticeID/TIN/NPI, LocationName, State, City, etc. (paginated)
GET /practice/location/services - Get practice location services by LocationID or NationalProviderID
GET /practice/location/licenses - Get practice location licenses by LocationID or NationalProviderID
Facility
GET /facility/search - Search facilities by name
GET /facility/demographics/{FacilityID} - Get demographics by ID
GET /facility/by-npi/{NationalProviderID} - Get facility by NPI
GET /facility/licenses/{FacilityID} - Get facility licenses
GET /facility/locations/search - Search facility locations by FacilityID/NPI, LocationName, State, City, etc. (paginated)
GET /facility/products/search - Search facility products by FacilityID/TIN, ProductCode, ProductName, ContractName, etc. (paginated)
Docker
Build: docker build -t provider-api . Run: docker run -p 8000:8000 --env-file .env provider-api