from sqlalchemy import create_engine
from sqlalchemy.pool import QueuePool
import logging
from config import settings

logger = logging.getLogger(__name__)

# Create engine with connection pooling
engine = create_engine(
    f"mssql+pyodbc:///?odbc_connect={settings.connection_string}",
    poolclass=QueuePool,
    pool_size=5,
    max_overflow=10,
    pool_pre_ping=True,
    pool_recycle=3600
)

def execute_query(query: str, params: tuple = None):
    try:
        logger.debug(f"Executing query: {query}")
        raw_conn = engine.raw_connection()
        try:
            cursor = raw_conn.cursor()
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            columns = [column[0] for column in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            return results
        finally:
            raw_conn.close()
    except Exception as e:
        err = str(e)
        # Broken pipe / stale connection — invalidate pool and retry once
        if "08S01" in err or "0x20" in err or "TCP Provider" in err:
            logger.warning("DB connection lost, invalidating pool and retrying")
            engine.dispose()
            raw_conn = engine.raw_connection()
            try:
                cursor = raw_conn.cursor()
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)
                columns = [column[0] for column in cursor.description]
                return [dict(zip(columns, row)) for row in cursor.fetchall()]
            finally:
                raw_conn.close()
        logger.error(f"Query execution failed: {e}", exc_info=True)
        raise