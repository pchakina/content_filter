from enum import Enum
from typing import Optional, Dict, Any
from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse


class ErrorCode(str, Enum):
    # Client errors (4xx)
    MISSING_REQUIRED_PARAMETER = "MISSING_REQUIRED_PARAMETER"
    INVALID_PARAMETER_VALUE = "INVALID_PARAMETER_VALUE"
    RESOURCE_NOT_FOUND = "RESOURCE_NOT_FOUND"
    MULTIPLE_RESULTS_FOUND = "MULTIPLE_RESULTS_FOUND"
    
    # Server errors (5xx)
    DATABASE_ERROR = "DATABASE_ERROR"
    INTERNAL_ERROR = "INTERNAL_ERROR"


class StandardError(HTTPException):
    def __init__(
        self,
        status_code: int,
        error_code: ErrorCode,
        message: str,
        details: Optional[Dict[str, Any]] = None
    ):
        self.error_code = error_code
        self.message = message
        self.details = details or {}
        super().__init__(status_code=status_code, detail=message)


class ResourceNotFoundError(StandardError):
    def __init__(self, resource: str, identifier: Any, identifier_type: str):
        super().__init__(
            status_code=404,
            error_code=ErrorCode.RESOURCE_NOT_FOUND,
            message=f"{resource.capitalize()} with {identifier_type} '{identifier}' not found",
            details={
                "resource": resource,
                "identifier": str(identifier),
                "identifier_type": identifier_type
            }
        )


class MissingRequiredParameterError(StandardError):
    def __init__(self, parameters: list[str], message: Optional[str] = None):
        default_message = f"At least one of the following parameters is required: {', '.join(parameters)}"
        super().__init__(
            status_code=400,
            error_code=ErrorCode.MISSING_REQUIRED_PARAMETER,
            message=message or default_message,
            details={
                "required_parameters": parameters
            }
        )


class DatabaseError(StandardError):
    def __init__(self, operation: str, original_error: Optional[str] = None):
        super().__init__(
            status_code=500,
            error_code=ErrorCode.DATABASE_ERROR,
            message=f"Database error during {operation}",
            details={
                "operation": operation,
                "original_error": original_error
            }
        )


async def standard_error_handler(request: Request, exc: StandardError):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": {
                "code": exc.error_code,
                "message": exc.message,
                "type": exc.__class__.__name__,
                "details": exc.details
            }
        }
    )


async def http_exception_handler(request: Request, exc: HTTPException):
    # Convert generic HTTPException to standard format
    error_code = ErrorCode.INTERNAL_ERROR
    if exc.status_code == 404:
        error_code = ErrorCode.RESOURCE_NOT_FOUND
    elif exc.status_code == 400:
        error_code = ErrorCode.INVALID_PARAMETER_VALUE
    
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": {
                "code": error_code,
                "message": exc.detail,
                "type": "HTTPException",
                "details": {}
            }
        }
    )


async def general_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": ErrorCode.INTERNAL_ERROR,
                "message": "An unexpected error occurred",
                "type": exc.__class__.__name__,
                "details": {
                    "error": str(exc)
                }
            }
        }
    )