FACILITY_DEMOGRAPHICS = """
SELECT 
    FacilityID, FacilityName, FacilityTypeName, 
    TaxIDNumber, NationalProviderID, LegalName,
    FacilityStatus, ApplicationStatus,
    CAST(AttestationDate AS DATE) AS AttestationDate,
    WebSite,
    CAST(FacilityStatusEffectiveDate AS DATE) AS FacilityStatusEffectiveDate,
    CAST(ApplicationStatusEffectiveDate AS DATE) AS ApplicationStatusEffectiveDate
FROM vwFacilities
WHERE FacilityID = ? AND Archived = 'N'
"""

FACILITY_BY_NPI = """
SELECT 
    FacilityID, FacilityName, FacilityTypeName, 
    TaxIDNumber, NationalProviderID, LegalName,
    FacilityStatus, ApplicationStatus,
    CAST(AttestationDate AS DATE) AS AttestationDate,
    WebSite,
    CAST(FacilityStatusEffectiveDate AS DATE) AS FacilityStatusEffectiveDate,
    CAST(ApplicationStatusEffectiveDate AS DATE) AS ApplicationStatusEffectiveDate
FROM vwFacilities
WHERE NationalProviderID = ? AND Archived = 'N'
"""

FACILITY_SEARCH = """
SELECT 
    FacilityID, FacilityName, FacilityTypeName, 
    TaxIDNumber, NationalProviderID, LegalName,
    FacilityStatus, ApplicationStatus,
    CAST(AttestationDate AS DATE) AS AttestationDate,
    WebSite,
    CAST(FacilityStatusEffectiveDate AS DATE) AS FacilityStatusEffectiveDate,
    CAST(ApplicationStatusEffectiveDate AS DATE) AS ApplicationStatusEffectiveDate
FROM vwFacilities
WHERE Archived = 'N'
"""

FACILITY_CREDENTIALING = """
SELECT
    ea.EntityAssignmentRecID, e.EntityName,
    st_ent.StatusTypeName AS EntityStatus,
    st_app.StatusTypeName AS ApplicationStatus,
    CAST(ea.ApplicationStatusEffectiveDate AS DATE) AS ApplicationStatusEffectiveDate,
    CAST(ea.DateFrom AS DATE) AS DateFrom,
    CAST(ea.DateTo AS DATE) AS DateTo,
    CAST(ea.RenewalDate AS DATE) AS RenewalDate,
    CAST(ea.AppointedDate AS DATE) AS AppointedDate,
    CAST(ea.AttestationDate AS DATE) AS AttestationDate,
    ea.Notes
FROM EntityAssignments ea
JOIN RecordTypes rt ON rt.RecordTypeID = ea.RecordTypeID AND rt.TableName = 'Facilities'
LEFT JOIN Entities e ON e.EntityID = ea.EntityID AND e.Archived = 'N'
LEFT JOIN StatusTypes st_ent ON st_ent.StatusTypeID = ea.StatusTypeID AND st_ent.Archived = 'N'
LEFT JOIN StatusTypes st_app ON st_app.StatusTypeID = ea.ApplicationStatusTypeID AND st_app.Archived = 'N'
WHERE ea.ProviderID = ? AND ea.ParentRecID = ? AND ea.Archived = 'N'
ORDER BY ea.DateFrom DESC
"""

FACILITY_QI_ACTIVITIES = """
SELECT
    fqi.FacilityQIActivityRecID,
    qit.QualityIndicatorTypeName, qit.QualityIndicatorTypeCode,
    qct.QualityCategoryTypeName, qct.QualityCategoryTypeCode,
    CAST(fqi.DateFrom AS DATE) AS DateFrom,
    CAST(fqi.DateTo AS DATE) AS DateTo,
    fqi.Notes
FROM FacilityQIActivities fqi
JOIN QualityIndicatorTypes qit ON qit.QualityIndicatorTypeID = fqi.QualityIndicatorTypeID AND qit.Archived = 'N'
JOIN QualityCategoryTypes qct ON qct.QualityCategoryTypeID = fqi.QualityCategoryTypeID AND qct.Archived = 'N'
WHERE fqi.FacilityID = ? AND fqi.Archived = 'N'
ORDER BY fqi.DateFrom DESC
"""

FACILITY_LOCATIONS_SEARCH_BASE = """
SELECT 
    FacilityAddressRecID, FacilityName, LocationName,
    TaxIDNumber, NationalProviderID, AddressTypeName,
    CAST(DateFrom AS DATE) AS DateFrom,
    CAST(DateTo AS DATE) AS DateTo,
    LineNumber1, LineNumber2, City, State, ZipCode,
    County, PrimaryContactAddress
FROM vwFacilityAddresses
WHERE Archived = 'N'
"""

FACILITY_LICENSES = """
SELECT 
    FacilityLicenseRecID, FacilityName, LocationName,
    LicenseTypeName, LicenseSubTypeName, LicenseNumber,
    IssuingState, PrimaryLicense,
    CAST(IssueDate AS DATE) AS IssueDate,
    CAST(ExpirationDate AS DATE) AS ExpirationDate,
    LicenseStatusTypeName, DisciplinaryAction, ActiveStatePractice
FROM vwFacilityLicenses
WHERE FacilityID = ? AND Archived = 'N'
"""

FACILITY_PRODUCTS_SEARCH_BASE = """
SELECT 
    FacilityProductRecID, FacilityName, LocationName,
    ProductCode, ProductName, ProductTypeName,
    StatusTypeName AS Active, ContractName,
    CAST(DateFrom AS DATE) AS DateFrom,
    CAST(DateTo AS DATE) AS DateTo,
    LineNumber1, LineNumber2, City, State, ZipCode,
    AddressTypeName, NetworkName, ProviderNumber
FROM vwFacilityProducts
WHERE Archived = 'N'
"""