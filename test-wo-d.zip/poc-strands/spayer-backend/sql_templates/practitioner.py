PRACTITIONER_DEMOGRAPHICS = """
SELECT 
    p.PractitionerID, p.NationalProviderID, p.FirstName, p.LastName, 
    p.MiddleName, ps.GenderName, CAST(p.BirthDate AS DATE) AS BirthDate,
    p.ActiveMilitaryOrReserve AS InDirectory,
    ps.PractitionerTypeName, ps.PractitionerStatus, ps.ApplicationStatus,
    CAST(ps.PractitionerStatusEffectiveDate AS DATE) AS PractitionerStatusEffectiveDate,
    CAST(ps.ApplicationStatusEffectiveDate AS DATE) AS ApplicationStatusEffectiveDate
FROM practitioners p
LEFT JOIN vwPractitionerSummary ps ON ps.PractitionerID = p.PractitionerID
WHERE p.PractitionerID = ? AND p.Archived = 'N'
"""

PRACTITIONER_BY_NPI = """
SELECT 
    p.PractitionerID, p.NationalProviderID, p.FirstName, p.LastName, 
    p.MiddleName, ps.GenderName, CAST(p.BirthDate AS DATE) AS BirthDate,
    p.ActiveMilitaryOrReserve AS InDirectory,
    ps.PractitionerTypeName, ps.PractitionerStatus, ps.ApplicationStatus,
    CAST(ps.PractitionerStatusEffectiveDate AS DATE) AS PractitionerStatusEffectiveDate,
    CAST(ps.ApplicationStatusEffectiveDate AS DATE) AS ApplicationStatusEffectiveDate
FROM practitioners p
LEFT JOIN vwPractitionerSummary ps ON ps.PractitionerID = p.PractitionerID
WHERE p.NationalProviderID = ? AND p.Archived = 'N'
"""

PRACTITIONER_SEARCH = """
SELECT 
    p.PractitionerID, p.NationalProviderID, p.FirstName, p.LastName, 
    p.MiddleName, ps.GenderName, CAST(p.BirthDate AS DATE) AS BirthDate,
    p.ActiveMilitaryOrReserve AS InDirectory,
    ps.PractitionerTypeName, ps.PractitionerStatus, ps.ApplicationStatus,
    CAST(ps.PractitionerStatusEffectiveDate AS DATE) AS PractitionerStatusEffectiveDate,
    CAST(ps.ApplicationStatusEffectiveDate AS DATE) AS ApplicationStatusEffectiveDate
FROM practitioners p
LEFT JOIN vwPractitionerSummary ps ON ps.PractitionerID = p.PractitionerID
WHERE p.Archived = 'N'
"""

PRACTITIONER_SPECIALTIES = """
SELECT 
    ps.PractitionerSpecialtyRecID, s.SpecialtyName, ps.PrimarySpecialty,
    ps.BoardCertified, ps.CertificationNumber, 
    CAST(ps.CertificationDate AS DATE) AS CertificationDate,
    CAST(ps.RecertificationDate AS DATE) AS RecertificationDate,
    CAST(ps.ExpirationDate AS DATE) AS ExpirationDate
FROM PractitionerSpecialties ps
LEFT JOIN Specialties s ON s.SpecialtyID = ps.SpecialtyID
WHERE ps.PractitionerID = ? AND ps.Archived = 'N' AND s.Archived = 'N'
"""

PRACTITIONER_LICENSES = """
SELECT 
    pl.PractitionerLicenseRecID, lt.LicenseTypeName, lst.LicenseSubTypeName,
    pl.LicenseNumber, pl.IssuingState, pl.PrimaryLicense,
    CAST(pl.IssueDate AS DATE) AS IssueDate,
    CAST(pl.ExpirationDate AS DATE) AS ExpirationDate,
    pl.DisciplinaryAction, pl.ActiveStatePractice
FROM PractitionerLicenses pl
LEFT JOIN LicenseTypes lt ON lt.LicenseTypeID = pl.LicenseTypeID
LEFT JOIN LicenseSubTypes lst ON lst.LicenseSubTypeID = pl.LicenseSubTypeID
WHERE pl.PractitionerID = ? AND pl.Archived = 'N'
"""

PRACTITIONER_LANGUAGES = """
SELECT pl.PractitionerLanguageRecID, lang.LanguageName from PractitionerLanguages pl 
	JOIN Languages lang ON lang.LanguageID = pl.LanguageID AND lang.Archived = 'N'
	WHERE pl.PractitionerID = ? AND pl.Archived = 'N'
	order by lang.LanguageName asc
"""

PRACTITIONER_EDUCATION = """
SELECT
    pe.PractitionerEducationRecID, et.EducationTypeName,
    inst.InstitutionName, deg.DegreeName, deg.DegreeCode,
    CAST(pe.DateFrom AS DATE) AS DateFrom,
    CAST(pe.DateTo AS DATE) AS DateTo,
    pe.Completed, pe.GMEProgramName, pe.DirectorName, pe.Notes,
    st.StatusTypeName AS EducationStatus
FROM PractitionerEducation pe
LEFT JOIN EducationTypes et ON et.EducationTypeID = pe.EducationTypeID AND et.Archived = 'N'
LEFT JOIN Institutions inst ON inst.InstitutionID = pe.InstitutionID AND inst.Archived = 'N'
LEFT JOIN Degrees deg ON deg.DegreeID = pe.DegreeID AND deg.Archived = 'N'
LEFT JOIN StatusTypes st ON st.StatusTypeID = pe.EducationStatusID AND st.Archived = 'N'
WHERE pe.PractitionerID = ? AND pe.Archived = 'N'
ORDER BY pe.DateFrom DESC
"""

PRACTITIONER_CREDENTIALING = """
SELECT
    ea.EntityAssignmentRecID, e.EntityName,
    st_ent.StatusTypeName AS EntityStatus,
    st_app.StatusTypeName AS ApplicationStatus,
    CAST(ea.ApplicationStatusEffectiveDate AS DATE) AS ApplicationStatusEffectiveDate,
    CAST(ea.DateFrom AS DATE) AS DateFrom,
    CAST(ea.DateTo AS DATE) AS DateTo,
    CAST(ea.RenewalDate AS DATE) AS RenewalDate,
    CAST(ea.AppointedDate AS DATE) AS AppointedDate,
    CAST(ea.AttestationDate AS DATE) AS AttestationDate,
    ea.Notes
FROM EntityAssignments ea
JOIN RecordTypes rt ON rt.RecordTypeID = ea.RecordTypeID AND rt.TableName = 'Practitioners'
LEFT JOIN Entities e ON e.EntityID = ea.EntityID AND e.Archived = 'N'
LEFT JOIN StatusTypes st_ent ON st_ent.StatusTypeID = ea.StatusTypeID AND st_ent.Archived = 'N'
LEFT JOIN StatusTypes st_app ON st_app.StatusTypeID = ea.ApplicationStatusTypeID AND st_app.Archived = 'N'
WHERE ea.ProviderID = ? AND ea.ParentRecID = ? AND ea.Archived = 'N'
ORDER BY ea.DateFrom DESC
"""

PRACTITIONER_QI_ACTIVITIES = """
SELECT
    pqi.PractitionerQIActivityRecID,
    qit.QualityIndicatorTypeName, qit.QualityIndicatorTypeCode,
    qct.QualityCategoryTypeName, qct.QualityCategoryTypeCode,
    CAST(pqi.DateFrom AS DATE) AS DateFrom,
    CAST(pqi.DateTo AS DATE) AS DateTo,
    pqi.Notes
FROM PractitionerQIActivities pqi
JOIN QualityIndicatorTypes qit ON qit.QualityIndicatorTypeID = pqi.QualityIndicatorTypeID AND qit.Archived = 'N'
JOIN QualityCategoryTypes qct ON qct.QualityCategoryTypeID = pqi.QualityCategoryTypeID AND qct.Archived = 'N'
WHERE pqi.PractitionerID = ? AND pqi.Archived = 'N'
ORDER BY pqi.DateFrom DESC
"""

PRACTITIONER_LOCATIONS = """
SELECT 
    PractitionerLocationRecID, PracticeName, LocationName,
    PrimaryLocation, AcceptingPatients,
    CAST(DateFrom AS DATE) AS DateFrom,
    CAST(DateTo AS DATE) AS DateTo,
    LineNumber1, LineNumber2, City, State, ZipCode,
    County, Latitude, Longitude
FROM vwPractitionerLocations
WHERE PractitionerID = ? AND Archived = 'N'
ORDER BY PrimaryLocation DESC, DateFrom DESC
OFFSET ? ROWS FETCH NEXT ? ROWS ONLY
"""

PRACTITIONER_LOCATIONS_COUNT = """
SELECT COUNT(*) as total
FROM vwPractitionerLocations
WHERE PractitionerID = ? AND Archived = 'N'
"""

PRACTITIONER_LOCATIONS_SEARCH_BASE = """
SELECT 
    PractitionerLocationRecID, PracticeName, LocationName,
    PrimaryLocation, AcceptingPatients,
    CAST(DateFrom AS DATE) AS DateFrom,
    CAST(DateTo AS DATE) AS DateTo,
    LineNumber1, LineNumber2, City, State, ZipCode,
    County, Latitude, Longitude
FROM vwPractitionerLocations
WHERE Archived = 'N'
"""

PRACTITIONER_PRODUCTS_SEARCH_BASE = """
SELECT 
    pp.PractitionerProductRecID, pp.PractitionerID, vpl.NationalProviderID,
    vpl.PractitionerLocationRecID, vpl.LocationName,
    CAST(pp.DateFrom AS DATE) AS DateFrom,
    CAST(pp.DateTo AS DATE) AS DateTo,
    CAST(pp.TerminationDate AS DATE) AS TerminationDate,
    vpl.LineNumber1, vpl.LineNumber2, vpl.City, vpl.State, vpl.ZipCode,
    tt.TerminationTypeName, st.StatusTypeName, ppl.ProductPopulationName,
    p.ProductName, p.ProductCode, pt.ProductTypeName,
    c.ContractName
FROM PractitionerProducts pp
JOIN vwPractitionerLocations vpl ON vpl.PractitionerLocationRecID = pp.PractitionerLocationRecID
LEFT JOIN Products p ON p.ProductID = pp.ProductID
LEFT JOIN ProductTypes pt ON pt.ProductTypeID = p.ProductTypeID
LEFT JOIN Contracts c ON c.ContractID = pp.ContractID
LEFT JOIN TerminationTypes tt ON tt.TerminationTypeID = pp.TerminationTypeID
LEFT JOIN StatusTypes st ON st.StatusTypeID = pp.StatusTypeID
LEFT JOIN ProductPopulations ppl ON ppl.ProductPopulationID = pp.ProductPopulationID
WHERE pp.Archived = 'N'
"""


PRACTITIONER_GROUP_AFFILIATIONS = """
SELECT DISTINCT
    g.PracticeID, g.PracticeName, g.TaxIDNumber AS GroupTIN,
    gl.LocationID, pl.PractitionerLocationRecID, gl.LocationName,
    gl.NationalProviderID AS GNPI,
    a.LineNumber1, a.LineNumber2, z.City, z.State, z.ZipCode
FROM Practitioners p
JOIN PractitionerLocations pl ON pl.PractitionerID = p.PractitionerID AND pl.Archived = 'N'
JOIN PracticeLocations gl ON gl.LocationID = pl.LocationID AND gl.Archived = 'N'
JOIN Practices g ON g.PracticeID = gl.PracticeID AND g.Archived = 'N'
LEFT JOIN Addresses a ON a.AddressID = gl.AddressID AND a.Archived = 'N'
LEFT JOIN ZipCodes z ON z.ZipCodeID = a.ZipCodeID AND z.Archived = 'N'
WHERE p.Archived = 'N'
"""