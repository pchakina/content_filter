PRACTICE_DEMOGRAPHICS = """
SELECT 
    PracticeID, PracticeName, PracticeTypeName, 
    TaxIDNumber, NationalProviderID, LegalName,
    ElectronicBillingCapability, PracticeStatus,
    CAST(PracticeStatusEffectiveDate AS DATE) AS PracticeStatusEffectiveDate,
    LocationCount, PractitionerCount,
    ApplicationStatus,
    CAST(ApplicationStatusEffectiveDate AS DATE) AS ApplicationStatusEffectiveDate
FROM vwPractices
WHERE PracticeID = ? AND Archived = 'N'
"""

PRACTICE_BY_TIN = """
SELECT 
    PracticeID, PracticeName, PracticeTypeName, 
    TaxIDNumber, NationalProviderID, LegalName,
    ElectronicBillingCapability, PracticeStatus,
    CAST(PracticeStatusEffectiveDate AS DATE) AS PracticeStatusEffectiveDate,
    LocationCount, PractitionerCount,
    ApplicationStatus,
    CAST(ApplicationStatusEffectiveDate AS DATE) AS ApplicationStatusEffectiveDate
FROM vwPractices
WHERE TaxIDNumber = ? AND Archived = 'N'
"""

PRACTICE_SEARCH = """
SELECT 
    PracticeID, PracticeName, PracticeTypeName, 
    TaxIDNumber, NationalProviderID, LegalName,
    ElectronicBillingCapability, PracticeStatus,
    CAST(PracticeStatusEffectiveDate AS DATE) AS PracticeStatusEffectiveDate,
    LocationCount, PractitionerCount,
    ApplicationStatus,
    CAST(ApplicationStatusEffectiveDate AS DATE) AS ApplicationStatusEffectiveDate
FROM vwPractices
WHERE Archived = 'N'
"""

PRACTICE_CREDENTIALING = """
SELECT
    ea.EntityAssignmentRecID, e.EntityName,
    st_ent.StatusTypeName AS EntityStatus,
    st_app.StatusTypeName AS ApplicationStatus,
    CAST(ea.ApplicationStatusEffectiveDate AS DATE) AS ApplicationStatusEffectiveDate,
    CAST(ea.DateFrom AS DATE) AS DateFrom,
    CAST(ea.DateTo AS DATE) AS DateTo,
    CAST(ea.RenewalDate AS DATE) AS RenewalDate,
    CAST(ea.AppointedDate AS DATE) AS AppointedDate,
    CAST(ea.AttestationDate AS DATE) AS AttestationDate,
    ea.Notes
FROM EntityAssignments ea
JOIN RecordTypes rt ON rt.RecordTypeID = ea.RecordTypeID AND rt.TableName = 'Practices'
LEFT JOIN Entities e ON e.EntityID = ea.EntityID AND e.Archived = 'N'
LEFT JOIN StatusTypes st_ent ON st_ent.StatusTypeID = ea.StatusTypeID AND st_ent.Archived = 'N'
LEFT JOIN StatusTypes st_app ON st_app.StatusTypeID = ea.ApplicationStatusTypeID AND st_app.Archived = 'N'
WHERE ea.ProviderID = ? AND ea.ParentRecID = ? AND ea.Archived = 'N'
ORDER BY ea.DateFrom DESC
"""

PRACTICE_QI_ACTIVITIES = """
SELECT
    pqi.PracticeQIActivityRecID,
    qit.QualityIndicatorTypeName, qit.QualityIndicatorTypeCode,
    qct.QualityCategoryTypeName, qct.QualityCategoryTypeCode,
    CAST(pqi.DateFrom AS DATE) AS DateFrom,
    CAST(pqi.DateTo AS DATE) AS DateTo,
    pqi.Notes
FROM PracticeQIActivities pqi
JOIN QualityIndicatorTypes qit ON qit.QualityIndicatorTypeID = pqi.QualityIndicatorTypeID AND qit.Archived = 'N'
JOIN QualityCategoryTypes qct ON qct.QualityCategoryTypeID = pqi.QualityCategoryTypeID AND qct.Archived = 'N'
WHERE pqi.PracticeID = ? AND pqi.Archived = 'N'
ORDER BY pqi.DateFrom DESC
"""

PRACTICE_LOCATIONS_SEARCH_BASE = """
SELECT 
    LocationID, PracticeID, PracticeName, LocationName,
    LocationTypeName, TaxIDNumber, NationalProviderID,
    CAST(DateFrom AS DATE) AS DateFrom,
    CAST(DateTo AS DATE) AS DateTo,
    LineNumber1, LineNumber2, City, State, ZipCode,
    County, OfficeManagerName, TwentyFourHourCoverage
FROM vwPracticeLocations
WHERE Archived = 'N'
"""

PRACTICE_LOCATION_SERVICES = """
SELECT 
    ls.LocationServiceRecID, ls.LocationName, ls.PracticeName,
    ls.ServiceTypeName, ls.ServiceCategoryTypeName, ls.ServiceClassTypeName,
    CAST(ls.DateFrom AS DATE) AS DateFrom,
    CAST(ls.DateTo AS DATE) AS DateTo,
    ls.ContactName, ls.ContactTypeName, ls.TaxonomyCode, ls.Notes
FROM vwLocationServices ls
JOIN vwPracticeLocations pl ON pl.LocationID = ls.LocationID
WHERE ls.Archived = 'N' AND pl.Archived = 'N'
"""

PRACTICE_LOCATION_LICENSES = """
SELECT 
    pl.PracticeLicenseRecID, lt.LicenseTypeName, lst.LicenseSubTypeName,
    pl.LicenseNumber, pl.IssuingState, pl.PrimaryLicense,
    CAST(pl.IssueDate AS DATE) AS IssueDate,
    CAST(pl.ExpirationDate AS DATE) AS ExpirationDate,
    pl.DisciplinaryAction, pl.ActiveStatePractice
FROM PracticeLicenses pl
LEFT JOIN LicenseTypes lt ON lt.LicenseTypeID = pl.LicenseTypeID
LEFT JOIN LicenseSubTypes lst ON lst.LicenseSubTypeID = pl.LicenseSubTypeID
JOIN vwPracticeLocations vpl ON vpl.LocationID = pl.LocationID
WHERE pl.Archived = 'N' AND vpl.Archived = 'N'
"""



PRACTICE_PRACTITIONER_AFFILIATIONS = """
SELECT DISTINCT
    p.PractitionerID, p.NationalProviderID AS PractitionerNPI,
    p.FirstName, p.LastName,
    g.PracticeID, g.PracticeName, g.TaxIDNumber AS GroupTIN,
    gl.LocationID, gl.LocationName,
    gl.NationalProviderID AS GNPI,
    a.LineNumber1, a.LineNumber2, z.City, z.State, z.ZipCode
FROM Practices g
JOIN PracticeLocations gl ON gl.PracticeID = g.PracticeID AND gl.Archived = 'N'
JOIN PractitionerLocations pl ON pl.LocationID = gl.LocationID AND pl.Archived = 'N'
JOIN Practitioners p ON p.PractitionerID = pl.PractitionerID AND p.Archived = 'N'
LEFT JOIN Addresses a ON a.AddressID = gl.AddressID AND a.Archived = 'N'
LEFT JOIN ZipCodes z ON z.ZipCodeID = a.ZipCodeID AND z.Archived = 'N'
WHERE g.Archived = 'N'
"""