from fastapi import APIRouter, Query
from typing import Optional
import logging
from database import execute_query
from sql_templates import practitioner as sql_templates
from error import ResourceNotFoundError, MissingRequiredParameterError, DatabaseError  # was "errors" -- no such module (see poc-strands/spayer-backend/main.py)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/practitioner", tags=["practitioner"])

@router.get("/search")
def search_practitioners(
    FirstName: Optional[str] = Query(None),
    LastName: Optional[str] = Query(None),
    NationalProviderID: Optional[str] = Query(None),
    limit: int = Query(100, ge=1, le=500)
):
    try:
        search_fields = {
            'p.FirstName': FirstName,
            'p.LastName': LastName,
            'p.NationalProviderID': NationalProviderID
        }
        
        conditions = []
        params = []
        
        for field, value in search_fields.items():
            if value:
                conditions.append(f"{field} LIKE ?")
                params.append(f"%{value}%")
        
        if not conditions:
            raise MissingRequiredParameterError(["FirstName", "LastName", "NationalProviderID"])
        
        query = f"{sql_templates.PRACTITIONER_SEARCH} AND ({' AND '.join(conditions)})"
        results = execute_query(query, tuple(params))
        return {"count": len(results), "results": results[:limit]}
    except MissingRequiredParameterError:
        raise
    except Exception as e:
        logger.error(f"Error searching practitioners: {e}", exc_info=True)
        raise DatabaseError("search practitioners", str(e))
        raise DatabaseError("operation", str(e))

@router.get("/locations/search")
def search_practitioner_locations(
    PractitionerID: Optional[int] = Query(None),
    NationalProviderID: Optional[str] = Query(None),
    State: Optional[str] = Query(None),
    City: Optional[str] = Query(None),
    ZipCode: Optional[str] = Query(None),
    LineNumber1: Optional[str] = Query(None),
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(100, ge=1, le=500, description="Items per page")
):
    try:
        # Require PractitionerID or NationalProviderID
        if not PractitionerID and not NationalProviderID:
            raise MissingRequiredParameterError([], "PractitionerID or NationalProviderID is required")
        
        # If NPI provided, look up PractitionerID first
        if NationalProviderID and not PractitionerID:
            npi_lookup = execute_query(
                "SELECT PractitionerID FROM practitioners WHERE NationalProviderID = ? AND Archived = 'N'",
                (NationalProviderID,)
            )
            if npi_lookup:
                PractitionerID = npi_lookup[0]['PractitionerID']
            else:
                # No practitioner found with this NPI
                return {
                    "total": 0,
                    "page": page,
                    "page_size": page_size,
                    "total_pages": 0,
                    "locations": []
                }
        
        # Exact match fields (only use PractitionerID now)
        exact_fields = {
            'PractitionerID': PractitionerID,
            'State': State
        }
        
        # LIKE match fields
        like_fields = {
            'City': City,
            'ZipCode': ZipCode,
            'LineNumber1': LineNumber1
        }
        
        conditions = []
        params = []
        
        for field, value in exact_fields.items():
            if value:
                conditions.append(f"{field} = ?")
                params.append(value)
        
        for field, value in like_fields.items():
            if value:
                conditions.append(f"{field} LIKE ?")
                params.append(f"%{value}%")
        
        # Build query
        where_clause = " AND ".join(conditions)
        query = f"{sql_templates.PRACTITIONER_LOCATIONS_SEARCH_BASE} AND {where_clause} ORDER BY PrimaryLocation DESC, DateFrom DESC"
        
        # Get all results for count
        all_results = execute_query(query, tuple(params))
        total = len(all_results)
        
        # Apply pagination
        offset = (page - 1) * page_size
        paginated_results = all_results[offset:offset + page_size]
        
        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size,
            "locations": paginated_results
        }
    except MissingRequiredParameterError:
        raise
    except Exception as e:
        logger.error(f"Error searching practitioner locations: {e}", exc_info=True)
        raise DatabaseError("search practitioner locations", str(e))

@router.get("/products/search")
def search_practitioner_products(
    PractitionerID: Optional[int] = Query(None),
    NationalProviderID: Optional[str] = Query(None),
    PractitionerLocationRecID: Optional[int] = Query(None),
    LocationName: Optional[str] = Query(None),
    ProductName: Optional[str] = Query(None),
    ProductCode: Optional[str] = Query(None),
    ContractName: Optional[str] = Query(None),
    State: Optional[str] = Query(None),
    City: Optional[str] = Query(None),
    LineNumber1: Optional[str] = Query(None),
    DateFrom: Optional[str] = Query(None, description="Filter by DateFrom (YYYY-MM-DD)"),
    DateTo: Optional[str] = Query(None, description="Filter by DateTo (YYYY-MM-DD)"),
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(100, ge=1, le=500, description="Items per page")
):
    try:
        # Require PractitionerID, NationalProviderID, or PractitionerLocationRecID
        if not PractitionerID and not NationalProviderID and not PractitionerLocationRecID:
            raise HTTPException(
                status_code=400, 
                detail="PractitionerID, NationalProviderID, or PractitionerLocationRecID is required"
            )

        # Resolve NPI to PractitionerID
        if NationalProviderID and not PractitionerID:
            npi_lookup = execute_query(
                "SELECT PractitionerID FROM practitioners WHERE NationalProviderID = ? AND Archived = 'N'",
                (NationalProviderID,)
            )
            if npi_lookup:
                PractitionerID = npi_lookup[0]['PractitionerID']
            else:
                return {"total": 0, "page": page, "page_size": page_size, "total_pages": 0, "products": []}

        # Exact match fields
        exact_fields = {
            'pp.PractitionerID': PractitionerID,
            'pp.PractitionerLocationRecID': PractitionerLocationRecID,
            'vpl.State': State,
            'p.ProductCode': ProductCode
        }
        
        # LIKE match fields
        like_fields = {
            'vpl.LocationName': LocationName,
            'p.ProductName': ProductName,
            'c.ContractName': ContractName,
            'vpl.City': City,
            'vpl.LineNumber1': LineNumber1
        }
        
        conditions = []
        params = []
        
        for field, value in exact_fields.items():
            if value:
                conditions.append(f"{field} = ?")
                params.append(value)
        
        for field, value in like_fields.items():
            if value:
                conditions.append(f"{field} LIKE ?")
                params.append(f"%{value}%")
        
        # Date filters
        if DateFrom:
            conditions.append("CAST(pp.DateFrom AS DATE) >= ?")
            params.append(DateFrom)
        
        if DateTo:
            conditions.append("CAST(pp.DateTo AS DATE) <= ?")
            params.append(DateTo)
        
        # Build query
        where_clause = " AND ".join(conditions)
        query = f"{sql_templates.PRACTITIONER_PRODUCTS_SEARCH_BASE} AND {where_clause} ORDER BY pp.DateFrom DESC"
        
        # Get all results for count
        all_results = execute_query(query, tuple(params))
        total = len(all_results)
        
        # Apply pagination
        offset = (page - 1) * page_size
        paginated_results = all_results[offset:offset + page_size]
        
        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size,
            "products": paginated_results
        }
    except MissingRequiredParameterError:
        raise
    except Exception as e:
        logger.error(f"Error searching practitioner products: {e}", exc_info=True)
        raise DatabaseError("search practitioner products", str(e))

@router.get("/demographics/{PractitionerID}")
def get_practitioner_demographics(PractitionerID: int):
    try:
        results = execute_query(sql_templates.PRACTITIONER_DEMOGRAPHICS, (PractitionerID,))
        if not results:
            raise ResourceNotFoundError("practitioner", PractitionerID, "PractitionerID")
        return results[0]
    except ResourceNotFoundError:
        raise
    except Exception as e:
        logger.error(f"Error fetching practitioner demographics: {e}", exc_info=True)
        raise DatabaseError("fetch practitioner demographics", str(e))

@router.get("/by-npi/{NationalProviderID}")
def get_practitioner_by_npi(NationalProviderID: str):
    try:
        if not NationalProviderID.isdigit() or len(NationalProviderID) != 10:
            raise MissingRequiredParameterError([], "NationalProviderID must be a 10-digit number")
        results = execute_query(sql_templates.PRACTITIONER_BY_NPI, (NationalProviderID,))
        if not results:
            raise ResourceNotFoundError("practitioner", NationalProviderID, "NationalProviderID")
        return {"count": len(results), "results": results}
    except (ResourceNotFoundError, MissingRequiredParameterError):
        raise
    except Exception as e:
        logger.error(f"Error fetching practitioner by NPI: {e}", exc_info=True)
        raise DatabaseError("fetch practitioner by NPI", str(e))

@router.get("/specialties/{PractitionerID}")
def get_practitioner_specialties(PractitionerID: int):
    try:
        results = execute_query(sql_templates.PRACTITIONER_SPECIALTIES, (PractitionerID,))
        return {"count": len(results), "specialties": results}
    except Exception as e:
        logger.error(f"Error fetching practitioner specialties: {e}", exc_info=True)
        raise DatabaseError("operation", str(e))

@router.get("/licenses/{PractitionerID}")
def get_practitioner_licenses(PractitionerID: int):
    try:
        results = execute_query(sql_templates.PRACTITIONER_LICENSES, (PractitionerID,))
        return {"count": len(results), "licenses": results}
    except Exception as e:
        logger.error(f"Error fetching practitioner licenses: {e}", exc_info=True)
        raise DatabaseError("operation", str(e))

@router.get("/locations/{PractitionerID}")
def get_practitioner_locations(
    PractitionerID: int,
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(100, ge=1, le=500, description="Items per page")
):
    try:
        # Get total count
        count_result = execute_query(sql_templates.PRACTITIONER_LOCATIONS_COUNT, (PractitionerID,))
        total = count_result[0]['total'] if count_result else 0
        
        # Calculate offset
        offset = (page - 1) * page_size
        
        # Get paginated results
        results = execute_query(sql_templates.PRACTITIONER_LOCATIONS, (PractitionerID, offset, page_size))
        
        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size,
            "locations": results
        }
    except Exception as e:
        logger.error(f"Error fetching practitioner locations: {e}", exc_info=True)
        raise DatabaseError("operation", str(e))

@router.get("/languages/{PractitionerID}")
def get_practitioner_languages(PractitionerID: int):
    try:
        results = execute_query(sql_templates.PRACTITIONER_LANGUAGES, (PractitionerID,))
        return {"count": len(results), "languages": results}
    except Exception as e:
        logger.error(f"Error fetching practitioner languages: {e}", exc_info=True)
        raise DatabaseError("fetch practitioner languages", str(e))

@router.get("/education/{PractitionerID}")
def get_practitioner_education(PractitionerID: int):
    try:
        results = execute_query(sql_templates.PRACTITIONER_EDUCATION, (PractitionerID,))
        return {"count": len(results), "education": results}
    except Exception as e:
        logger.error(f"Error fetching practitioner education: {e}", exc_info=True)
        raise DatabaseError("fetch practitioner education", str(e))

@router.get("/credentialing/{PractitionerID}")
def get_practitioner_credentialing(PractitionerID: int):
    try:
        results = execute_query(sql_templates.PRACTITIONER_CREDENTIALING, (PractitionerID, PractitionerID))
        return {"count": len(results), "credentialing": results}
    except Exception as e:
        logger.error(f"Error fetching practitioner credentialing: {e}", exc_info=True)
        raise DatabaseError("fetch practitioner credentialing", str(e))

@router.get("/qi-activities/{PractitionerID}")
def get_practitioner_qi_activities(PractitionerID: int):
    try:
        results = execute_query(sql_templates.PRACTITIONER_QI_ACTIVITIES, (PractitionerID,))
        return {"count": len(results), "qi_activities": results}
    except Exception as e:
        logger.error(f"Error fetching practitioner QI activities: {e}", exc_info=True)
        raise DatabaseError("fetch practitioner QI activities", str(e))

@router.get("/affiliations/{PractitionerID}")
def get_practitioner_group_affiliations(PractitionerID: int):
    """Get all group affiliations with locations for a practitioner."""
    try:
        query = sql_templates.PRACTITIONER_GROUP_AFFILIATIONS + " AND p.PractitionerID = ? ORDER BY g.TaxIDNumber, gl.NationalProviderID"
        rows = execute_query(query, (PractitionerID,))
        return _build_affiliation_response(rows)
    except Exception as e:
        logger.error(f"Error fetching practitioner affiliations: {e}", exc_info=True)
        raise DatabaseError("fetch practitioner affiliations", str(e))

@router.get("/affiliations/by-npi/{NationalProviderID}")
def get_practitioner_group_affiliations_by_npi(NationalProviderID: str):
    """Get all group affiliations with locations for a practitioner by NPI."""
    try:
        query = sql_templates.PRACTITIONER_GROUP_AFFILIATIONS + " AND p.NationalProviderID = ? ORDER BY g.TaxIDNumber, gl.NationalProviderID"
        rows = execute_query(query, (NationalProviderID,))
        return _build_affiliation_response(rows)
    except Exception as e:
        logger.error(f"Error fetching practitioner affiliations by NPI: {e}", exc_info=True)
        raise DatabaseError("fetch practitioner affiliations by NPI", str(e))

def _build_affiliation_response(rows):
    groups = {}
    for r in rows:
        tin = r["GroupTIN"]
        if tin not in groups:
            groups[tin] = {"PracticeID": r["PracticeID"], "PracticeName": r["PracticeName"], "GroupTIN": tin, "locations": []}
        groups[tin]["locations"].append({
            "LocationID": r["LocationID"], "PractitionerLocationRecID": r["PractitionerLocationRecID"],
            "LocationName": r["LocationName"], "GNPI": r["GNPI"],
            "LineNumber1": r["LineNumber1"], "LineNumber2": r["LineNumber2"],
            "City": r["City"], "State": r["State"], "ZipCode": r["ZipCode"],
        })
    result = list(groups.values())
    return {"count": len(result), "total_locations": len(rows), "groups": result}