from fastapi import APIRouter, Query
from error import ResourceNotFoundError, MissingRequiredParameterError, DatabaseError  # was "errors" -- no such module (see poc-strands/spayer-backend/main.py)
from typing import Optional
import logging
from database import execute_query
from sql_templates import practice as sql_templates

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/practice", tags=["practice"])

@router.get("/search")
def search_practices(
    PracticeName: Optional[str] = Query(None),
    TaxIDNumber: Optional[str] = Query(None),
    limit: int = Query(100, ge=1, le=500)
):
    try:
        search_fields = {
            'PracticeName': PracticeName,
            'TaxIDNumber': TaxIDNumber
        }
        
        conditions = []
        params = []
        
        for field, value in search_fields.items():
            if value:
                conditions.append(f"{field} LIKE ?")
                params.append(f"%{value}%")
        
        if not conditions:
            raise MissingRequiredParameterError(["PracticeName", "TaxIDNumber"])
        
        query = f"{sql_templates.PRACTICE_SEARCH} AND ({' OR '.join(conditions)})"
        results = execute_query(query, tuple(params))
        return {"count": len(results), "results": results[:limit]}
    except MissingRequiredParameterError:
        raise
    except Exception as e:
        logger.error(f"Error searching practices: {e}", exc_info=True)
        raise DatabaseError("search practices", str(e))

@router.get("/demographics/{PracticeID}")
def get_practice_demographics(PracticeID: int):
    try:
        results = execute_query(sql_templates.PRACTICE_DEMOGRAPHICS, (PracticeID,))
        if not results:
            raise ResourceNotFoundError("practice", PracticeID, "PracticeID")
        return results[0]
    except ResourceNotFoundError:
        raise
    except Exception as e:
        logger.error(f"Error fetching practice demographics: {e}", exc_info=True)
        raise DatabaseError("fetch practice demographics", str(e))

@router.get("/by-tin/{TaxIDNumber}")
def get_practice_by_tin(TaxIDNumber: str):
    try:
        if not TaxIDNumber.isdigit() or len(TaxIDNumber) != 9:
            raise MissingRequiredParameterError([], "TaxIDNumber must be a 9-digit number")
        results = execute_query(sql_templates.PRACTICE_BY_TIN, (TaxIDNumber,))
        if not results:
            raise ResourceNotFoundError("practice", TaxIDNumber, "TaxIDNumber")
        return {"count": len(results), "results": results}
    except (ResourceNotFoundError, MissingRequiredParameterError):
        raise
    except Exception as e:
        logger.error(f"Error fetching practice by TIN: {e}", exc_info=True)
        raise DatabaseError("fetch practice by TIN", str(e))

@router.get("/locations/search")
def search_practice_locations(
    PracticeID: Optional[int] = Query(None),
    TaxIDNumber: Optional[str] = Query(None),
    NationalProviderID: Optional[str] = Query(None),
    LocationName: Optional[str] = Query(None),
    LocationTypeName: Optional[str] = Query(None),
    State: Optional[str] = Query(None),
    City: Optional[str] = Query(None),
    ZipCode: Optional[str] = Query(None),
    LineNumber1: Optional[str] = Query(None),
    DateFrom: Optional[str] = Query(None, description="Filter by DateFrom (YYYY-MM-DD)"),
    DateTo: Optional[str] = Query(None, description="Filter by DateTo (YYYY-MM-DD)"),
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(100, ge=1, le=500, description="Items per page")
):
    try:
        if not PracticeID and not TaxIDNumber and not NationalProviderID:
            raise MissingRequiredParameterError(
                ["PracticeID", "TaxIDNumber", "NationalProviderID"]
            )
        
        # Exact match fields
        exact_fields = {
            'PracticeID': PracticeID,
            'TaxIDNumber': TaxIDNumber,
            'NationalProviderID': NationalProviderID,
            'State': State,
            'LocationTypeName': LocationTypeName
        }
        
        # LIKE match fields
        like_fields = {
            'LocationName': LocationName,
            'City': City,
            'ZipCode': ZipCode,
            'LineNumber1': LineNumber1
        }
        
        conditions = []
        params = []
        
        for field, value in exact_fields.items():
            if value:
                conditions.append(f"{field} = ?")
                params.append(value)
        
        for field, value in like_fields.items():
            if value:
                conditions.append(f"{field} LIKE ?")
                params.append(f"%{value}%")
        
        # Date filters
        if DateFrom:
            conditions.append("CAST(DateFrom AS DATE) >= ?")
            params.append(DateFrom)
        
        if DateTo:
            conditions.append("CAST(DateTo AS DATE) <= ?")
            params.append(DateTo)
        
        # Build query
        where_clause = " AND ".join(conditions)
        query = f"{sql_templates.PRACTICE_LOCATIONS_SEARCH_BASE} AND {where_clause} ORDER BY DateFrom DESC"
        
        # Get all results for count
        all_results = execute_query(query, tuple(params))
        total = len(all_results)
        
        # Apply pagination
        offset = (page - 1) * page_size
        paginated_results = all_results[offset:offset + page_size]
        
        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size,
            "locations": paginated_results
        }
    except MissingRequiredParameterError:
        raise
    except Exception as e:
        logger.error(f"Error searching practice locations: {e}", exc_info=True)
        raise DatabaseError("search practice locations", str(e))

@router.get("/location/services")
def get_practice_location_services(
    LocationID: Optional[int] = Query(None),
    NationalProviderID: Optional[str] = Query(None)
):
    try:
        if not LocationID and not NationalProviderID:
            raise MissingRequiredParameterError(["LocationID", "NationalProviderID"])
        
        conditions = []
        params = []
        
        if LocationID:
            conditions.append("ls.LocationID = ?")
            params.append(LocationID)
        
        if NationalProviderID:
            conditions.append("pl.NationalProviderID = ?")
            params.append(NationalProviderID)
        
        where_clause = " AND ".join(conditions)
        query = f"{sql_templates.PRACTICE_LOCATION_SERVICES} AND {where_clause}"
        
        results = execute_query(query, tuple(params))
        return {"count": len(results), "services": results}
    except MissingRequiredParameterError:
        raise
    except Exception as e:
        logger.error(f"Error fetching practice location services: {e}", exc_info=True)
        raise DatabaseError("fetch practice location services", str(e))

@router.get("/location/licenses")
def get_practice_location_licenses(
    LocationID: Optional[int] = Query(None),
    NationalProviderID: Optional[str] = Query(None)
):
    try:
        if not LocationID and not NationalProviderID:
            raise MissingRequiredParameterError(["LocationID", "NationalProviderID"])
        
        conditions = []
        params = []
        
        if LocationID:
            conditions.append("pl.LocationID = ?")
            params.append(LocationID)
        
        if NationalProviderID:
            conditions.append("vpl.NationalProviderID = ?")
            params.append(NationalProviderID)
        
        where_clause = " AND ".join(conditions)
        query = f"{sql_templates.PRACTICE_LOCATION_LICENSES} AND {where_clause}"
        
        results = execute_query(query, tuple(params))
        return {"count": len(results), "licenses": results}
    except MissingRequiredParameterError:
        raise
    except Exception as e:
        logger.error(f"Error fetching practice location licenses: {e}", exc_info=True)
        raise DatabaseError("fetch practice location licenses", str(e))

@router.get("/credentialing/{PracticeID}")
def get_practice_credentialing(PracticeID: int):
    try:
        results = execute_query(sql_templates.PRACTICE_CREDENTIALING, (PracticeID, PracticeID))
        return {"count": len(results), "credentialing": results}
    except Exception as e:
        logger.error(f"Error fetching practice credentialing: {e}", exc_info=True)
        raise DatabaseError("fetch practice credentialing", str(e))

@router.get("/qi-activities/{PracticeID}")
def get_practice_qi_activities(PracticeID: int):
    try:
        results = execute_query(sql_templates.PRACTICE_QI_ACTIVITIES, (PracticeID,))
        return {"count": len(results), "qi_activities": results}
    except Exception as e:
        logger.error(f"Error fetching practice QI activities: {e}", exc_info=True)
        raise DatabaseError("fetch practice QI activities", str(e))

@router.get("/affiliations/{PracticeID}")
def get_practice_practitioner_affiliations(
    PracticeID: int,
    NationalProviderID: Optional[str] = Query(None, description="Filter by GNPI (location NPI)")
):
    """Get practitioners affiliated with a practice. Optionally filter by GNPI."""
    try:
        query = sql_templates.PRACTICE_PRACTITIONER_AFFILIATIONS + " AND g.PracticeID = ?"
        params = [PracticeID]
        if NationalProviderID:
            query += " AND gl.NationalProviderID = ?"
            params.append(NationalProviderID)
        results = execute_query(query, tuple(params))
        return {"count": len(results), "affiliations": results}
    except Exception as e:
        logger.error(f"Error fetching practice affiliations: {e}", exc_info=True)
        raise DatabaseError("fetch practice affiliations", str(e))

@router.get("/affiliations/by-tin/{TaxIDNumber}")
def get_practice_practitioner_affiliations_by_tin(
    TaxIDNumber: str,
    NationalProviderID: Optional[str] = Query(None, description="Filter by GNPI (location NPI)")
):
    """Get practitioners affiliated with a practice by TIN. Optionally filter by GNPI."""
    try:
        query = sql_templates.PRACTICE_PRACTITIONER_AFFILIATIONS + " AND g.TaxIDNumber = ?"
        params = [TaxIDNumber]
        if NationalProviderID:
            query += " AND gl.NationalProviderID = ?"
            params.append(NationalProviderID)
        results = execute_query(query, tuple(params))
        return {"count": len(results), "affiliations": results}
    except Exception as e:
        logger.error(f"Error fetching practice affiliations by TIN: {e}", exc_info=True)
        raise DatabaseError("fetch practice affiliations by TIN", str(e))