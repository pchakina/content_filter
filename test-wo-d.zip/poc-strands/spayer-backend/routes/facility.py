from fastapi import APIRouter, Query
from error import ResourceNotFoundError, MissingRequiredParameterError, DatabaseError  # was "errors" -- no such module (see poc-strands/spayer-backend/main.py)
from typing import Optional
import logging
from database import execute_query
from sql_templates import facility as sql_templates

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/facility", tags=["facility"])

@router.get("/search")
def search_facilities(name: Optional[str] = Query(None), limit: int = Query(100, ge=1, le=500)):
    try:
        if not name:
            raise MissingRequiredParameterError(["name"])
        
        query = f"{sql_templates.FACILITY_SEARCH} AND FacilityName LIKE ?"
        results = execute_query(query, (f"%{name}%",))
        return {"count": len(results), "results": results[:limit]}
    except MissingRequiredParameterError:
        raise
    except Exception as e:
        logger.error(f"Error searching facilities: {e}", exc_info=True)
        raise DatabaseError("search facilities", str(e))

@router.get("/demographics/{FacilityID}")
def get_facility_demographics(FacilityID: int):
    try:
        results = execute_query(sql_templates.FACILITY_DEMOGRAPHICS, (FacilityID,))
        if not results:
            raise ResourceNotFoundError("facility", FacilityID, "FacilityID")
        return results[0]
    except ResourceNotFoundError:
        raise
    except Exception as e:
        logger.error(f"Error fetching facility demographics: {e}", exc_info=True)
        raise DatabaseError("fetch facility demographics", str(e))

@router.get("/by-npi/{NationalProviderID}")
def get_facility_by_npi(NationalProviderID: str):
    try:
        results = execute_query(sql_templates.FACILITY_BY_NPI, (NationalProviderID,))
        if not results:
            raise ResourceNotFoundError("facility", FacilityID, "FacilityID")
        return {"count": len(results), "results": results}
    except Exception as e:
        logger.error(f"Error fetching facility by NPI: {e}", exc_info=True)
        raise DatabaseError("operation", str(e))

@router.get("/licenses/{FacilityID}")
def get_facility_licenses(FacilityID: int):
    try:
        results = execute_query(sql_templates.FACILITY_LICENSES, (FacilityID,))
        return {"count": len(results), "licenses": results}
    except Exception as e:
        logger.error(f"Error fetching facility licenses: {e}", exc_info=True)
        raise DatabaseError("operation", str(e))

@router.get("/products/search")
def search_facility_products(
    FacilityID: Optional[int] = Query(None),
    TaxIDNumber: Optional[str] = Query(None),
    ProductCode: Optional[str] = Query(None),
    ProductName: Optional[str] = Query(None),
    ProductTypeName: Optional[str] = Query(None),
    Active: Optional[str] = Query(None, description="Status type name"),
    ContractName: Optional[str] = Query(None),
    LocationName: Optional[str] = Query(None),
    State: Optional[str] = Query(None),
    City: Optional[str] = Query(None),
    LineNumber1: Optional[str] = Query(None),
    DateFrom: Optional[str] = Query(None, description="Filter by DateFrom (YYYY-MM-DD)"),
    DateTo: Optional[str] = Query(None, description="Filter by DateTo (YYYY-MM-DD)"),
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(100, ge=1, le=500, description="Items per page")
):
    try:
        # Require FacilityID or TaxIDNumber
        if not FacilityID and not TaxIDNumber:
            raise MissingRequiredParameterError([], "FacilityID or TaxIDNumber is required")
        
        # Exact match fields
        exact_fields = {
            'FacilityID': FacilityID,
            'TaxIDNumber': TaxIDNumber,
            'ProductCode': ProductCode,
            'State': State,
            'StatusTypeName': Active
        }
        
        # LIKE match fields
        like_fields = {
            'ProductName': ProductName,
            'ProductTypeName': ProductTypeName,
            'ContractName': ContractName,
            'LocationName': LocationName,
            'City': City,
            'LineNumber1': LineNumber1
        }
        
        conditions = []
        params = []
        
        for field, value in exact_fields.items():
            if value:
                conditions.append(f"{field} = ?")
                params.append(value)
        
        for field, value in like_fields.items():
            if value:
                conditions.append(f"{field} LIKE ?")
                params.append(f"%{value}%")
        
        # Date filters
        if DateFrom:
            conditions.append("CAST(DateFrom AS DATE) >= ?")
            params.append(DateFrom)
        
        if DateTo:
            conditions.append("CAST(DateTo AS DATE) <= ?")
            params.append(DateTo)
        
        # Build query
        where_clause = " AND ".join(conditions)
        query = f"{sql_templates.FACILITY_PRODUCTS_SEARCH_BASE} AND {where_clause} ORDER BY DateFrom DESC"
        
        # Get all results for count
        all_results = execute_query(query, tuple(params))
        total = len(all_results)
        
        # Apply pagination
        offset = (page - 1) * page_size
        paginated_results = all_results[offset:offset + page_size]
        
        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size,
            "products": paginated_results
        }
    except Exception as e:
        logger.error(f"Error searching facility products: {e}", exc_info=True)
        raise DatabaseError("operation", str(e))

@router.get("/locations/search")
def search_facility_locations(
    FacilityID: Optional[int] = Query(None),
    NationalProviderID: Optional[str] = Query(None),
    TaxIDNumber: Optional[str] = Query(None),
    LocationName: Optional[str] = Query(None),
    AddressTypeName: Optional[str] = Query(None, description="Billing or Service"),
    State: Optional[str] = Query(None),
    City: Optional[str] = Query(None),
    ZipCode: Optional[str] = Query(None),
    LineNumber1: Optional[str] = Query(None),
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(100, ge=1, le=500, description="Items per page")
):
    try:
        # Require FacilityID or NationalProviderID
        if not FacilityID and not NationalProviderID:
            raise MissingRequiredParameterError([], "FacilityID or NationalProviderID is required")
        
        # Exact match fields
        exact_fields = {
            'FacilityID': FacilityID,
            'NationalProviderID': NationalProviderID,
            'State': State,
            'AddressTypeName': AddressTypeName
        }
        
        # LIKE match fields
        like_fields = {
            'TaxIDNumber': TaxIDNumber,
            'LocationName': LocationName,
            'City': City,
            'ZipCode': ZipCode,
            'LineNumber1': LineNumber1
        }
        
        conditions = []
        params = []
        
        for field, value in exact_fields.items():
            if value:
                conditions.append(f"{field} = ?")
                params.append(value)
        
        for field, value in like_fields.items():
            if value:
                conditions.append(f"{field} LIKE ?")
                params.append(f"%{value}%")
        
        # Build query
        where_clause = " AND ".join(conditions)
        query = f"{sql_templates.FACILITY_LOCATIONS_SEARCH_BASE} AND {where_clause} ORDER BY DateFrom DESC"
        
        # Get all results for count
        all_results = execute_query(query, tuple(params))
        total = len(all_results)
        
        # Apply pagination
        offset = (page - 1) * page_size
        paginated_results = all_results[offset:offset + page_size]
        
        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size,
            "locations": paginated_results
        }
    except Exception as e:
        logger.error(f"Error searching facility locations: {e}", exc_info=True)
        raise DatabaseError("operation", str(e))

@router.get("/credentialing/{FacilityID}")
def get_facility_credentialing(FacilityID: int):
    try:
        results = execute_query(sql_templates.FACILITY_CREDENTIALING, (FacilityID, FacilityID))
        return {"count": len(results), "credentialing": results}
    except Exception as e:
        logger.error(f"Error fetching facility credentialing: {e}", exc_info=True)
        raise DatabaseError("fetch facility credentialing", str(e))

@router.get("/qi-activities/{FacilityID}")
def get_facility_qi_activities(FacilityID: int):
    try:
        results = execute_query(sql_templates.FACILITY_QI_ACTIVITIES, (FacilityID,))
        return {"count": len(results), "qi_activities": results}
    except Exception as e:
        logger.error(f"Error fetching facility QI activities: {e}", exc_info=True)
        raise DatabaseError("fetch facility QI activities", str(e))