from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    db_driver: str
    db_server: str
    db_port: int = 1433
    db_name: str
    db_user: str
    db_password: str
    
    class Config:
        env_file = ".env"
    
    @property
    def connection_string(self) -> str:
        return (
            f"DRIVER={{{self.db_driver}}};"
            f"SERVER={self.db_server},{self.db_port};"
            f"DATABASE={self.db_name};"
            f"UID={self.db_user};"
            f"PWD={self.db_password};"
            f"TrustServerCertificate=yes"
        )

settings = Settings()