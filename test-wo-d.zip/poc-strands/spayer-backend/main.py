from fastapi import FastAPI, APIRouter
import logging
from routes import practitioner, practice, facility
from error import (  # NOTE: poc/spayer-backend/main.py imports "from errors import
                      # (...)" but the actual module is error.py (no "s") --
                      # that import fails with ModuleNotFoundError as committed
                      # there. Fixed here.
    StandardError, 
    standard_error_handler, 
    http_exception_handler, 
    general_exception_handler
)
from fastapi.exceptions import HTTPException

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = FastAPI(title="Provider API", version="1.0.0",
             docs_url="/spayer/api/v1/docs",
             openapi_url="/spayer/api/v1/openapi.json")

# Register error handlers
app.add_exception_handler(StandardError, standard_error_handler)
app.add_exception_handler(HTTPException, http_exception_handler)
app.add_exception_handler(Exception, general_exception_handler)

# All routes under /spayer/api/v1
api = APIRouter(prefix="/spayer/api/v1")
api.include_router(practitioner.router)
api.include_router(practice.router)
api.include_router(facility.router)

@api.get("/")
def api_root():
    return {"status": "ok"}

app.include_router(api)

logger.info("Provider API initialized with routes: practitioner, practice, facility")

@app.get("/")
def root():
    return {"status": "ok"}