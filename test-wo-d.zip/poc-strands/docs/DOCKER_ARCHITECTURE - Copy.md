# Docker Architecture & Process Flow (Pattern 2 / A2A)

Each folder in `poc/` builds into its **own container image**, runs as its **own ECS service**, and talks to the others over HTTP by service name.

---

## 1. Runtime flow — one user request across containers

```mermaid
flowchart TB
    User(["👤 User (browser)"])

    subgraph UI["master container · :7860"]
        WebUI["web_ui.py<br/>Gradio chat"]
        Orch["orchestrator.py<br/>intent routing + session guards"]
    end

    subgraph REG["registry container · :7000"]
        Registry["Agent Registry<br/>find agent by capability"]
    end

    subgraph AGENTS["Specialist agent containers"]
        Prac["PractitionerAgent<br/>:8001"]
        NL2["NL2SQLAgent<br/>:8002"]
        Pra["PracticeAgent<br/>:8003"]
        Fac["FacilityAgent<br/>:8004"]
    end

    subgraph SYN["synthesis container · :8005"]
        Synth["SynthesisAgent<br/>formats results as tables"]
    end

    subgraph MCPC["mcp container · :8080"]
        MCP["MCP Server<br/>34 tools, tagged per agent"]
    end

    subgraph BE["spayer-backend container · :8000"]
        API["Provider REST API<br/>FastAPI + ODBC Driver 18"]
    end

    DB[("MS-SQL Server<br/>provider data")]
    Bedrock{{"AWS Bedrock<br/>Ministral-3 / Mistral Large"}}

    User -->|"1 · question"| WebUI
    WebUI -->|"2"| Orch
    Orch -.->|"3 · classify intent"| Bedrock
    Orch -->|"4 · GET /agents?capability="| Registry
    Orch -->|"5 · POST /a2a/task + a2a-* headers"| Prac
    Orch -.-> NL2
    Orch -.-> Pra
    Orch -.-> Fac
    Prac -.->|"6 · reason / pick tools"| Bedrock
    Prac -->|"7 · POST /mcp/v1/tools/call"| MCP
    NL2 --> MCP
    Pra --> MCP
    Fac --> MCP
    MCP -->|"8 · GET /spayer/api/v1/..."| API
    MCP -.->|"NL2SQL direct query"| DB
    API -->|"9 · parameterized SQL"| DB
    Prac -->|"10 · tool_results + context_updates"| Orch
    Orch -->|"11 · POST /a2a/task"| Synth
    Synth -.->|"LLM fallback only"| Bedrock
    Synth -->|"12 · markdown tables"| Orch
    Orch -->|"13 · answer"| WebUI
    WebUI --> User
```

Solid arrows = the path taken for a practitioner query. Dotted arrows = alternative routes or LLM calls.

| Step | From → To | What happens |
|---|---|---|
| 1–2 | Browser → master | User question reaches the orchestrator |
| 3 | master → Bedrock | Router LLM decides entity type (practitioner / practice / facility / nl2sql) |
| 4 | master → registry | Look up which agent serves that capability (cached after first call) |
| 5 | master → specialist | A2A task call, with discovered IDs passed in `a2a-*` headers |
| 6 | specialist → Bedrock | Agent's ReAct loop chooses which tools to call |
| 7 | specialist → mcp | Tool call, e.g. `search_practitioners` |
| 8–9 | mcp → backend → DB | Proxied REST call becomes a parameterized SQL query |
| 10 | specialist → master | Raw `tool_results[]` + newly discovered IDs |
| 11–12 | master → synthesis | Results turned into one markdown table per tool |
| 13 | master → browser | Final answer rendered in chat |

---

## 2. Container map — ports, images, dependencies

```mermaid
flowchart LR
    subgraph Front["Front door"]
        M["master<br/>:7860<br/>Dockerfile.txt"]
    end

    subgraph Control["Discovery"]
        R["registry<br/>:7000<br/>Dockerfile"]
    end

    subgraph Agents["Agents (same base recipe)"]
        A1["practitioner :8001"]
        A2["nl2sql :8002"]
        A3["practice :8003"]
        A4["facility :8004"]
        A5["synthesis :8005"]
    end

    subgraph Data["Data layer (needs ODBC Driver 18)"]
        T["mcp<br/>:8080<br/>Dockerfile"]
        B["spayer-backend<br/>:8000<br/>Docker"]
    end

    M --> R
    M --> A1 & A2 & A3 & A4
    M --> A5
    A1 & A2 & A3 & A4 --> T
    T --> B
    A1 & A2 & A3 & A4 -. "self-register on startup" .-> R
```

---

## 3. Build & deploy flow

```mermaid
flowchart LR
    Src["Repo root<br/>(build context)"] --> Cert["combined.pem<br/>corporate CA cert<br/>⚠ not in repo"]
    Cert --> Build["docker build -f &lt;folder&gt;/Dockerfile ."]
    Build --> Img1["practitioner-agent image"]
    Build --> Img2["practice-agent image"]
    Build --> Img3["facility-agent image"]
    Build --> Img4["... one image per folder"]
    Img1 & Img2 & Img3 & Img4 --> ECR[("AWS ECR<br/>image registry")]
    ECR --> ECS["AWS ECS<br/>one service per image"]
    ECS --> ALB["ALB path routing<br/>/practitioner/* /practice/* ..."]
```

What every agent image contains (same recipe for all five):

```mermaid
flowchart TB
    L1["python:3.11-slim"] --> L2["+ corporate CA cert (combined.pem)"]
    L2 --> L3["+ pip install agents/requirements.txt"]
    L3 --> L4["+ a2a/ contract"]
    L4 --> L5["+ agents/_internal/ shared runtime"]
    L5 --> L6["+ agents/prompts.py"]
    L6 --> L7["+ ONLY its own folder<br/>e.g. agents/practitioner/"]
    L7 --> L8["CMD uvicorn ... --port 800X"]
```

---

## 4. Known build blockers in `poc/`

| Issue | Affects | Fix |
|---|---|---|
| `combined.pem` missing from repo | every image except registry | Place your corporate CA cert at repo root (keep it out of git) |
| Build context must be repo root | all agents, master, mcp, backend | `docker build -f agents/practitioner/Dockerfile .` |
| Registry uses its own folder as context | registry | `cd registry && docker build .` |
| Non-standard filenames | `spayer-backend/Docker`, `master/Dockerfile.txt` | Always pass `-f` explicitly |
| `adk/healthspring_logo_dark.svg` missing | master | Add the file or remove that `COPY` line |
| No `EXPOSE 8000` | spayer-backend | Cosmetic — add for documentation |
| No `docker-compose.yml` | local runs | Use `start-local-a2a.sh`, or add a compose file |

> **poc-strands note:** the same layout applies, minus the `registry` container — agent URLs come from env vars instead.
