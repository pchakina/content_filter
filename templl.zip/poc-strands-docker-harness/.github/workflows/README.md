# .github/workflows

The CI check that has to pass before a change goes in.

## What goes in here

- `verify.yml`. It loads the config for every environment, runs the tests and the evaluation, scans
  the dependencies for known vulnerabilities, scans for committed secrets, and builds every image.

## How this folder helps with the harness

- It scans every change for committed secrets (HAR-023).
- It fails the build if an evaluation category drops below its pass mark (HAR-034).
- It runs the tests that try to break the controls (HAR-035).
- It scans dependencies and builds every image with read-only repository access (HAR-039).

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/.github/workflows/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-023: Secrets management

Secrets must not be embedded in source, prompts, environment files committed to Git or agent messages. Priority P0: has to be done before going live.

**What to build:** Store secrets centrally; retrieve at runtime using workload identity; rotate; restrict secret access per service; scan repositories and deployment artifacts.

**How you know it's done:** Secret scanning finds no committed credentials; rotation works without code change; agents cannot enumerate unrelated secrets.

### HAR-034: Evaluation

Agent quality and safety must be measured before release and continuously after changes. Priority P0: has to be done before going live.

**What to build:** Build datasets for routing, tool selection, parameter accuracy, SQL correctness, groundedness, refusal, PHI leakage and injection resistance; set pass thresholds.

**How you know it's done:** CI blocks releases below thresholds; results are reproducible and versioned by prompt, model, agent and tool version.

### HAR-035: Adversarial testing

The harness must be tested against deliberate policy-bypass attempts. Priority P0: has to be done before going live.

**What to build:** Test prompt injection, role spoofing, cross-tenant access, SQL mutation, SSRF, tool argument manipulation, approval tampering, data exfiltration and agent loops.

**How you know it's done:** P0 attack cases cannot cause unauthorized action or disclosure; findings have owners and remediation deadlines.

### HAR-039: Deployment security

Builds and deployments must be reproducible, scanned and approved. Priority P1: needed to run it reliably in production.

**What to build:** Pin dependencies; generate an SBOM; scan code, containers and IaC; sign artifacts; use least-privilege CI roles; require environment gates.

**How you know it's done:** Critical vulnerabilities block deployment; artifacts are traceable to commit; production deployments require approved gates.
