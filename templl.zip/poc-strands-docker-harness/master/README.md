# master

The front door, on port 7860, and the only service anyone outside can reach. The gateway lets
requests in, the orchestrator sends each one to the right agent and then to synthesis, and the chat
UI is just another client of the gateway.

## What goes in here

- `gateway.py` builds the app and mounts the UI.
- `orchestrator.py` does the routing. It keeps the original routing prompt and the follow-up and
  NL2SQL rules.
- `web_ui.py` is the Gradio chat. It calls `/v1/requests` with the signed-in user's token.
- `Dockerfile` starts the service with `uvicorn --factory master.gateway:create_app`.
- `requirements.txt` adds Strands and Gradio to the shared harness packages.
- `__init__.py`, empty.

## How this folder helps with the harness

- The gateway checks content type, size and prompt length, applies rate and concurrency limits, and
  gives every response a request ID (HAR-001).
- It checks the user's token, and runs the demo login outside production (HAR-002).
- The router model only suggests which agent to use. The registry decides, and each request gets
  at most two agent hops (HAR-008, HAR-010).
- Agent replies are checked against the expected format before they're used (HAR-014).
- Session memory keeps only a short list of allowed fields (HAR-022).
- Sending the same `Idempotency-Key` again returns the first answer instead of running the request
  a second time (HAR-026).
- Auditors can read the audit log and traces at `/v1/audit` and `/v1/traces/{id}` (HAR-030,
  HAR-031).
- Daily request and token budgets are enforced, and usage can be read at `/v1/usage` (HAR-041).

## Before you start

The UI must go through the gateway like any other client. Don't let it call the orchestrator
directly.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/master/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-001: Entry protection

All external requests must enter through a managed, authenticated endpoint. Agents must not be exposed directly to the internet. Priority P0: has to be done before going live.

**What to build:** Terminate TLS at the edge; reject malformed requests; enforce payload-size, content-type, rate and request-time limits; attach a unique request ID.

**How you know it's done:** Direct access to agent runtimes is blocked; TLS is mandatory; invalid or oversized requests are rejected; every accepted request receives a request ID.

### HAR-002: User authentication

Every interactive request must be associated with a verified human or application identity. Priority P0: has to be done before going live.

**What to build:** Validate JWT issuer, audience, signature, expiry and token use. Derive identity only from validated claims, never from prompt text. Support MFA where risk requires it.

**How you know it's done:** Missing, expired, incorrectly signed or wrong-audience tokens return 401; the model cannot alter the authenticated user ID.

### HAR-008: Capability discovery

The orchestrator must select agents using trusted capability metadata rather than arbitrary model-generated URLs. Priority P0: has to be done before going live.

**What to build:** Resolve requested capability against the registry; allowlist permitted caller-to-agent routes; validate protocol and schema versions before dispatch.

**How you know it's done:** The model cannot call a URL supplied in user content; unsupported capabilities return a controlled error; route tests are deterministic.

### HAR-010: Orchestration

Agent selection, delegation and workflow state must be controlled by the harness. Priority P0: has to be done before going live.

**What to build:** Use explicit routing rules for known intents; validate model-proposed delegations; record every hop; prohibit unrestricted recursive delegation.

**How you know it's done:** Every hop is traceable; only allowed routes execute; orchestration produces a terminal success, partial or failure state.

### HAR-014: Tool output validation

Backend and agent results must be treated as untrusted until validated. Priority P0: has to be done before going live.

**What to build:** Check response schema, status, content type, size, provenance and required fields; redact sensitive values; return typed errors for invalid responses.

**How you know it's done:** Malformed, excessive or unauthorized backend fields are blocked; agents cannot forward unvalidated output to users or other agents.

### HAR-022: Memory governance

Agent memory must never become an unverified system of record. Priority P0: has to be done before going live.

**What to build:** Separate session, preference and business state; define permitted memory fields, retention and deletion; require authoritative APIs for claims, patients, prescriptions and payments.

**How you know it's done:** Expired sessions are removed; protected fields are not stored in preference memory; business decisions use current authoritative data.

### HAR-026: Idempotency and deduplication

Retries and repeated A2A deliveries must not create duplicate side effects. Priority P0: has to be done before going live.

**What to build:** Generate or accept an idempotency key; persist request fingerprint and terminal result; reject conflicting reuse; define deduplication windows.

**How you know it's done:** Replaying the same request returns the original result; the same key with different parameters is rejected.

### HAR-030: Audit logging

Security-relevant activity must produce an immutable, queryable audit record. Priority P0: has to be done before going live.

**What to build:** Record actor, agent, action, resource, purpose, authorization decision, tool, timestamp, outcome and correlation ID. Log data access without copying sensitive payloads.

**How you know it's done:** Auditors can reconstruct who accessed which resource and why; audit retention and tamper-protection meet policy; PHI is minimized.

### HAR-031: Distributed tracing

A request must be traceable across orchestrator, agents, tools, APIs and asynchronous messages. Priority P1: needed to run it reliably in production.

**What to build:** Propagate trace, request and correlation IDs; create spans for model calls, agent hops, tools and dependencies; mask sensitive attributes.

**How you know it's done:** One trace shows the complete path and latency breakdown; asynchronous continuations retain correlation; sensitive values are absent.

### HAR-041: Cost governance

Model and infrastructure expenditure must be observable and bounded by tenant, use case and agent. Priority P1: needed to run it reliably in production.

**What to build:** Attribute usage; set token and request budgets; cache only safe reusable results; alarm on anomalies; apply quotas and throttling.

**How you know it's done:** Cost can be reported per agent/use case; abnormal usage alarms fire; a single user cannot create unbounded spend.
