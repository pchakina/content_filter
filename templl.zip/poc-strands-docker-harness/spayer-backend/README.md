# spayer-backend

The sPayer REST API on top of MS-SQL, on port 8000. The routes are the same as before. What's new
is a check on who's calling, safer error messages, and a read-only way to run checked SQL.

## What goes in here

- `main.py` sets up the app, installs the caller check and adds the routes.
- `harness_guard.py` is the caller check.
- `config.py` holds the database settings, `database.py` the connection and queries, and `error.py`
  the error responses.
- `Dockerfile` installs the ODBC 18 driver and runs as a non-root user.
- `requirements.txt` adds pyodbc, SQLAlchemy and pydantic-settings to the shared harness packages.
- `readme.md` holds the original notes.

## How this folder helps with the harness

- Only MCP can call the data routes, and only with a valid user context (HAR-003, HAR-006).
- The database password is read from a mounted file, not an environment variable (HAR-023).
- The connection is encrypted, and the server certificate is checked unless you turn that off for
  a local test server (HAR-024).
- Error messages and normal logs no longer include SQL text or driver messages (HAR-018, HAR-029).
- `execute_readonly` runs checked SQL on a read-only connection, with a timeout and a row limit,
  and always rolls back (HAR-015).

## Before you start

Connect with a database login that can only read (`db_datareader`).

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/spayer-backend/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-003: Agent authentication

Every agent and service must have a distinct workload identity for A2A and tool calls. Priority P0: has to be done before going live.

**What to build:** Assign separate IAM roles; use short-lived credentials and signed service calls; prohibit shared long-lived access keys.

**How you know it's done:** CloudTrail identifies the calling workload; one agent's credentials cannot invoke unauthorized services; no static AWS key is stored in code.

### HAR-006: Trusted security context

Verified identity and authorization attributes must be kept separate from model-controlled content. Priority P0: has to be done before going live.

**What to build:** Create an immutable security-context object after authentication; pass it through runtime context, not prompts or model-generated tool arguments; prevent downstream agents from replacing it.

**How you know it's done:** A model-generated role, user ID or approval flag is ignored; all downstream calls retain the original verified identity and correlation ID.

### HAR-015: NL-to-SQL safety

Generated SQL must be read-only, scoped, bounded and validated independently of the model. Priority P0: has to be done before going live.

**What to build:** Parse the SQL AST; allowlist schemas, tables, columns and functions; block DDL/DML and multi-statements; inject tenant filters; set row, time and scan limits; use read-only credentials.

**How you know it's done:** `DROP`, `DELETE`, `UPDATE`, unrestricted cross-tenant and unbounded queries are rejected; all approved queries include required scoping and limits.

### HAR-018: PHI/PII protection

Sensitive identifiers and healthcare data must be minimized throughout the agent lifecycle. Priority P0: has to be done before going live.

**What to build:** Classify fields; mask/tokenize SSNs; avoid sending raw identifiers to the LLM; redact logs and traces; prevent sensitive data from entering long-term memory; encrypt in transit and at rest.

**How you know it's done:** Raw SSNs, tokens and prohibited PHI do not appear in prompts, logs, traces or errors; redaction and data-minimization tests pass.

### HAR-023: Secrets management

Secrets must not be embedded in source, prompts, environment files committed to Git or agent messages. Priority P0: has to be done before going live.

**What to build:** Store secrets centrally; retrieve at runtime using workload identity; rotate; restrict secret access per service; scan repositories and deployment artifacts.

**How you know it's done:** Secret scanning finds no committed credentials; rotation works without code change; agents cannot enumerate unrelated secrets.

### HAR-024: Network isolation

Agent, database and internal API traffic must follow least-access network paths. Priority P0: has to be done before going live.

**What to build:** Use private subnets/endpoints where feasible; restrict security groups and egress; deny arbitrary outbound destinations; use TLS and private DNS.

**How you know it's done:** Databases have no public endpoint; unapproved outbound connections fail; network-flow tests match the approved architecture.

### HAR-029: Error handling

Errors must be typed, safe and actionable without exposing internals or PHI. Priority P0: has to be done before going live.

**What to build:** Define validation, authentication, authorization, dependency, timeout, limit and internal-error codes; map them consistently; retain detailed internal diagnostics securely.

**How you know it's done:** Client errors contain no stack trace, SQL, secret or PHI; operations can distinguish retryable from non-retryable failures.
