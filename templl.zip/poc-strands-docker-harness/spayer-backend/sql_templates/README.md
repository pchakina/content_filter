# spayer-backend/sql_templates

The fixed SQL behind the API routes.

## What goes in here

- `practitioner.py`, `practice.py` and `facility.py`. Copy them over unchanged.

## How this folder helps with the harness

Nothing here needed to change. The queries already pass values as parameters rather than gluing
them into the SQL.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/spayer-backend/sql_templates/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../../HARNESS_GUIDE.md) has the full folder map and the order to add things in.
