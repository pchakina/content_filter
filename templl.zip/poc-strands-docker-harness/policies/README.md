# policies

The security rules. The harness applies them in code, outside any model, so no prompt can talk its
way around them.

## What goes in here

- `authorization.yaml` holds the access rules. A request is allowed only if a rule matches the
  user's role, the agent, the action, the purpose and the kind of data. Everything else is denied
  (HAR-004).
- `data_classification.yaml` says what to do with each sPayer column. SSNs are masked, birth dates
  and similar fields are removed, and free-text notes are checked for hidden instructions
  (HAR-018, HAR-019).
- `sql.yaml` controls which tables, columns and functions generated SQL may use, and sets the row
  and time limits (HAR-015).

## Before you start

Whenever you change a policy, add a test showing what the change now allows and what it still
blocks.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/policies/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-004: Authorization

Access must be decided by deterministic policy outside the language model. Priority P0: has to be done before going live.

**What to build:** Enforce RBAC plus ABAC using user role, agent identity, tenant, organization, resource, action, data class and purpose of use. Re-authorize at every protected tool.

**How you know it's done:** Unauthorized requests return 403; changing prompt text cannot elevate privileges; policy tests cover allow, deny and default-deny behavior.

### HAR-015: NL-to-SQL safety

Generated SQL must be read-only, scoped, bounded and validated independently of the model. Priority P0: has to be done before going live.

**What to build:** Parse the SQL AST; allowlist schemas, tables, columns and functions; block DDL/DML and multi-statements; inject tenant filters; set row, time and scan limits; use read-only credentials.

**How you know it's done:** `DROP`, `DELETE`, `UPDATE`, unrestricted cross-tenant and unbounded queries are rejected; all approved queries include required scoping and limits.

### HAR-018: PHI/PII protection

Sensitive identifiers and healthcare data must be minimized throughout the agent lifecycle. Priority P0: has to be done before going live.

**What to build:** Classify fields; mask/tokenize SSNs; avoid sending raw identifiers to the LLM; redact logs and traces; prevent sensitive data from entering long-term memory; encrypt in transit and at rest.

**How you know it's done:** Raw SSNs, tokens and prohibited PHI do not appear in prompts, logs, traces or errors; redaction and data-minimization tests pass.

### HAR-019: Prompt-injection defense

Instructions contained in user input, retrieved records or agent responses must not override trusted policy. Priority P0: has to be done before going live.

**What to build:** Mark untrusted content; isolate system policy; detect suspicious instructions; deny privilege changes; re-authorize tool calls; restrict context and tool access regardless of prompt.

**How you know it's done:** Injection attempts cannot reveal secrets, register tools, change identity, remove SQL restrictions or bypass approval.
