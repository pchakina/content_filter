# docs

The written record of what was done for each requirement.

## What goes in here

- `HARNESS_REQUIREMENTS.md`. Copy it from the finished version, then keep each requirement's status
  current as the code goes in.

## How this folder helps with the harness

For now this is the only compliance evidence in the repo (HAR-042).

## Before you start

When a commit changes how a requirement is handled, update that requirement's section in the same
commit.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/docs/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-042: Compliance evidence

The system must retain evidence of security controls and operational procedures required for healthcare use. Priority P0: has to be done before going live.

**What to build:** Maintain data-flow diagrams, threat model, access reviews, risk assessments, BAAs where applicable, incident procedures, training records and control-test evidence.

**How you know it's done:** Required evidence is current, assigned and reviewable; access reviews and incident exercises occur on schedule.
