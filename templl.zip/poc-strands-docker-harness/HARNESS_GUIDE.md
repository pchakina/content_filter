# Developer guide

We're building this repo up one piece at a time. The first commit was just the empty folders. Every
folder now has a README that explains what belongs in it, which harness requirements it covers, and
what those requirements say. The requirements come from
`C:\praveen\AI\req\A2A_Harness_Engineering_Requirements.md`.

A finished version already exists next to this repo, in `poc-strands-docker-harness-full`, and its
tests pass. Copy from it one step at a time. Please leave `poc-strands-docker` alone; that's the
original project.

## The folders

| Folder | What it's for | Requirements |
|---|---|---|
| [`agents/`](agents/README.md) | This is where the five agents live: practitioner, practice, facility, NL2SQL and synthesis. | HAR-010, HAR-021 |
| [`agents/_internal/`](agents/_internal/README.md) | This is the shared runtime behind every agent. | HAR-003, HAR-004, HAR-006, HAR-009, HAR-011, HAR-012, HAR-019, HAR-020, HAR-027, HAR-033 |
| [`agents/practitioner/`](agents/practitioner/README.md) | The practitioner agent, on port 8001. | HAR-007, HAR-021, HAR-033 |
| [`agents/practice/`](agents/practice/README.md) | The practice agent, on port 8003. | HAR-007, HAR-021, HAR-033 |
| [`agents/facility/`](agents/facility/README.md) | The facility agent, on port 8004. | HAR-007, HAR-021, HAR-033 |
| [`agents/nl2sql/`](agents/nl2sql/README.md) | The NL2SQL agent, on port 8002, for free-form database questions. | HAR-004, HAR-015 |
| [`agents/synthesis/`](agents/synthesis/README.md) | The synthesis agent, on port 8005. | HAR-018, HAR-019, HAR-021, HAR-033 |
| [`contracts/`](contracts/README.md) | These are the message formats every service uses when it talks to another, plus the one error type they all raise. | HAR-009, HAR-029, HAR-040 |
| [`harness/`](harness/README.md) | The shared library that every service uses. | HAR-002, HAR-003, HAR-004, HAR-006, HAR-007, HAR-008, HAR-011, HAR-012, HAR-013, HAR-014, HAR-018, HAR-019, HAR-020, HAR-022, HAR-025, HAR-026, HAR-027, HAR-028, HAR-029, HAR-030, HAR-031, HAR-032, HAR-033, HAR-036, HAR-038 |
| [`config/`](config/README.md) | Everything that changes between environments, or that should be reviewed the way policy is: the agent registry, routes, tool allowlist, tenants, models, limits and retention. | HAR-038 |
| [`config/base/`](config/base/README.md) | The default configuration, one YAML file per topic. | HAR-001, HAR-002, HAR-005, HAR-006, HAR-007, HAR-008, HAR-010, HAR-011, HAR-012, HAR-016, HAR-022, HAR-027, HAR-028, HAR-033, HAR-036, HAR-041 |
| [`config/environments/`](config/environments/README.md) | Small files that adjust the base configuration for each environment. | HAR-002, HAR-033, HAR-038 |
| [`policies/`](policies/README.md) | The security rules. | HAR-004, HAR-015, HAR-018, HAR-019 |
| [`master/`](master/README.md) | The front door, on port 7860, and the only service anyone outside can reach. | HAR-001, HAR-002, HAR-008, HAR-010, HAR-014, HAR-022, HAR-026, HAR-030, HAR-031, HAR-041 |
| [`mcp/`](mcp/README.md) | The tool server, on port 8080. | HAR-005, HAR-011, HAR-012, HAR-013, HAR-014, HAR-015, HAR-018, HAR-019 |
| [`mcp/n2sql/`](mcp/n2sql/README.md) | Material for turning questions into SQL: the extracted database schema and the prompts. | HAR-015 |
| [`mcp/n2sql/prompts/`](mcp/n2sql/prompts/README.md) | Prompt text, one file per entity, for the SQL generator once there is one. | HAR-015 |
| [`mcp/n2sql/schemas/`](mcp/n2sql/schemas/README.md) | The table and column definitions extracted from the database, one set per domain. | HAR-015 |
| [`mcp/n2sql/schemas/tables/`](mcp/n2sql/schemas/tables/README.md) | Plain-text lists of table names, one file per domain. | HAR-015 |
| [`mcp/n2sql/scripts/`](mcp/n2sql/scripts/README.md) | Tools for keeping the schema files current. | HAR-015 |
| [`spayer-backend/`](spayer-backend/README.md) | The sPayer REST API on top of MS-SQL, on port 8000. | HAR-003, HAR-006, HAR-015, HAR-018, HAR-023, HAR-024, HAR-029 |
| [`spayer-backend/routes/`](spayer-backend/routes/README.md) | The API endpoints. | HAR-015 |
| [`spayer-backend/sql_templates/`](spayer-backend/sql_templates/README.md) | The fixed SQL behind the API routes. | none |
| [`tests/`](tests/README.md) | The automated tests. | HAR-035 |
| [`evals/`](evals/README.md) | The evaluation run. | HAR-034 |
| [`scripts/`](scripts/README.md) | Small tools for developers. | HAR-003, HAR-023 |
| [`docs/`](docs/README.md) | The written record of what was done for each requirement. | HAR-042 |
| [`certs/`](certs/README.md) | Somewhere to put your company's root certificate if builds run behind a proxy that inspects TLS. | HAR-039 |
| [`.github/workflows/`](.github/workflows/README.md) | The CI check that has to pass before a change goes in. | HAR-023, HAR-034, HAR-035, HAR-039 |

| [`infra/`](infra/README.md) | Everything needed to run this system on AWS ECS, written in Terraform and driven by Terragrunt. | HAR-038, HAR-039 |
| [`infra/modules/`](infra/modules/README.md) | Reusable Terraform modules, one folder each. | none |
| [`infra/modules/network/`](infra/modules/network/README.md) | The VPC the whole system runs in. | HAR-024 |
| [`infra/modules/ecr/`](infra/modules/ecr/README.md) | The image repositories, one per service: `master`, `mcp`, `spayer-backend`, and the five agents. | HAR-039 |
| [`infra/modules/ecs-cluster/`](infra/modules/ecs-cluster/README.md) | The ECS cluster and the private DNS namespace the services use to find each other. | HAR-008 |
| [`infra/modules/ecs-service/`](infra/modules/ecs-service/README.md) | One ECS service: a task definition, a service and its security group. | HAR-003, HAR-024, HAR-037 |
| [`infra/modules/alb/`](infra/modules/alb/README.md) | The public entry point. | HAR-001 |
| [`infra/modules/iam/`](infra/modules/iam/README.md) | The roles each service runs with. | HAR-003, HAR-023, HAR-033 |
| [`infra/modules/secrets/`](infra/modules/secrets/README.md) | The Secrets Manager entries the services read at startup. | HAR-023 |
| [`infra/modules/storage/`](infra/modules/storage/README.md) | Where the harness keeps its state: the audit log, trace spans, sessions, idempotency records, counters and usage. | HAR-025, HAR-030, HAR-036 |
| [`infra/modules/observability/`](infra/modules/observability/README.md) | Logs, alarms and dashboards. | HAR-030, HAR-031, HAR-032 |
| [`infra/live/`](infra/live/README.md) | The Terragrunt configuration for each environment. | HAR-038 |
| [`infra/live/dev/`](infra/live/dev/README.md) | The development environment. | none |
| [`infra/live/dev/services/`](infra/live/dev/services/README.md) | One folder per service: `master`, `mcp`, `spayer-backend`, `practitioner-agent`, `practice-agent`, `facility-agent`, `nl2sql-agent` and `synthesis-agent`. | HAR-003, HAR-024 |
| [`infra/live/prod/`](infra/live/prod/README.md) | The production environment. | HAR-037, HAR-038 |

A few folders stay out of Git on purpose, and the scripts create them when they're needed:
`secrets/` (signing keys and the database password file), `data/` (the local audit log, traces,
sessions and usage), `.venv/`, `.pytest_tmp/` and `evals/results/`.

## The order we suggest adding things

1. `contracts/`. Everything else imports it.
2. `harness/`, `config/` and `policies/` together, plus `mcp/spayer-tools-registry.json` and
   `mcp/n2sql/schemas/`, because the config loader reads them. Before committing, check that the
   config loads for every environment.
3. The data layer: `mcp/` and `spayer-backend/`. Check with `tests/test_tools_sql_and_data.py`.
4. `agents/_internal/`, then each agent.
5. `master/`. By this point the whole test suite should pass.
6. `tests/`, `evals/` and `scripts/`. Run `pytest`, `evals/run.py` and `scripts/live_checks.py`.
7. The Dockerfiles, `docker-compose.yml`, `.env.example` and `.github/workflows/`. Check with
   `docker compose up`.
8. `docs/` and the root `README.md`.
9. `infra/`, to deploy to AWS ECS. Start with `live/dev`; see `infra/README.md`.

## A few house rules

- Changes to config and policies control security, so get them reviewed like code.
- When you add or change a control, put its tests in the same commit.
- Update that requirement's section in `docs/HARNESS_REQUIREMENTS.md` too: its status, files and
  tests, and anything still missing.
- Never commit `secrets/`, `.env`, keys, passwords or real patient or provider data.
- Build each service with a `create_app(...)` function instead of a module-level app, so the tests
  can set it up with their own settings.

## All 42 requirements

| ID | Topic | Priority | What it asks for |
|---|---|---|---|
| HAR-001 | Entry protection | P0 | All external requests must enter through a managed, authenticated endpoint. Agents must not be exposed directly to the internet. |
| HAR-002 | User authentication | P0 | Every interactive request must be associated with a verified human or application identity. |
| HAR-003 | Agent authentication | P0 | Every agent and service must have a distinct workload identity for A2A and tool calls. |
| HAR-004 | Authorization | P0 | Access must be decided by deterministic policy outside the language model. |
| HAR-005 | Tenant and record isolation | P0 | Authorized users must see only permitted organizations, patients, providers, claims or accounts. |
| HAR-006 | Trusted security context | P0 | Verified identity and authorization attributes must be kept separate from model-controlled content. |
| HAR-007 | Agent registry | P0 | Only registered and approved agents may participate in the A2A system. |
| HAR-008 | Capability discovery | P0 | The orchestrator must select agents using trusted capability metadata rather than arbitrary model-generated URLs. |
| HAR-009 | Standard A2A contract | P0 | All agents must use versioned request, response and error envelopes. |
| HAR-010 | Orchestration | P0 | Agent selection, delegation and workflow state must be controlled by the harness. |
| HAR-011 | Execution limits | P0 | Each request must have bounded time, turns, tokens, agent hops, tool calls, concurrency and cost. |
| HAR-012 | Tool allowlisting | P0 | Agents may invoke only explicitly registered tools appropriate to their role and task. |
| HAR-013 | Tool input validation | P0 | Every tool call must be validated before it reaches a backend. |
| HAR-014 | Tool output validation | P0 | Backend and agent results must be treated as untrusted until validated. |
| HAR-015 | NL-to-SQL safety | P0 | Generated SQL must be read-only, scoped, bounded and validated independently of the model. |
| HAR-016 | API action safety | P0 | Side-effecting backend actions must be idempotent, authorized and separately controlled. |
| HAR-017 | Human approval | P0 | Sensitive or irreversible actions must pause for an authorized human decision. |
| HAR-018 | PHI/PII protection | P0 | Sensitive identifiers and healthcare data must be minimized throughout the agent lifecycle. |
| HAR-019 | Prompt-injection defense | P0 | Instructions contained in user input, retrieved records or agent responses must not override trusted policy. |
| HAR-020 | Model output grounding | P1 | Material factual or operational claims must be connected to authoritative tool results. |
| HAR-021 | Conversation context | P0 | Only the minimum relevant, authorized context should be sent to each model or downstream agent. |
| HAR-022 | Memory governance | P0 | Agent memory must never become an unverified system of record. |
| HAR-023 | Secrets management | P0 | Secrets must not be embedded in source, prompts, environment files committed to Git or agent messages. |
| HAR-024 | Network isolation | P0 | Agent, database and internal API traffic must follow least-access network paths. |
| HAR-025 | State management | P1 | Workflow, session and business state must be separated and consistently managed. |
| HAR-026 | Idempotency and deduplication | P0 | Retries and repeated A2A deliveries must not create duplicate side effects. |
| HAR-027 | Timeouts and cancellation | P1 | Deadlines must be enforced end to end rather than independently by each agent. |
| HAR-028 | Retries and circuit breaking | P1 | Transient failures must be retried safely without amplifying outages or repeating unsafe actions. |
| HAR-029 | Error handling | P0 | Errors must be typed, safe and actionable without exposing internals or PHI. |
| HAR-030 | Audit logging | P0 | Security-relevant activity must produce an immutable, queryable audit record. |
| HAR-031 | Distributed tracing | P1 | A request must be traceable across orchestrator, agents, tools, APIs and asynchronous messages. |
| HAR-032 | Metrics and alerting | P1 | The platform must expose operational, model, security and cost health. |
| HAR-033 | Model governance | P0 | Models and inference parameters must be explicitly approved and version-controlled. |
| HAR-034 | Evaluation | P0 | Agent quality and safety must be measured before release and continuously after changes. |
| HAR-035 | Adversarial testing | P0 | The harness must be tested against deliberate policy-bypass attempts. |
| HAR-036 | Data retention and deletion | P0 | Retention periods must be defined separately for prompts, responses, traces, audit events, workflow state and memory. |
| HAR-037 | High availability and recovery | P1 | Critical components must tolerate expected failures and have documented recovery objectives. |
| HAR-038 | Configuration management | P1 | Environment-specific agent, model, routing, policy and limit configuration must be externalized and versioned. |
| HAR-039 | Deployment security | P1 | Builds and deployments must be reproducible, scanned and approved. |
| HAR-040 | Version compatibility | P1 | A2A agents and message schemas must evolve without silently breaking active workflows. |
| HAR-041 | Cost governance | P1 | Model and infrastructure expenditure must be observable and bounded by tenant, use case and agent. |
| HAR-042 | Compliance evidence | P0 | The system must retain evidence of security controls and operational procedures required for healthcare use. |
