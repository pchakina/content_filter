# mcp/n2sql

Material for turning questions into SQL: the extracted database schema and the prompts. The schema
files also decide which tables and columns generated SQL may use.

## What goes in here

- `prompts/` holds the prompt text for each entity.
- `schemas/` holds the extracted tables and columns.
- `scripts/` holds the tool that extracts the schema.

## How this folder helps with the harness

Generated SQL may only touch the tables and columns listed in `schemas/` (HAR-015).

## Before you start

When someone writes a SQL generator, it goes here (for example `generator.py` with
`generate_sql(question)`). It only suggests SQL. MCP checks it and the backend runs it.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/mcp/n2sql/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-015: NL-to-SQL safety

Generated SQL must be read-only, scoped, bounded and validated independently of the model. Priority P0: has to be done before going live.

**What to build:** Parse the SQL AST; allowlist schemas, tables, columns and functions; block DDL/DML and multi-statements; inject tenant filters; set row, time and scan limits; use read-only credentials.

**How you know it's done:** `DROP`, `DELETE`, `UPDATE`, unrestricted cross-tenant and unbounded queries are rejected; all approved queries include required scoping and limits.
