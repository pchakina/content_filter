# mcp/n2sql/schemas/tables

Plain-text lists of table names, one file per domain.

## What goes in here

- The `*_tables.txt` files. Copy them over unchanged.

## How this folder helps with the harness

They're a quick reference for which tables generated SQL may use (HAR-015).

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/mcp/n2sql/schemas/tables/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../../../../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-015: NL-to-SQL safety

Generated SQL must be read-only, scoped, bounded and validated independently of the model. Priority P0: has to be done before going live.

**What to build:** Parse the SQL AST; allowlist schemas, tables, columns and functions; block DDL/DML and multi-statements; inject tenant filters; set row, time and scan limits; use read-only credentials.

**How you know it's done:** `DROP`, `DELETE`, `UPDATE`, unrestricted cross-tenant and unbounded queries are rejected; all approved queries include required scoping and limits.
