# mcp/n2sql/schemas

The table and column definitions extracted from the database, one set per domain.

## What goes in here

- The `*_schema.json` and `*_domain.json` files, plus `SCHEMA_METADATA.md`. Copy them over
  unchanged.
- `tables/`, with the plain table lists.

## How this folder helps with the harness

`harness/config.py` reads these files to build the list of tables and columns SQL may use, minus the
restricted columns in `policies/sql.yaml` (HAR-015).

## Before you start

When the database changes, re-run `scripts/extract_schema.py`, then run the tests again.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/mcp/n2sql/schemas/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../../../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-015: NL-to-SQL safety

Generated SQL must be read-only, scoped, bounded and validated independently of the model. Priority P0: has to be done before going live.

**What to build:** Parse the SQL AST; allowlist schemas, tables, columns and functions; block DDL/DML and multi-statements; inject tenant filters; set row, time and scan limits; use read-only credentials.

**How you know it's done:** `DROP`, `DELETE`, `UPDATE`, unrestricted cross-tenant and unbounded queries are rejected; all approved queries include required scoping and limits.
