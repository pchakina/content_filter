# mcp/n2sql/scripts

Tools for keeping the schema files current.

## What goes in here

- `extract_schema.py`, which pulls the schema out of the database. Copy it over unchanged.

## How this folder helps with the harness

It keeps the SQL allowlist in step with the real database (HAR-015).

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/mcp/n2sql/scripts/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../../../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-015: NL-to-SQL safety

Generated SQL must be read-only, scoped, bounded and validated independently of the model. Priority P0: has to be done before going live.

**What to build:** Parse the SQL AST; allowlist schemas, tables, columns and functions; block DDL/DML and multi-statements; inject tenant filters; set row, time and scan limits; use read-only credentials.

**How you know it's done:** `DROP`, `DELETE`, `UPDATE`, unrestricted cross-tenant and unbounded queries are rejected; all approved queries include required scoping and limits.
