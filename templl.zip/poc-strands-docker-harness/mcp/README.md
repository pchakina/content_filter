# mcp

The tool server, on port 8080. It's the only service allowed to call the sPayer backend, so every
tool call an agent makes passes through here. For each call it checks, in order: who's calling, the
user's context, whether the tenant can see this data, whether the agent may use this tool, the
tool-call budget, the user's permissions and the arguments. Only then does it call the backend.
Afterwards it cleans up the result and writes an audit record.

## What goes in here

- `server_http.py` is the service itself.
- `tool_schemas.py` builds strict argument checks for every tool from the registry.
- `sql_guard.py` checks generated SQL before it can run.
- `spayer-tools-registry.json` defines the tools. Copy it from `poc-strands-docker/mcp/`.
- `Dockerfile` starts the service with `uvicorn --factory server_http:create_app`.
- `requirements.txt` has the shared harness packages only. MCP never calls a model.
- `README.txt` holds the original notes.

## How this folder helps with the harness

- Before any backend call, it checks that the tenant is allowed to read sPayer data (HAR-005).
- It keeps its own count of tool calls per request, separate from the agent's (HAR-011).
- Each agent sees only its own tools, and unknown tools are refused (HAR-012).
- Every argument is checked for type, length and format. That includes NPI check digits, TINs,
  state codes and dates, and unexpected arguments are refused (HAR-013).
- Backend results must have the expected shape and size (HAR-014). Sensitive fields are masked or
  removed (HAR-018), and text that looks like instructions is taken out (HAR-019).
- Generated SQL has to pass `sql_guard.py`: one read-only query, only allowed tables and columns,
  and a row limit (HAR-015).

## Before you start

Don't add an `mcp/__init__.py`. There's a pip package also called `mcp` that Strands depends on, and
this folder would hide it. The tests put `mcp/` on the Python path instead.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/mcp/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-005: Tenant and record isolation

Authorized users must see only permitted organizations, patients, providers, claims or accounts. Priority P0: has to be done before going live.

**What to build:** Propagate a trusted tenant/organization ID; inject mandatory scope filters server-side; apply record-level authorization after retrieval as defense in depth.

**How you know it's done:** Cross-tenant test cases return no data; removing tenant information produces a denial rather than an unrestricted query.

### HAR-011: Execution limits

Each request must have bounded time, turns, tokens, agent hops, tool calls, concurrency and cost. Priority P0: has to be done before going live.

**What to build:** Apply per-request budgets; propagate deadlines and cancellation to child agents; stop loops; limit parallel fan-out; return a clear stop reason.

**How you know it's done:** Infinite-loop and fan-out tests terminate within configured limits; cancellations reach downstream work; budget exhaustion does not corrupt state.

### HAR-012: Tool allowlisting

Agents may invoke only explicitly registered tools appropriate to their role and task. Priority P0: has to be done before going live.

**What to build:** Register tools at construction; separate read and write tools; prohibit dynamic code execution, arbitrary URLs and unrestricted shell/database access.

**How you know it's done:** Unregistered tool requests fail closed; each agent exposes only its approved tool set; tool inventory is reviewable.

### HAR-013: Tool input validation

Every tool call must be validated before it reaches a backend. Priority P0: has to be done before going live.

**What to build:** Use typed schemas; validate formats, ranges, enums and identifiers; normalize NPI and dates; reject extra fields; limit string and collection sizes.

**How you know it's done:** Invalid input never reaches the backend; boundary, malformed and injection test cases produce controlled validation errors.

### HAR-014: Tool output validation

Backend and agent results must be treated as untrusted until validated. Priority P0: has to be done before going live.

**What to build:** Check response schema, status, content type, size, provenance and required fields; redact sensitive values; return typed errors for invalid responses.

**How you know it's done:** Malformed, excessive or unauthorized backend fields are blocked; agents cannot forward unvalidated output to users or other agents.

### HAR-015: NL-to-SQL safety

Generated SQL must be read-only, scoped, bounded and validated independently of the model. Priority P0: has to be done before going live.

**What to build:** Parse the SQL AST; allowlist schemas, tables, columns and functions; block DDL/DML and multi-statements; inject tenant filters; set row, time and scan limits; use read-only credentials.

**How you know it's done:** `DROP`, `DELETE`, `UPDATE`, unrestricted cross-tenant and unbounded queries are rejected; all approved queries include required scoping and limits.

### HAR-018: PHI/PII protection

Sensitive identifiers and healthcare data must be minimized throughout the agent lifecycle. Priority P0: has to be done before going live.

**What to build:** Classify fields; mask/tokenize SSNs; avoid sending raw identifiers to the LLM; redact logs and traces; prevent sensitive data from entering long-term memory; encrypt in transit and at rest.

**How you know it's done:** Raw SSNs, tokens and prohibited PHI do not appear in prompts, logs, traces or errors; redaction and data-minimization tests pass.

### HAR-019: Prompt-injection defense

Instructions contained in user input, retrieved records or agent responses must not override trusted policy. Priority P0: has to be done before going live.

**What to build:** Mark untrusted content; isolate system policy; detect suspicious instructions; deny privilege changes; re-authorize tool calls; restrict context and tool access regardless of prompt.

**How you know it's done:** Injection attempts cannot reveal secrets, register tools, change identity, remove SQL restrictions or bypass approval.
