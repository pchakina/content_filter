# config/environments

Small files that adjust the base configuration for each environment. Each one also has an
`endpoints:` list with the addresses of the services in that environment.

## What goes in here

- `local.yaml`, for running on a laptop with everything on localhost.
- `docker.yaml`, for Docker Compose, using the service names.
- `test.yaml`, for the tests and evaluations. It switches every model to the scripted stand-in, so
  no AWS calls are made.
- `prod.yaml`, for production. The demo login is switched off, so a real identity provider has to be
  configured.

## How this folder helps with the harness

Each environment keeps its own settings (HAR-038). The demo login only works in local, docker and
test (HAR-002). Production refuses the scripted model (HAR-033).

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/config/environments/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-002: User authentication

Every interactive request must be associated with a verified human or application identity. Priority P0: has to be done before going live.

**What to build:** Validate JWT issuer, audience, signature, expiry and token use. Derive identity only from validated claims, never from prompt text. Support MFA where risk requires it.

**How you know it's done:** Missing, expired, incorrectly signed or wrong-audience tokens return 401; the model cannot alter the authenticated user ID.

### HAR-033: Model governance

Models and inference parameters must be explicitly approved and version-controlled. Priority P0: has to be done before going live.

**What to build:** Maintain allowlisted model IDs, regions, use cases, parameters and fallback order; test before upgrade; prevent agents from choosing arbitrary models.

**How you know it's done:** Unapproved models cannot be invoked; model changes pass evaluation gates and are visible in deployment history.

### HAR-038: Configuration management

Environment-specific agent, model, routing, policy and limit configuration must be externalized and versioned. Priority P1: needed to run it reliably in production.

**What to build:** Separate dev/test/prod; validate configuration schema; use controlled promotion; prohibit manual production drift.

**How you know it's done:** Configuration changes are reviewed, auditable and reversible; invalid configuration cannot deploy; drift is detected.
