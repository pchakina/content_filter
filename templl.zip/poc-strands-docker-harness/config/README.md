# config

Everything that changes between environments, or that should be reviewed the way policy is: the
agent registry, routes, tool allowlist, tenants, models, limits and retention.

## What goes in here

- `base/` holds the shared defaults.
- `environments/` holds a small file per environment that adjusts them.

## How this folder helps with the harness

Configuration lives outside the code, comes in separate versions for each environment, and is
checked when a service starts. A service with bad configuration simply won't start (HAR-038).

## Before you start

`HARNESS_ENV` picks the environment: local, docker, test or prod. To check a change, run
`python -c "from harness.config import load_settings; load_settings('prod')"`.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/config/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-038: Configuration management

Environment-specific agent, model, routing, policy and limit configuration must be externalized and versioned. Priority P1: needed to run it reliably in production.

**What to build:** Separate dev/test/prod; validate configuration schema; use controlled promotion; prohibit manual production drift.

**How you know it's done:** Configuration changes are reviewed, auditable and reversible; invalid configuration cannot deploy; drift is detected.
