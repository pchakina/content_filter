# config/base

The default configuration, one YAML file per topic.

## What goes in here

- `agents.yaml` is the agent registry: each agent's version, address, owner, capabilities, who may
  call it, and whether it's enabled (HAR-007). It also lists who may call each internal service.
- `routes.yaml` says which caller may reach which agent for which capability, and which entity
  names the router is allowed to pick (HAR-008, HAR-010).
- `tools.yaml` lists which tools each agent may use and whether each tool reads or writes
  (HAR-012). Write tools are refused for now (HAR-016).
- `tenants.yaml` says which tenants may read which data sources (HAR-005).
- `auth.yaml` sets the token issuer and audience, which service may sign the security context, and
  the demo users (HAR-002, HAR-006).
- `models.yaml` lists the approved models and which one each service uses (HAR-033).
- `limits.yaml` sets the request size, time, rate, turn, token, tool-call, hop, retry and budget
  limits (HAR-001, HAR-011, HAR-027, HAR-028, HAR-041).
- `retention.yaml` sets how long each kind of data is kept, and which fields session memory may
  hold (HAR-022, HAR-036).

## Before you start

`tools.yaml` has to match `mcp/spayer-tools-registry.json`, so regenerate it whenever the registry
changes. Anything in this folder affects security, so get changes reviewed like code.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/config/base/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-001: Entry protection

All external requests must enter through a managed, authenticated endpoint. Agents must not be exposed directly to the internet. Priority P0: has to be done before going live.

**What to build:** Terminate TLS at the edge; reject malformed requests; enforce payload-size, content-type, rate and request-time limits; attach a unique request ID.

**How you know it's done:** Direct access to agent runtimes is blocked; TLS is mandatory; invalid or oversized requests are rejected; every accepted request receives a request ID.

### HAR-002: User authentication

Every interactive request must be associated with a verified human or application identity. Priority P0: has to be done before going live.

**What to build:** Validate JWT issuer, audience, signature, expiry and token use. Derive identity only from validated claims, never from prompt text. Support MFA where risk requires it.

**How you know it's done:** Missing, expired, incorrectly signed or wrong-audience tokens return 401; the model cannot alter the authenticated user ID.

### HAR-005: Tenant and record isolation

Authorized users must see only permitted organizations, patients, providers, claims or accounts. Priority P0: has to be done before going live.

**What to build:** Propagate a trusted tenant/organization ID; inject mandatory scope filters server-side; apply record-level authorization after retrieval as defense in depth.

**How you know it's done:** Cross-tenant test cases return no data; removing tenant information produces a denial rather than an unrestricted query.

### HAR-006: Trusted security context

Verified identity and authorization attributes must be kept separate from model-controlled content. Priority P0: has to be done before going live.

**What to build:** Create an immutable security-context object after authentication; pass it through runtime context, not prompts or model-generated tool arguments; prevent downstream agents from replacing it.

**How you know it's done:** A model-generated role, user ID or approval flag is ignored; all downstream calls retain the original verified identity and correlation ID.

### HAR-007: Agent registry

Only registered and approved agents may participate in the A2A system. Priority P0: has to be done before going live.

**What to build:** Maintain agent ID, version, endpoint, capabilities, owner, schemas, authentication method, allowed callers, data classification, health status, timeout and deprecation state.

**How you know it's done:** Unknown, disabled or incompatible agent versions cannot be invoked; registry changes are versioned and audited.

### HAR-008: Capability discovery

The orchestrator must select agents using trusted capability metadata rather than arbitrary model-generated URLs. Priority P0: has to be done before going live.

**What to build:** Resolve requested capability against the registry; allowlist permitted caller-to-agent routes; validate protocol and schema versions before dispatch.

**How you know it's done:** The model cannot call a URL supplied in user content; unsupported capabilities return a controlled error; route tests are deterministic.

### HAR-010: Orchestration

Agent selection, delegation and workflow state must be controlled by the harness. Priority P0: has to be done before going live.

**What to build:** Use explicit routing rules for known intents; validate model-proposed delegations; record every hop; prohibit unrestricted recursive delegation.

**How you know it's done:** Every hop is traceable; only allowed routes execute; orchestration produces a terminal success, partial or failure state.

### HAR-011: Execution limits

Each request must have bounded time, turns, tokens, agent hops, tool calls, concurrency and cost. Priority P0: has to be done before going live.

**What to build:** Apply per-request budgets; propagate deadlines and cancellation to child agents; stop loops; limit parallel fan-out; return a clear stop reason.

**How you know it's done:** Infinite-loop and fan-out tests terminate within configured limits; cancellations reach downstream work; budget exhaustion does not corrupt state.

### HAR-012: Tool allowlisting

Agents may invoke only explicitly registered tools appropriate to their role and task. Priority P0: has to be done before going live.

**What to build:** Register tools at construction; separate read and write tools; prohibit dynamic code execution, arbitrary URLs and unrestricted shell/database access.

**How you know it's done:** Unregistered tool requests fail closed; each agent exposes only its approved tool set; tool inventory is reviewable.

### HAR-016: API action safety

Side-effecting backend actions must be idempotent, authorized and separately controlled. Priority P0: has to be done before going live.

**What to build:** Classify tools as read or write; require idempotency keys; preview high-impact actions; use transaction boundaries; do not automatically retry unsafe actions.

**How you know it's done:** Duplicate requests produce one business action; write operations cannot execute through read-only routes; failed actions expose a safe, recoverable state.

### HAR-022: Memory governance

Agent memory must never become an unverified system of record. Priority P0: has to be done before going live.

**What to build:** Separate session, preference and business state; define permitted memory fields, retention and deletion; require authoritative APIs for claims, patients, prescriptions and payments.

**How you know it's done:** Expired sessions are removed; protected fields are not stored in preference memory; business decisions use current authoritative data.

### HAR-027: Timeouts and cancellation

Deadlines must be enforced end to end rather than independently by each agent. Priority P1: needed to run it reliably in production.

**What to build:** Set connect/read/overall timeouts; propagate remaining deadline and cancellation signal; stop queued child work; return a typed timeout result.

**How you know it's done:** Parent cancellation stops or safely abandons child work; no child starts after the deadline; timeout behavior is covered by tests.

### HAR-028: Retries and circuit breaking

Transient failures must be retried safely without amplifying outages or repeating unsafe actions. Priority P1: needed to run it reliably in production.

**What to build:** Use bounded exponential backoff with jitter; classify retryable errors; apply circuit breakers; route exhausted asynchronous work to a DLQ.

**How you know it's done:** Retry counts are bounded; permanent failures are not retried; circuit opens during simulated dependency failure; DLQ alarms fire.

### HAR-033: Model governance

Models and inference parameters must be explicitly approved and version-controlled. Priority P0: has to be done before going live.

**What to build:** Maintain allowlisted model IDs, regions, use cases, parameters and fallback order; test before upgrade; prevent agents from choosing arbitrary models.

**How you know it's done:** Unapproved models cannot be invoked; model changes pass evaluation gates and are visible in deployment history.

### HAR-036: Data retention and deletion

Retention periods must be defined separately for prompts, responses, traces, audit events, workflow state and memory. Priority P0: has to be done before going live.

**What to build:** Apply lifecycle policies and legal/compliance requirements; support deletion where allowed; preserve immutable audit data where mandated.

**How you know it's done:** Each data class has an approved retention rule; expiration and deletion tests succeed; exceptions are documented.

### HAR-041: Cost governance

Model and infrastructure expenditure must be observable and bounded by tenant, use case and agent. Priority P1: needed to run it reliably in production.

**What to build:** Attribute usage; set token and request budgets; cache only safe reusable results; alarm on anomalies; apply quotas and throttling.

**How you know it's done:** Cost can be reported per agent/use case; abnormal usage alarms fire; a single user cannot create unbounded spend.
