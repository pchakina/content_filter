# scripts

Small tools for developers.

## What goes in here

- `gen_keys.py` creates a signing key pair for each service in `secrets/`, and a copy of the public
  keys in `secrets/public/`. Use `--rotate` to replace existing keys.
- `run_local.py` starts all eight services on your machine without Docker. Use
  `--offline --fake-backend` to do without AWS and SQL Server.
- `live_checks.py` runs 20 checks over HTTP against services that are already running. Use
  `--docker` when running against Compose; it also checks that the internal ports can't be reached
  from outside.

## How this folder helps with the harness

Every service gets its own key, so one service can't pretend to be another (HAR-003). The keys go in
`secrets/`, which never goes into Git (HAR-023).

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/scripts/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-003: Agent authentication

Every agent and service must have a distinct workload identity for A2A and tool calls. Priority P0: has to be done before going live.

**What to build:** Assign separate IAM roles; use short-lived credentials and signed service calls; prohibit shared long-lived access keys.

**How you know it's done:** CloudTrail identifies the calling workload; one agent's credentials cannot invoke unauthorized services; no static AWS key is stored in code.

### HAR-023: Secrets management

Secrets must not be embedded in source, prompts, environment files committed to Git or agent messages. Priority P0: has to be done before going live.

**What to build:** Store secrets centrally; retrieve at runtime using workload identity; rotate; restrict secret access per service; scan repositories and deployment artifacts.

**How you know it's done:** Secret scanning finds no committed credentials; rotation works without code change; agents cannot enumerate unrelated secrets.
