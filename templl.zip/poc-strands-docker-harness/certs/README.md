# certs

Somewhere to put your company's root certificate if builds run behind a proxy that inspects TLS.
Drop `combined.pem` (or any `.pem` or `.crt` file) here, and every Dockerfile adds it to the image's
trusted certificates.

## What goes in here

- This README. The certificate files themselves are never kept in Git.

## How this folder helps with the harness

Builds keep checking certificates properly instead of switching verification off (HAR-039).

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/certs/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-039: Deployment security

Builds and deployments must be reproducible, scanned and approved. Priority P1: needed to run it reliably in production.

**What to build:** Pin dependencies; generate an SBOM; scan code, containers and IaC; sign artifacts; use least-privilege CI roles; require environment gates.

**How you know it's done:** Critical vulnerabilities block deployment; artifacts are traceable to commit; production deployments require approved gates.
