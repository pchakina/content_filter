# agents/practitioner

The practitioner agent, on port 8001. It answers questions about individual providers: finding
someone by name or NPI, then pulling their specialties, licenses, locations and so on.

## What goes in here

- `main.py` does two things. `extract_context_updates()` picks the PractitionerID out of tool
  results so the next question can say "their". `create_app()` builds the service on top of the
  shared runtime.
- `Dockerfile` builds a non-root image that starts the service with
  `uvicorn --factory agents.practitioner.main:create_app`.
- `manifest.json` is kept for reference only. The registry in `config/base/agents.yaml` is what
  counts now.
- `__init__.py`, empty.

## How this folder helps with the harness

The agent is registered as `practitioner-agent` (HAR-007). Between requests it only hands back the
practitioner's internal ID, never names or other details (HAR-021). Its model is picked from the
approved list (HAR-033).

## Before you start

Use the `create_app()` function rather than a module-level `app`, so the tests can build the agent
with their own settings.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/agents/practitioner/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-007: Agent registry

Only registered and approved agents may participate in the A2A system. Priority P0: has to be done before going live.

**What to build:** Maintain agent ID, version, endpoint, capabilities, owner, schemas, authentication method, allowed callers, data classification, health status, timeout and deprecation state.

**How you know it's done:** Unknown, disabled or incompatible agent versions cannot be invoked; registry changes are versioned and audited.

### HAR-021: Conversation context

Only the minimum relevant, authorized context should be sent to each model or downstream agent. Priority P0: has to be done before going live.

**What to build:** Apply context filtering by task and recipient; cap history; separate trusted policy from conversation; remove PHI not required by the target agent.

**How you know it's done:** Downstream agents receive only required fields; old or unrelated PHI is excluded; context-size limits are enforced.

### HAR-033: Model governance

Models and inference parameters must be explicitly approved and version-controlled. Priority P0: has to be done before going live.

**What to build:** Maintain allowlisted model IDs, regions, use cases, parameters and fallback order; test before upgrade; prevent agents from choosing arbitrary models.

**How you know it's done:** Unapproved models cannot be invoked; model changes pass evaluation gates and are visible in deployment history.
