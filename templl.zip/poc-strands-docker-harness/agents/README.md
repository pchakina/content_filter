# agents

This is where the five agents live: practitioner, practice, facility, NL2SQL and synthesis. Each one
is a small FastAPI service. The checks they all share sit in `_internal/`, so the agent folders
themselves stay short.

## What goes in here

- `prompts.py` holds the system prompts. Copy it over from `poc-strands-docker` as it is; the
  prompts didn't change.
- `requirements.txt` lists what the agent images install. It pulls in the shared harness packages
  plus Strands and boto3.
- `__init__.py`, empty.

## How this folder helps with the harness

Agents never call each other. Only `master` is allowed to call an agent, so a model can't kick off
a chain of delegations on its own (HAR-010). Every request also gets a brand-new Strands agent with
no memory of earlier conversations, which keeps old data out of new requests (HAR-021).

## Before you start

Add `_internal/` first, because every agent depends on it. When you add an agent, register it in
`config/base/agents.yaml` and `config/base/routes.yaml` at the same time. The config loader refuses
to start if an agent is missing from either file.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/agents/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-010: Orchestration

Agent selection, delegation and workflow state must be controlled by the harness. Priority P0: has to be done before going live.

**What to build:** Use explicit routing rules for known intents; validate model-proposed delegations; record every hop; prohibit unrestricted recursive delegation.

**How you know it's done:** Every hop is traceable; only allowed routes execute; orchestration produces a terminal success, partial or failure state.

### HAR-021: Conversation context

Only the minimum relevant, authorized context should be sent to each model or downstream agent. Priority P0: has to be done before going live.

**What to build:** Apply context filtering by task and recipient; cap history; separate trusted policy from conversation; remove PHI not required by the target agent.

**How you know it's done:** Downstream agents receive only required fields; old or unrelated PHI is excluded; context-size limits are enforced.
