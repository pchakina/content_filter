# agents/nl2sql

The NL2SQL agent, on port 8002, for free-form database questions. Unlike the others it has no
model. It always passes the user's question straight to the `query_provider_database` tool. We
kept that design from the original, because when a model sat in front of that single tool it
sometimes wrote SQL itself instead of calling the tool.

## What goes in here

- `main.py` builds the service with `direct_tool=("query_provider_database", "question")`.
- `Dockerfile` builds the image for port 8002. It doesn't need a route to Bedrock.
- `manifest.json` is kept for reference only.
- `__init__.py`, empty.

## How this folder helps with the harness

Only data stewards can use this agent, and only for operations work (HAR-004). The SQL itself is
checked at MCP by `mcp/sql_guard.py` and run read-only by the backend (HAR-015).

## Before you start

We don't have a SQL generator yet. Until someone plugs one in with
`NL2SQL_GENERATOR=module:function`, these questions come back with a clear "not available" error.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/agents/nl2sql/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-004: Authorization

Access must be decided by deterministic policy outside the language model. Priority P0: has to be done before going live.

**What to build:** Enforce RBAC plus ABAC using user role, agent identity, tenant, organization, resource, action, data class and purpose of use. Re-authorize at every protected tool.

**How you know it's done:** Unauthorized requests return 403; changing prompt text cannot elevate privileges; policy tests cover allow, deny and default-deny behavior.

### HAR-015: NL-to-SQL safety

Generated SQL must be read-only, scoped, bounded and validated independently of the model. Priority P0: has to be done before going live.

**What to build:** Parse the SQL AST; allowlist schemas, tables, columns and functions; block DDL/DML and multi-statements; inject tenant filters; set row, time and scan limits; use read-only credentials.

**How you know it's done:** `DROP`, `DELETE`, `UPDATE`, unrestricted cross-tenant and unbounded queries are rejected; all approved queries include required scoping and limits.
