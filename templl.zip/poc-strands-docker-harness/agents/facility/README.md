# agents/facility

The facility agent, on port 8004. It answers questions about hospitals, clinics and dialysis
centers.

## What goes in here

- `main.py` has the same shape as the practitioner agent's, except it looks for a FacilityID.
- `Dockerfile` builds the image for port 8004.
- `manifest.json` is kept for reference only.
- `__init__.py`, empty.

## How this folder helps with the harness

The agent is registered as `facility-agent` (HAR-007). It only passes the facility's internal ID
back to the session (HAR-021), and it uses a model from the approved list (HAR-033).

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/agents/facility/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-007: Agent registry

Only registered and approved agents may participate in the A2A system. Priority P0: has to be done before going live.

**What to build:** Maintain agent ID, version, endpoint, capabilities, owner, schemas, authentication method, allowed callers, data classification, health status, timeout and deprecation state.

**How you know it's done:** Unknown, disabled or incompatible agent versions cannot be invoked; registry changes are versioned and audited.

### HAR-021: Conversation context

Only the minimum relevant, authorized context should be sent to each model or downstream agent. Priority P0: has to be done before going live.

**What to build:** Apply context filtering by task and recipient; cap history; separate trusted policy from conversation; remove PHI not required by the target agent.

**How you know it's done:** Downstream agents receive only required fields; old or unrelated PHI is excluded; context-size limits are enforced.

### HAR-033: Model governance

Models and inference parameters must be explicitly approved and version-controlled. Priority P0: has to be done before going live.

**What to build:** Maintain allowlisted model IDs, regions, use cases, parameters and fallback order; test before upgrade; prevent agents from choosing arbitrary models.

**How you know it's done:** Unapproved models cannot be invoked; model changes pass evaluation gates and are visible in deployment history.
