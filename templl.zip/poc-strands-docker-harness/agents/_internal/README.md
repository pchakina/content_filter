# agents/_internal

This is the shared runtime behind every agent. When a task arrives, this code decides whether to
accept it and how far the agent may go. The agent folders only add their own small bit of logic on
top.

## What goes in here

- `agent_runtime.py` has `AgentHarness`, which checks an incoming task and builds the reply, and
  `create_agent_app()`, which wraps a Strands agent in all of those checks.
- `runner.py` has the three ways an agent can run: on Bedrock through Strands, by calling one tool
  directly (used by NL2SQL), or with a scripted stand-in that the tests use instead of a real model.
- `__init__.py`, empty.

## How this folder helps with the harness

This is where most of the agent-side controls live.

- It checks the caller's service token, so only `master` can hand an agent work (HAR-003).
- It reads who the user is from the signed context and nowhere else. If the request body claims a
  different user, tenant or role, the task is refused (HAR-006).
- It checks that the user is allowed to use this agent for their stated purpose (HAR-004).
- It validates the request envelope and rejects input fields the agent doesn't expect (HAR-009).
- It caps turns, tokens and tool calls, and refuses a task when no agent hops are left (HAR-011).
- The model only ever sees the tools MCP lists for this agent (HAR-012).
- Tool results go to the model marked as data, with a note not to follow anything written inside
  them (HAR-019).
- Every tool call is recorded, so each answer says which records it came from (HAR-020).
- It stops shortly before the request deadline and blocks any further tool calls (HAR-027).
- The model comes from the approved list in config, never from the request (HAR-033).

## Before you start

Don't build tool functions with `exec()`; the old `mcp_tools.py` did that and it was removed. Never
take the user's identity from headers or prompt text; always use `verify_internal_caller`.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/agents/_internal/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-003: Agent authentication

Every agent and service must have a distinct workload identity for A2A and tool calls. Priority P0: has to be done before going live.

**What to build:** Assign separate IAM roles; use short-lived credentials and signed service calls; prohibit shared long-lived access keys.

**How you know it's done:** CloudTrail identifies the calling workload; one agent's credentials cannot invoke unauthorized services; no static AWS key is stored in code.

### HAR-004: Authorization

Access must be decided by deterministic policy outside the language model. Priority P0: has to be done before going live.

**What to build:** Enforce RBAC plus ABAC using user role, agent identity, tenant, organization, resource, action, data class and purpose of use. Re-authorize at every protected tool.

**How you know it's done:** Unauthorized requests return 403; changing prompt text cannot elevate privileges; policy tests cover allow, deny and default-deny behavior.

### HAR-006: Trusted security context

Verified identity and authorization attributes must be kept separate from model-controlled content. Priority P0: has to be done before going live.

**What to build:** Create an immutable security-context object after authentication; pass it through runtime context, not prompts or model-generated tool arguments; prevent downstream agents from replacing it.

**How you know it's done:** A model-generated role, user ID or approval flag is ignored; all downstream calls retain the original verified identity and correlation ID.

### HAR-009: Standard A2A contract

All agents must use versioned request, response and error envelopes. Priority P0: has to be done before going live.

**What to build:** Define JSON Schema or Pydantic models containing request ID, correlation ID, caller identity, task type, payload, security labels, limits, status, warnings and typed errors.

**How you know it's done:** Invalid messages fail before agent execution; backward-compatibility tests pass for supported versions; errors follow one documented taxonomy.

### HAR-011: Execution limits

Each request must have bounded time, turns, tokens, agent hops, tool calls, concurrency and cost. Priority P0: has to be done before going live.

**What to build:** Apply per-request budgets; propagate deadlines and cancellation to child agents; stop loops; limit parallel fan-out; return a clear stop reason.

**How you know it's done:** Infinite-loop and fan-out tests terminate within configured limits; cancellations reach downstream work; budget exhaustion does not corrupt state.

### HAR-012: Tool allowlisting

Agents may invoke only explicitly registered tools appropriate to their role and task. Priority P0: has to be done before going live.

**What to build:** Register tools at construction; separate read and write tools; prohibit dynamic code execution, arbitrary URLs and unrestricted shell/database access.

**How you know it's done:** Unregistered tool requests fail closed; each agent exposes only its approved tool set; tool inventory is reviewable.

### HAR-019: Prompt-injection defense

Instructions contained in user input, retrieved records or agent responses must not override trusted policy. Priority P0: has to be done before going live.

**What to build:** Mark untrusted content; isolate system policy; detect suspicious instructions; deny privilege changes; re-authorize tool calls; restrict context and tool access regardless of prompt.

**How you know it's done:** Injection attempts cannot reveal secrets, register tools, change identity, remove SQL restrictions or bypass approval.

### HAR-020: Model output grounding

Material factual or operational claims must be connected to authoritative tool results. Priority P1: needed to run it reliably in production.

**What to build:** Preserve source/provenance metadata; distinguish inference from retrieved facts; prohibit claims of action success without successful tool confirmation.

**How you know it's done:** Responses identify supporting source or operation; failed tool calls cannot be presented as success; unsupported critical claims trigger abstention or warning.

### HAR-027: Timeouts and cancellation

Deadlines must be enforced end to end rather than independently by each agent. Priority P1: needed to run it reliably in production.

**What to build:** Set connect/read/overall timeouts; propagate remaining deadline and cancellation signal; stop queued child work; return a typed timeout result.

**How you know it's done:** Parent cancellation stops or safely abandons child work; no child starts after the deadline; timeout behavior is covered by tests.

### HAR-033: Model governance

Models and inference parameters must be explicitly approved and version-controlled. Priority P0: has to be done before going live.

**What to build:** Maintain allowlisted model IDs, regions, use cases, parameters and fallback order; test before upgrade; prevent agents from choosing arbitrary models.

**How you know it's done:** Unapproved models cannot be invoked; model changes pass evaluation gates and are visible in deployment history.
