# agents/synthesis

The synthesis agent, on port 8005. It takes the tool results a specialist agent found and turns
them into readable markdown tables. When a result is JSON, the table is built in code. The model is
only used for anything that isn't JSON.

## What goes in here

- `main.py` holds the formatting functions, unchanged from the original, plus a `create_app()` that
  puts them behind the shared checks.
- `Dockerfile` builds the image for port 8005.
- `manifest.json` is kept for reference only.
- `__init__.py`, empty.

## How this folder helps with the harness

It only accepts the question and the tool results, and nothing from the user's session (HAR-021).
The question and the data arrive as separate fields, so text inside a record can't pass itself off
as part of the question (HAR-019). Any SSN in the output is masked (HAR-018), and the model comes
from the approved list (HAR-033).

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/agents/synthesis/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-018: PHI/PII protection

Sensitive identifiers and healthcare data must be minimized throughout the agent lifecycle. Priority P0: has to be done before going live.

**What to build:** Classify fields; mask/tokenize SSNs; avoid sending raw identifiers to the LLM; redact logs and traces; prevent sensitive data from entering long-term memory; encrypt in transit and at rest.

**How you know it's done:** Raw SSNs, tokens and prohibited PHI do not appear in prompts, logs, traces or errors; redaction and data-minimization tests pass.

### HAR-019: Prompt-injection defense

Instructions contained in user input, retrieved records or agent responses must not override trusted policy. Priority P0: has to be done before going live.

**What to build:** Mark untrusted content; isolate system policy; detect suspicious instructions; deny privilege changes; re-authorize tool calls; restrict context and tool access regardless of prompt.

**How you know it's done:** Injection attempts cannot reveal secrets, register tools, change identity, remove SQL restrictions or bypass approval.

### HAR-021: Conversation context

Only the minimum relevant, authorized context should be sent to each model or downstream agent. Priority P0: has to be done before going live.

**What to build:** Apply context filtering by task and recipient; cap history; separate trusted policy from conversation; remove PHI not required by the target agent.

**How you know it's done:** Downstream agents receive only required fields; old or unrelated PHI is excluded; context-size limits are enforced.

### HAR-033: Model governance

Models and inference parameters must be explicitly approved and version-controlled. Priority P0: has to be done before going live.

**What to build:** Maintain allowlisted model IDs, regions, use cases, parameters and fallback order; test before upgrade; prevent agents from choosing arbitrary models.

**How you know it's done:** Unapproved models cannot be invoked; model changes pass evaluation gates and are visible in deployment history.
