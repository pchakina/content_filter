# harness

The shared library that every service uses. None of it knows about practitioners or sPayer. It does
what `config/` and `policies/` tell it to.

## What goes in here, and what each file is for

- `config.py` loads the configuration, layers the environment on top, checks it against strict
  schemas, and refuses to start if anything is inconsistent (HAR-038). It also refuses models that
  aren't on the approved list (HAR-033).
- `security.py` checks user tokens (HAR-002), signs and checks service tokens (HAR-003), and builds
  the signed security context that carries the user's identity from service to service (HAR-006).
  It holds the authorization check, which denies anything no rule allows (HAR-004), and the
  helpers that blank out SSNs, tokens and other sensitive values in logs (HAR-018).
- `registry.py` looks up agents, routes and tools by their registered names, and never by URL
  (HAR-007, HAR-008, HAR-012).
- `runtime.py` handles the request deadline, rate and concurrency limits, retries and the circuit
  breaker (HAR-011, HAR-027, HAR-028).
- `http.py` is the client every service uses to call another. It attaches the tokens, trims the
  timeout to the time left, and turns remote errors back into typed ones (HAR-003, HAR-027,
  HAR-028, HAR-029).
- `state.py` stores sessions, idempotency records, counters, usage, the audit log and trace spans,
  and clears out expired rows (HAR-022, HAR-025, HAR-026, HAR-030, HAR-036).
- `observability.py` writes the audit records, trace spans and metrics (HAR-030, HAR-031, HAR-032).
- `validation.py` checks identifiers such as NPI and TIN, filters backend results, removes text
  that looks like instructions, and checks that answers are backed by tool results (HAR-013,
  HAR-014, HAR-019, HAR-020).
- `web.py` holds the pieces every FastAPI service shares: typed error responses, `/health`,
  `/metrics`, and the caller check (HAR-029).
- `__init__.py`, empty.

## Before you start

Add this folder after `contracts/`, and at the same time as `config/` and `policies/`, because
`config.py` can't load without them. Keep it free of anything specific to sPayer. That belongs in
config, policies or the services.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/harness/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-002: User authentication

Every interactive request must be associated with a verified human or application identity. Priority P0: has to be done before going live.

**What to build:** Validate JWT issuer, audience, signature, expiry and token use. Derive identity only from validated claims, never from prompt text. Support MFA where risk requires it.

**How you know it's done:** Missing, expired, incorrectly signed or wrong-audience tokens return 401; the model cannot alter the authenticated user ID.

### HAR-003: Agent authentication

Every agent and service must have a distinct workload identity for A2A and tool calls. Priority P0: has to be done before going live.

**What to build:** Assign separate IAM roles; use short-lived credentials and signed service calls; prohibit shared long-lived access keys.

**How you know it's done:** CloudTrail identifies the calling workload; one agent's credentials cannot invoke unauthorized services; no static AWS key is stored in code.

### HAR-004: Authorization

Access must be decided by deterministic policy outside the language model. Priority P0: has to be done before going live.

**What to build:** Enforce RBAC plus ABAC using user role, agent identity, tenant, organization, resource, action, data class and purpose of use. Re-authorize at every protected tool.

**How you know it's done:** Unauthorized requests return 403; changing prompt text cannot elevate privileges; policy tests cover allow, deny and default-deny behavior.

### HAR-006: Trusted security context

Verified identity and authorization attributes must be kept separate from model-controlled content. Priority P0: has to be done before going live.

**What to build:** Create an immutable security-context object after authentication; pass it through runtime context, not prompts or model-generated tool arguments; prevent downstream agents from replacing it.

**How you know it's done:** A model-generated role, user ID or approval flag is ignored; all downstream calls retain the original verified identity and correlation ID.

### HAR-007: Agent registry

Only registered and approved agents may participate in the A2A system. Priority P0: has to be done before going live.

**What to build:** Maintain agent ID, version, endpoint, capabilities, owner, schemas, authentication method, allowed callers, data classification, health status, timeout and deprecation state.

**How you know it's done:** Unknown, disabled or incompatible agent versions cannot be invoked; registry changes are versioned and audited.

### HAR-008: Capability discovery

The orchestrator must select agents using trusted capability metadata rather than arbitrary model-generated URLs. Priority P0: has to be done before going live.

**What to build:** Resolve requested capability against the registry; allowlist permitted caller-to-agent routes; validate protocol and schema versions before dispatch.

**How you know it's done:** The model cannot call a URL supplied in user content; unsupported capabilities return a controlled error; route tests are deterministic.

### HAR-011: Execution limits

Each request must have bounded time, turns, tokens, agent hops, tool calls, concurrency and cost. Priority P0: has to be done before going live.

**What to build:** Apply per-request budgets; propagate deadlines and cancellation to child agents; stop loops; limit parallel fan-out; return a clear stop reason.

**How you know it's done:** Infinite-loop and fan-out tests terminate within configured limits; cancellations reach downstream work; budget exhaustion does not corrupt state.

### HAR-012: Tool allowlisting

Agents may invoke only explicitly registered tools appropriate to their role and task. Priority P0: has to be done before going live.

**What to build:** Register tools at construction; separate read and write tools; prohibit dynamic code execution, arbitrary URLs and unrestricted shell/database access.

**How you know it's done:** Unregistered tool requests fail closed; each agent exposes only its approved tool set; tool inventory is reviewable.

### HAR-013: Tool input validation

Every tool call must be validated before it reaches a backend. Priority P0: has to be done before going live.

**What to build:** Use typed schemas; validate formats, ranges, enums and identifiers; normalize NPI and dates; reject extra fields; limit string and collection sizes.

**How you know it's done:** Invalid input never reaches the backend; boundary, malformed and injection test cases produce controlled validation errors.

### HAR-014: Tool output validation

Backend and agent results must be treated as untrusted until validated. Priority P0: has to be done before going live.

**What to build:** Check response schema, status, content type, size, provenance and required fields; redact sensitive values; return typed errors for invalid responses.

**How you know it's done:** Malformed, excessive or unauthorized backend fields are blocked; agents cannot forward unvalidated output to users or other agents.

### HAR-018: PHI/PII protection

Sensitive identifiers and healthcare data must be minimized throughout the agent lifecycle. Priority P0: has to be done before going live.

**What to build:** Classify fields; mask/tokenize SSNs; avoid sending raw identifiers to the LLM; redact logs and traces; prevent sensitive data from entering long-term memory; encrypt in transit and at rest.

**How you know it's done:** Raw SSNs, tokens and prohibited PHI do not appear in prompts, logs, traces or errors; redaction and data-minimization tests pass.

### HAR-019: Prompt-injection defense

Instructions contained in user input, retrieved records or agent responses must not override trusted policy. Priority P0: has to be done before going live.

**What to build:** Mark untrusted content; isolate system policy; detect suspicious instructions; deny privilege changes; re-authorize tool calls; restrict context and tool access regardless of prompt.

**How you know it's done:** Injection attempts cannot reveal secrets, register tools, change identity, remove SQL restrictions or bypass approval.

### HAR-020: Model output grounding

Material factual or operational claims must be connected to authoritative tool results. Priority P1: needed to run it reliably in production.

**What to build:** Preserve source/provenance metadata; distinguish inference from retrieved facts; prohibit claims of action success without successful tool confirmation.

**How you know it's done:** Responses identify supporting source or operation; failed tool calls cannot be presented as success; unsupported critical claims trigger abstention or warning.

### HAR-022: Memory governance

Agent memory must never become an unverified system of record. Priority P0: has to be done before going live.

**What to build:** Separate session, preference and business state; define permitted memory fields, retention and deletion; require authoritative APIs for claims, patients, prescriptions and payments.

**How you know it's done:** Expired sessions are removed; protected fields are not stored in preference memory; business decisions use current authoritative data.

### HAR-025: State management

Workflow, session and business state must be separated and consistently managed. Priority P1: needed to run it reliably in production.

**What to build:** Store resumable workflow state; use optimistic locking/versioning; define TTLs; never rely on in-memory agent state for durable operations.

**How you know it's done:** Restarting an agent does not lose durable workflow state; stale writes are detected; expired temporary state is deleted.

### HAR-026: Idempotency and deduplication

Retries and repeated A2A deliveries must not create duplicate side effects. Priority P0: has to be done before going live.

**What to build:** Generate or accept an idempotency key; persist request fingerprint and terminal result; reject conflicting reuse; define deduplication windows.

**How you know it's done:** Replaying the same request returns the original result; the same key with different parameters is rejected.

### HAR-027: Timeouts and cancellation

Deadlines must be enforced end to end rather than independently by each agent. Priority P1: needed to run it reliably in production.

**What to build:** Set connect/read/overall timeouts; propagate remaining deadline and cancellation signal; stop queued child work; return a typed timeout result.

**How you know it's done:** Parent cancellation stops or safely abandons child work; no child starts after the deadline; timeout behavior is covered by tests.

### HAR-028: Retries and circuit breaking

Transient failures must be retried safely without amplifying outages or repeating unsafe actions. Priority P1: needed to run it reliably in production.

**What to build:** Use bounded exponential backoff with jitter; classify retryable errors; apply circuit breakers; route exhausted asynchronous work to a DLQ.

**How you know it's done:** Retry counts are bounded; permanent failures are not retried; circuit opens during simulated dependency failure; DLQ alarms fire.

### HAR-029: Error handling

Errors must be typed, safe and actionable without exposing internals or PHI. Priority P0: has to be done before going live.

**What to build:** Define validation, authentication, authorization, dependency, timeout, limit and internal-error codes; map them consistently; retain detailed internal diagnostics securely.

**How you know it's done:** Client errors contain no stack trace, SQL, secret or PHI; operations can distinguish retryable from non-retryable failures.

### HAR-030: Audit logging

Security-relevant activity must produce an immutable, queryable audit record. Priority P0: has to be done before going live.

**What to build:** Record actor, agent, action, resource, purpose, authorization decision, tool, timestamp, outcome and correlation ID. Log data access without copying sensitive payloads.

**How you know it's done:** Auditors can reconstruct who accessed which resource and why; audit retention and tamper-protection meet policy; PHI is minimized.

### HAR-031: Distributed tracing

A request must be traceable across orchestrator, agents, tools, APIs and asynchronous messages. Priority P1: needed to run it reliably in production.

**What to build:** Propagate trace, request and correlation IDs; create spans for model calls, agent hops, tools and dependencies; mask sensitive attributes.

**How you know it's done:** One trace shows the complete path and latency breakdown; asynchronous continuations retain correlation; sensitive values are absent.

### HAR-032: Metrics and alerting

The platform must expose operational, model, security and cost health. Priority P1: needed to run it reliably in production.

**What to build:** Measure traffic, errors, latency, throttles, token usage, cost, turns, tool failures, denials, guardrail blocks, queue age and DLQ depth; define SLO-based alarms.

**How you know it's done:** Dashboards exist per environment; critical alarms are tested; alerts include runbook and correlation information.

### HAR-033: Model governance

Models and inference parameters must be explicitly approved and version-controlled. Priority P0: has to be done before going live.

**What to build:** Maintain allowlisted model IDs, regions, use cases, parameters and fallback order; test before upgrade; prevent agents from choosing arbitrary models.

**How you know it's done:** Unapproved models cannot be invoked; model changes pass evaluation gates and are visible in deployment history.

### HAR-036: Data retention and deletion

Retention periods must be defined separately for prompts, responses, traces, audit events, workflow state and memory. Priority P0: has to be done before going live.

**What to build:** Apply lifecycle policies and legal/compliance requirements; support deletion where allowed; preserve immutable audit data where mandated.

**How you know it's done:** Each data class has an approved retention rule; expiration and deletion tests succeed; exceptions are documented.

### HAR-038: Configuration management

Environment-specific agent, model, routing, policy and limit configuration must be externalized and versioned. Priority P1: needed to run it reliably in production.

**What to build:** Separate dev/test/prod; validate configuration schema; use controlled promotion; prohibit manual production drift.

**How you know it's done:** Configuration changes are reviewed, auditable and reversible; invalid configuration cannot deploy; drift is detected.
