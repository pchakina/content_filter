# tests

The automated tests. They run the whole system in one process: the gateway, an agent, MCP, a fake
backend and synthesis. The models are scripted, so you don't need AWS or SQL Server to run them.

## What goes in here

- `conftest.py` sets up the whole stack for each test and provides the fake backend.
- `test_entry_and_identity.py` covers the front door, logins, service tokens and the security
  context.
- `test_authorization_and_registry.py` covers permissions, tenants, the registry, routing, tool
  access and config checks.
- `test_tools_sql_and_data.py` covers argument checks, result filtering, SQL checks, PHI, injected
  instructions and grounding.
- `test_runtime_control.py` covers hops, limits, idempotency, timeouts, retries and budgets.
- `test_contract_governance_and_ops.py` covers message formats, session memory, errors, audit,
  tracing, metrics, models, retention and versions.

## How this folder helps with the harness

Besides checking that each control works, the tests try to break them on purpose: forged tokens,
fake roles, other tenants' data, SQL attacks, hidden instructions, runaway loops and more (HAR-035).
Each requirement's section in `docs/HARNESS_REQUIREMENTS.md` lists the tests that prove it.

## Before you start

Run `python -m pytest`. It expects `pytest.ini` to set `--basetemp=.pytest_tmp`. Add the tests in
the same commit as the code they cover.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/tests/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-035: Adversarial testing

The harness must be tested against deliberate policy-bypass attempts. Priority P0: has to be done before going live.

**What to build:** Test prompt injection, role spoofing, cross-tenant access, SQL mutation, SSRF, tool argument manipulation, approval tampering, data exfiltration and agent loops.

**How you know it's done:** P0 attack cases cannot cause unauthorized action or disclosure; findings have owners and remediation deadlines.
