# contracts

These are the message formats every service uses when it talks to another, plus the one error type
they all raise. This folder replaces the old `a2a/contract.py`.

## What goes in here

- `envelope.py` defines the request and response formats from sections 4 and 5 of the requirements
  document (`A2ARequest`, `A2AResponse`, `Provenance`), plus the protocol version check.
- `errors.py` defines `ErrorCode` and `HarnessError`.
- `__init__.py`, empty.

## How this folder helps with the harness

Every request and response has a version and a fixed set of fields, and anything unexpected is
rejected before an agent runs (HAR-009). Errors all have the same shape: a code, a message that's
safe to show, and whether retrying might help (HAR-029). A message from a different major version
is turned away with a clear error (HAR-040).

## Before you start

Add this folder first, because `harness/` imports it. Changing a field changes the protocol, so bump
the version and keep accepting the old one until every agent has been updated.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/contracts/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-009: Standard A2A contract

All agents must use versioned request, response and error envelopes. Priority P0: has to be done before going live.

**What to build:** Define JSON Schema or Pydantic models containing request ID, correlation ID, caller identity, task type, payload, security labels, limits, status, warnings and typed errors.

**How you know it's done:** Invalid messages fail before agent execution; backward-compatibility tests pass for supported versions; errors follow one documented taxonomy.

### HAR-029: Error handling

Errors must be typed, safe and actionable without exposing internals or PHI. Priority P0: has to be done before going live.

**What to build:** Define validation, authentication, authorization, dependency, timeout, limit and internal-error codes; map them consistently; retain detailed internal diagnostics securely.

**How you know it's done:** Client errors contain no stack trace, SQL, secret or PHI; operations can distinguish retryable from non-retryable failures.

### HAR-040: Version compatibility

A2A agents and message schemas must evolve without silently breaking active workflows. Priority P1: needed to run it reliably in production.

**What to build:** Use semantic versions; publish supported compatibility ranges; support controlled rollout and rollback; reject incompatible protocol versions explicitly.

**How you know it's done:** Compatibility tests pass; incompatible calls return a typed error; rollback restores service without state corruption.
