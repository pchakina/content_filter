# infra/live/dev/services

One folder per service: `master`, `mcp`, `spayer-backend`, `practitioner-agent`, `practice-agent`,
`facility-agent`, `nl2sql-agent` and `synthesis-agent`. Each `terragrunt.hcl` calls the shared
`modules/ecs-service` module.

## What each one sets

- The image (ECR repository plus the commit SHA tag), the port, and the CPU and memory size.
- `allowed_from`, matching who may call it in `config/base/agents.yaml`:
  - `master` accepts traffic only from the load balancer.
  - Each agent accepts traffic only from `master`.
  - `mcp` accepts traffic only from the four agents that use tools.
  - `spayer-backend` accepts traffic only from `mcp`.
- The secrets it needs: its own private signing key, the public keys, and for the backend, the
  database password.

## How this folder helps with the harness

Each service gets its own role and only the network paths it really needs. The security groups
mirror the service-token checks in the code, so a caller is stopped by the network as well as by
the code (HAR-003, HAR-024).

## What the requirements say

Here's the wording from the requirements document, with the AWS services it suggests, so you
can check the work here without opening it.

### HAR-003: Agent authentication

Every agent and service must have a distinct workload identity for A2A and tool calls. Priority P0: has to be done before going live.

**What to build:** Assign separate IAM roles; use short-lived credentials and signed service calls; prohibit shared long-lived access keys.

**Suggested AWS services:** IAM roles, STS, IAM Roles Anywhere when applicable, SigV4

**How you know it's done:** CloudTrail identifies the calling workload; one agent's credentials cannot invoke unauthorized services; no static AWS key is stored in code.

### HAR-024: Network isolation

Agent, database and internal API traffic must follow least-access network paths. Priority P0: has to be done before going live.

**What to build:** Use private subnets/endpoints where feasible; restrict security groups and egress; deny arbitrary outbound destinations; use TLS and private DNS.

**Suggested AWS services:** VPC, security groups, PrivateLink, VPC endpoints, Route 53 private zones, Network Firewall

**How you know it's done:** Databases have no public endpoint; unapproved outbound connections fail; network-flow tests match the approved architecture.
