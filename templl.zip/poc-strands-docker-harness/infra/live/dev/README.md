# infra/live/dev

The development environment. It's the first one to deploy to, and it can be small: one task per
service.

## What goes in here

- `env.hcl` with the account ID, region (`us-east-1`), CPU and memory sizes, and `HARNESS_ENV`.
- One folder per piece, each with a `terragrunt.hcl` that points at a module and fills in its
  inputs:
  - `network/`, `ecr/`, `ecs-cluster/`, `alb/`, `iam/`, `secrets/`, `storage/`, `observability/`
  - `services/master/`, `services/mcp/`, `services/spayer-backend/`, and one per agent under
    `services/`

## Before you start

Set the dependencies between folders with `dependency` blocks, for example `services/master`
needs the outputs of `network`, `ecs-cluster`, `alb` and `iam`. Then Terragrunt applies them in the
right order.
