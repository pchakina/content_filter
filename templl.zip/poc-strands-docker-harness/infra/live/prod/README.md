# infra/live/prod

The production environment. It has the same layout as `dev/`, with production values.

## What's different from dev

- At least two tasks per service, spread across two availability zones.
- `HARNESS_ENV=prod`. In that environment the demo login and the scripted model are refused, so a
  real identity provider has to be configured first.
- Deletion protection on the load balancer and the storage, and longer log retention.
- Deployments happen through the pipeline, from a reviewed plan, never from a laptop.

## How this folder helps with the harness

Prod is kept separate from dev and only changes through review (HAR-038). Running across zones, with
backups of the state, is the start of a recovery plan. You still need to agree recovery time and
data-loss targets and test a restore (HAR-037).

## What the requirements say

Here's the wording from the requirements document, with the AWS services it suggests, so you
can check the work here without opening it.

### HAR-037: High availability and recovery

Critical components must tolerate expected failures and have documented recovery objectives. Priority P1: needed to run it reliably in production.

**What to build:** Deploy across availability zones; remove single points of failure; define RTO/RPO; back up configuration and state; test restoration and regional strategy where required.

**Suggested AWS services:** Multi-AZ AWS services, AWS Backup, Route 53, DynamoDB PITR, S3 versioning

**How you know it's done:** Recovery exercise meets approved RTO/RPO; registry, policies and state can be restored; failure modes are documented.

### HAR-038: Configuration management

Environment-specific agent, model, routing, policy and limit configuration must be externalized and versioned. Priority P1: needed to run it reliably in production.

**What to build:** Separate dev/test/prod; validate configuration schema; use controlled promotion; prohibit manual production drift.

**Suggested AWS services:** AppConfig, Parameter Store, Terraform/Terragrunt, CI/CD

**How you know it's done:** Configuration changes are reviewed, auditable and reversible; invalid configuration cannot deploy; drift is detected.
