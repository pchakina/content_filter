# infra/live

The Terragrunt configuration for each environment. This is where you run Terragrunt from.

## How it's laid out

- `terragrunt.hcl` at this level sets things every environment shares: the S3 remote state with
  DynamoDB locking, the AWS provider, and common tags such as `project`, `env` and `owner`.
- `dev/` and `prod/` each hold an `env.hcl` with that environment's account, region and sizes, and
  one folder per module call.

## Running it

Run `terragrunt run-all plan` inside `dev/` to see every change for dev. Use
`terragrunt run-all apply` to make them. To work on one piece, `cd` into its folder (for example
`dev/services/master`) and run `terragrunt plan`.

## How this folder helps with the harness

Each environment is separate, every change shows up in a plan before it's applied, and nothing is
changed by hand. Re-running `plan` shows any drift (HAR-038).

## What the requirements say

Here's the wording from the requirements document, with the AWS services it suggests, so you
can check the work here without opening it.

### HAR-038: Configuration management

Environment-specific agent, model, routing, policy and limit configuration must be externalized and versioned. Priority P1: needed to run it reliably in production.

**What to build:** Separate dev/test/prod; validate configuration schema; use controlled promotion; prohibit manual production drift.

**Suggested AWS services:** AppConfig, Parameter Store, Terraform/Terragrunt, CI/CD

**How you know it's done:** Configuration changes are reviewed, auditable and reversible; invalid configuration cannot deploy; drift is detected.
