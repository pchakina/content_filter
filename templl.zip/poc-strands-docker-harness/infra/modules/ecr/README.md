# infra/modules/ecr

The image repositories, one per service: `master`, `mcp`, `spayer-backend`, and the five agents.

## What it should create

- One ECR repository per service, with scan on push turned on and immutable tags.
- A lifecycle rule that keeps the last N images.

## How this module helps with the harness

Every image is scanned when it's pushed, and a tag can't be overwritten. That way a deployment
always runs exactly the image that was built and checked (HAR-039).

## Before you start

Tag images with the Git commit SHA, not `latest`, so each running task can be traced back to a
commit.

## What the requirements say

Here's the wording from the requirements document, with the AWS services it suggests, so you
can check the work here without opening it.

### HAR-039: Deployment security

Builds and deployments must be reproducible, scanned and approved. Priority P1: needed to run it reliably in production.

**What to build:** Pin dependencies; generate an SBOM; scan code, containers and IaC; sign artifacts; use least-privilege CI roles; require environment gates.

**Suggested AWS services:** CodePipeline/GitHub Actions, CodeBuild, ECR scanning, Inspector, Signer, Terraform/Terragrunt

**How you know it's done:** Critical vulnerabilities block deployment; artifacts are traceable to commit; production deployments require approved gates.
