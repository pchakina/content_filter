# infra/modules/observability

Logs, alarms and dashboards.

## What it should create

- One CloudWatch log group per service, encrypted, with a retention period set.
- Alarms on unhealthy tasks, 5xx responses from the load balancer, and spikes in the harness
  metrics (denials, timeouts, circuit-breaker trips, token use).
- An SNS topic for alarm notifications.
- A dashboard per environment.

## How this module helps with the harness

Service logs, which are already redacted, are kept for a set period (HAR-030). Requests can be
followed across services through their correlation ID (HAR-031). Problems raise an alarm instead of
waiting for someone to notice (HAR-032).

## Before you start

The services currently serve metrics in Prometheus format on `/metrics`. To get them into
CloudWatch, add the CloudWatch agent or an ADOT sidecar to the `ecs-service` module.

## What the requirements say

Here's the wording from the requirements document, with the AWS services it suggests, so you
can check the work here without opening it.

### HAR-030: Audit logging

Security-relevant activity must produce an immutable, queryable audit record. Priority P0: has to be done before going live.

**What to build:** Record actor, agent, action, resource, purpose, authorization decision, tool, timestamp, outcome and correlation ID. Log data access without copying sensitive payloads.

**Suggested AWS services:** CloudTrail, CloudWatch Logs, S3 Object Lock, KMS, Firehose

**How you know it's done:** Auditors can reconstruct who accessed which resource and why; audit retention and tamper-protection meet policy; PHI is minimized.

### HAR-031: Distributed tracing

A request must be traceable across orchestrator, agents, tools, APIs and asynchronous messages. Priority P1: needed to run it reliably in production.

**What to build:** Propagate trace, request and correlation IDs; create spans for model calls, agent hops, tools and dependencies; mask sensitive attributes.

**Suggested AWS services:** OpenTelemetry, AWS X-Ray, CloudWatch Application Signals

**How you know it's done:** One trace shows the complete path and latency breakdown; asynchronous continuations retain correlation; sensitive values are absent.

### HAR-032: Metrics and alerting

The platform must expose operational, model, security and cost health. Priority P1: needed to run it reliably in production.

**What to build:** Measure traffic, errors, latency, throttles, token usage, cost, turns, tool failures, denials, guardrail blocks, queue age and DLQ depth; define SLO-based alarms.

**Suggested AWS services:** CloudWatch Metrics/Alarms/Dashboards, SNS, OpenTelemetry

**How you know it's done:** Dashboards exist per environment; critical alarms are tested; alerts include runbook and correlation information.
