# infra/modules

Reusable Terraform modules, one folder each. A module never hard-codes an account, region, name or
size; everything comes in as a variable.

## What goes in each module

Every module folder has the same three files:

- `main.tf` with the resources.
- `variables.tf` with the inputs, each with a description and a type.
- `outputs.tf` with what other modules need, such as IDs, ARNs and security group IDs.

## The modules

| Folder | What it creates |
|---|---|
| `network/` | The VPC, private subnets, and VPC endpoints for AWS services |
| `ecr/` | One image repository per service |
| `ecs-cluster/` | The ECS cluster and the private service-discovery namespace |
| `ecs-service/` | One ECS service. It's written once and used eight times |
| `alb/` | The public load balancer in front of `master` |
| `iam/` | A task role and an execution role for each service |
| `secrets/` | Secrets Manager entries for the database password and signing keys |
| `storage/` | Where the harness keeps its state (EFS for now, DynamoDB later) |
| `observability/` | CloudWatch log groups and alarms |

## Before you start

Pin provider versions in each module's `versions.tf`. Run `terraform fmt` and `terraform validate`
before committing.
