# infra/modules/storage

Where the harness keeps its state: the audit log, trace spans, sessions, idempotency records,
counters and usage.

## What it should create

For the first version: an encrypted EFS file system mounted at `/data/state` in every task, so all
services share the one SQLite file just as they do in Docker Compose. Turn on EFS backups.

Later: DynamoDB tables (sessions, idempotency, counters, usage), with TTLs for expiry and point-in-time
recovery. Audit records go to S3 with Object Lock.

## How this module helps with the harness

Durable state survives a task restart (HAR-025). The audit log is kept somewhere it can't be quietly
changed (HAR-030), and each kind of data has its own retention setting (HAR-036).

## Before you start

SQLite on EFS is fine while each service runs one task. It doesn't hold up with several tasks
writing at once, so plan the move to DynamoDB before scaling out. The move only touches
`harness/state.py`.

## What the requirements say

Here's the wording from the requirements document, with the AWS services it suggests, so you
can check the work here without opening it.

### HAR-025: State management

Workflow, session and business state must be separated and consistently managed. Priority P1: needed to run it reliably in production.

**What to build:** Store resumable workflow state; use optimistic locking/versioning; define TTLs; never rely on in-memory agent state for durable operations.

**Suggested AWS services:** DynamoDB, Step Functions, ElastiCache only for non-authoritative caching

**How you know it's done:** Restarting an agent does not lose durable workflow state; stale writes are detected; expired temporary state is deleted.

### HAR-030: Audit logging

Security-relevant activity must produce an immutable, queryable audit record. Priority P0: has to be done before going live.

**What to build:** Record actor, agent, action, resource, purpose, authorization decision, tool, timestamp, outcome and correlation ID. Log data access without copying sensitive payloads.

**Suggested AWS services:** CloudTrail, CloudWatch Logs, S3 Object Lock, KMS, Firehose

**How you know it's done:** Auditors can reconstruct who accessed which resource and why; audit retention and tamper-protection meet policy; PHI is minimized.

### HAR-036: Data retention and deletion

Retention periods must be defined separately for prompts, responses, traces, audit events, workflow state and memory. Priority P0: has to be done before going live.

**What to build:** Apply lifecycle policies and legal/compliance requirements; support deletion where allowed; preserve immutable audit data where mandated.

**Suggested AWS services:** S3 lifecycle/Object Lock, DynamoDB TTL, CloudWatch retention, KMS

**How you know it's done:** Each data class has an approved retention rule; expiration and deletion tests succeed; exceptions are documented.
