# infra/modules/ecs-service

One ECS service: a task definition, a service and its security group. All eight services use this
same module with different inputs, so fixes and hardening happen in one place.

## Inputs it should take

- `name`, `image`, `port`, `cpu`, `memory`, `desired_count`.
- `environment`: plain settings such as `HARNESS_ENV=prod` and `HARNESS_ROOT=/app`.
- `secrets`: Secrets Manager ARNs that ECS injects at startup, such as the service's private
  signing key.
- `allowed_from`: security group IDs that may call this service on its port.
- `task_role_arn` and `execution_role_arn` from the `iam` module.
- `efs` mount settings, while the harness state still lives in a shared file.
- `load_balancer`: only used for `master`.

## What it should set on every task

- `readonlyRootFilesystem = true`, a non-root user, and no added Linux capabilities, matching the
  Docker Compose hardening.
- A health check that calls `/health`.
- Logs sent to the service's CloudWatch log group.
- Registration in Cloud Map under the service name.

## How this module helps with the harness

Each service runs with its own IAM role, so one service's credentials can't be used to do another
service's job (HAR-003). Its security group only accepts traffic from the callers listed in
`allowed_from`. That mirrors the caller lists in `config/base/agents.yaml`: master to the agents,
agents to mcp, mcp to the backend (HAR-024). Tasks are spread across two availability zones
(HAR-037).

## What the requirements say

Here's the wording from the requirements document, with the AWS services it suggests, so you
can check the work here without opening it.

### HAR-003: Agent authentication

Every agent and service must have a distinct workload identity for A2A and tool calls. Priority P0: has to be done before going live.

**What to build:** Assign separate IAM roles; use short-lived credentials and signed service calls; prohibit shared long-lived access keys.

**Suggested AWS services:** IAM roles, STS, IAM Roles Anywhere when applicable, SigV4

**How you know it's done:** CloudTrail identifies the calling workload; one agent's credentials cannot invoke unauthorized services; no static AWS key is stored in code.

### HAR-024: Network isolation

Agent, database and internal API traffic must follow least-access network paths. Priority P0: has to be done before going live.

**What to build:** Use private subnets/endpoints where feasible; restrict security groups and egress; deny arbitrary outbound destinations; use TLS and private DNS.

**Suggested AWS services:** VPC, security groups, PrivateLink, VPC endpoints, Route 53 private zones, Network Firewall

**How you know it's done:** Databases have no public endpoint; unapproved outbound connections fail; network-flow tests match the approved architecture.

### HAR-037: High availability and recovery

Critical components must tolerate expected failures and have documented recovery objectives. Priority P1: needed to run it reliably in production.

**What to build:** Deploy across availability zones; remove single points of failure; define RTO/RPO; back up configuration and state; test restoration and regional strategy where required.

**Suggested AWS services:** Multi-AZ AWS services, AWS Backup, Route 53, DynamoDB PITR, S3 versioning

**How you know it's done:** Recovery exercise meets approved RTO/RPO; registry, policies and state can be restored; failure modes are documented.
