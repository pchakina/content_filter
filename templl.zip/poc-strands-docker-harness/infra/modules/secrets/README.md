# infra/modules/secrets

The Secrets Manager entries the services read at startup.

## What it should create

- The database password, read only by `spayer-backend`.
- One private signing key per service (`master`, the five agents, `mcp`, `spayer-backend`), each
  readable only by its own service.
- One entry holding all the public keys, readable by every service.
- A KMS key for encrypting them.

## How this module helps with the harness

No secret is kept in the repo, in an image or in plain task settings. ECS injects each one into
only the service that needs it, and secrets can be rotated without changing any code (HAR-023).

## Before you start

Terraform should create the empty secret entries, never the values. Put the values in once by hand
or from a script, so they never end up in Terraform state.

## What the requirements say

Here's the wording from the requirements document, with the AWS services it suggests, so you
can check the work here without opening it.

### HAR-023: Secrets management

Secrets must not be embedded in source, prompts, environment files committed to Git or agent messages. Priority P0: has to be done before going live.

**What to build:** Store secrets centrally; retrieve at runtime using workload identity; rotate; restrict secret access per service; scan repositories and deployment artifacts.

**Suggested AWS services:** Secrets Manager, Systems Manager Parameter Store, KMS, IAM

**How you know it's done:** Secret scanning finds no committed credentials; rotation works without code change; agents cannot enumerate unrelated secrets.
