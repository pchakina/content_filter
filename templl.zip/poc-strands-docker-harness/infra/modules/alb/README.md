# infra/modules/alb

The public entry point. It sits in front of `master` and nothing else.

## What it should create

- An internet-facing Application Load Balancer in the public subnets.
- An HTTPS listener with an ACM certificate, and an HTTP listener that only redirects to HTTPS.
- A target group for `master` on port 7860, checked with `/health`.
- Optionally, an AWS WAF web ACL with the AWS managed rule sets and a rate-based rule.

## How this module helps with the harness

All outside traffic comes through one managed, TLS-only entry point, and the agents can't be
reached from the internet (HAR-001).

## Before you start

The gateway already limits body size, prompt length and request rate. WAF adds protection at the
edge, so keep both.

## What the requirements say

Here's the wording from the requirements document, with the AWS services it suggests, so you
can check the work here without opening it.

### HAR-001: Entry protection

All external requests must enter through a managed, authenticated endpoint. Agents must not be exposed directly to the internet. Priority P0: has to be done before going live.

**What to build:** Terminate TLS at the edge; reject malformed requests; enforce payload-size, content-type, rate and request-time limits; attach a unique request ID.

**Suggested AWS services:** CloudFront, AWS WAF, API Gateway or ALB, ACM

**How you know it's done:** Direct access to agent runtimes is blocked; TLS is mandatory; invalid or oversized requests are rejected; every accepted request receives a request ID.
