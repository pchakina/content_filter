# infra/modules/iam

The roles each service runs with.

## What it should create

- For each service, an execution role that lets ECS pull the image, write logs and read only that
  service's secrets.
- For each service, a task role with only what that service's code needs:
  - `master`, the three lookup agents and `synthesis-agent` may call `bedrock:InvokeModel`, only on
    the approved model ARNs.
  - `mcp` and `nl2sql-agent` get no AWS permissions.
  - `spayer-backend` may read the database secret.
- A CI deployment role with permission to push to ECR and update these services, and nothing more.

## How this module helps with the harness

Each service has its own short-lived credentials, with no shared access keys (HAR-003). Each one can
only read its own secrets (HAR-023). Bedrock access is limited to the approved models, so even with
a changed setting a service can't call an unapproved one (HAR-033).

## What the requirements say

Here's the wording from the requirements document, with the AWS services it suggests, so you
can check the work here without opening it.

### HAR-003: Agent authentication

Every agent and service must have a distinct workload identity for A2A and tool calls. Priority P0: has to be done before going live.

**What to build:** Assign separate IAM roles; use short-lived credentials and signed service calls; prohibit shared long-lived access keys.

**Suggested AWS services:** IAM roles, STS, IAM Roles Anywhere when applicable, SigV4

**How you know it's done:** CloudTrail identifies the calling workload; one agent's credentials cannot invoke unauthorized services; no static AWS key is stored in code.

### HAR-023: Secrets management

Secrets must not be embedded in source, prompts, environment files committed to Git or agent messages. Priority P0: has to be done before going live.

**What to build:** Store secrets centrally; retrieve at runtime using workload identity; rotate; restrict secret access per service; scan repositories and deployment artifacts.

**Suggested AWS services:** Secrets Manager, Systems Manager Parameter Store, KMS, IAM

**How you know it's done:** Secret scanning finds no committed credentials; rotation works without code change; agents cannot enumerate unrelated secrets.

### HAR-033: Model governance

Models and inference parameters must be explicitly approved and version-controlled. Priority P0: has to be done before going live.

**What to build:** Maintain allowlisted model IDs, regions, use cases, parameters and fallback order; test before upgrade; prevent agents from choosing arbitrary models.

**Suggested AWS services:** Amazon Bedrock, AppConfig, IaC

**How you know it's done:** Unapproved models cannot be invoked; model changes pass evaluation gates and are visible in deployment history.
