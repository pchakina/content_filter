# infra/modules/ecs-cluster

The ECS cluster and the private DNS namespace the services use to find each other.

## What it should create

- An ECS cluster using Fargate, with Container Insights turned on.
- A Cloud Map private DNS namespace, for example `spayer.local`.

## How this module helps with the harness

Services find each other through fixed names in a private namespace that the registry config
points to. They never use an address taken from a user or a model (HAR-008).

## What the requirements say

Here's the wording from the requirements document, with the AWS services it suggests, so you
can check the work here without opening it.

### HAR-008: Capability discovery

The orchestrator must select agents using trusted capability metadata rather than arbitrary model-generated URLs. Priority P0: has to be done before going live.

**What to build:** Resolve requested capability against the registry; allowlist permitted caller-to-agent routes; validate protocol and schema versions before dispatch.

**Suggested AWS services:** Agent registry, AppConfig, Step Functions when workflow-driven

**How you know it's done:** The model cannot call a URL supplied in user content; unsupported capabilities return a controlled error; route tests are deterministic.
