# infra/modules/network

The VPC the whole system runs in.

## What it should create

- A VPC with private subnets in at least two availability zones, plus public subnets used only by
  the load balancer.
- VPC endpoints, so tasks reach AWS services without going over the internet: Bedrock runtime,
  ECR (api and dkr), S3 (for ECR layers), Secrets Manager, CloudWatch Logs and STS.
- No NAT gateway if the endpoints cover everything. If one is needed, restrict where traffic can
  go with Network Firewall or tight security groups.

## How this module helps with the harness

Services sit in private subnets with no public address, and their outbound traffic is limited to
the AWS services they actually need (HAR-024).

## Outputs other modules need

`vpc_id`, `private_subnet_ids`, `public_subnet_ids`, and the endpoint security group ID.

## What the requirements say

Here's the wording from the requirements document, with the AWS services it suggests, so you
can check the work here without opening it.

### HAR-024: Network isolation

Agent, database and internal API traffic must follow least-access network paths. Priority P0: has to be done before going live.

**What to build:** Use private subnets/endpoints where feasible; restrict security groups and egress; deny arbitrary outbound destinations; use TLS and private DNS.

**Suggested AWS services:** VPC, security groups, PrivateLink, VPC endpoints, Route 53 private zones, Network Firewall

**How you know it's done:** Databases have no public endpoint; unapproved outbound connections fail; network-flow tests match the approved architecture.
