# infra

Everything needed to run this system on AWS ECS, written in Terraform and driven by Terragrunt. The
application code lives in the other folders; this folder only describes the AWS resources it runs
on.

## How it's laid out

- `modules/` holds plain Terraform modules. They take inputs and create resources, and they contain
  no environment-specific values.
- `live/` holds the Terragrunt configuration for each environment (`dev`, `prod`). Each folder there
  calls one module and fills in its inputs.

Keep the two apart. A change to a module affects every environment that uses it. A change under
`live/dev` affects only dev.

## How this folder helps with the harness

Infrastructure is code, reviewed and versioned like the rest of the repo, with a separate setup for
each environment and no hand-made changes in the console (HAR-038). Images come from ECR with
scanning turned on, and deployments run through a pipeline rather than from someone's laptop
(HAR-039).

## Before you start

- You need Terraform 1.6 or later, Terragrunt, and AWS credentials for the target account.
- Remote state goes in an S3 bucket with a DynamoDB lock table. Create those once per account
  before the first `terragrunt run-all plan`.
- Add `infra/` to `.dockerignore` when that file is added, so Terraform files never end up in an
  image.
- Keep `live/<env>` in step with `config/environments/<env>.yaml`. The service addresses in that
  file have to match the Cloud Map names this folder creates (for example
  `practitioner-agent.spayer.local:8001`).

## What the requirements say

Here's the wording from the requirements document, with the AWS services it suggests, so you
can check the work here without opening it.

### HAR-038: Configuration management

Environment-specific agent, model, routing, policy and limit configuration must be externalized and versioned. Priority P1: needed to run it reliably in production.

**What to build:** Separate dev/test/prod; validate configuration schema; use controlled promotion; prohibit manual production drift.

**Suggested AWS services:** AppConfig, Parameter Store, Terraform/Terragrunt, CI/CD

**How you know it's done:** Configuration changes are reviewed, auditable and reversible; invalid configuration cannot deploy; drift is detected.

### HAR-039: Deployment security

Builds and deployments must be reproducible, scanned and approved. Priority P1: needed to run it reliably in production.

**What to build:** Pin dependencies; generate an SBOM; scan code, containers and IaC; sign artifacts; use least-privilege CI roles; require environment gates.

**Suggested AWS services:** CodePipeline/GitHub Actions, CodeBuild, ECR scanning, Inspector, Signer, Terraform/Terragrunt

**How you know it's done:** Critical vulnerabilities block deployment; artifacts are traceable to commit; production deployments require approved gates.
