# evals

The evaluation run. It sends a set of scored questions through the whole system and fails if any
category scores below its pass mark.

## What goes in here

- `cases.jsonl`, the questions and what each one should produce.
- `thresholds.yaml`, the pass mark for each category. The safety categories must score 100%.
- `run.py`, which runs the cases. Set `HARNESS_EVAL_ENV=local` to use Bedrock instead of the scripted
  model.
- `results/`, where each run writes its report. This folder isn't kept in Git.

## How this folder helps with the harness

It measures routing, tool choice, SQL safety, grounding, refusals, PHI leaks and resistance to
injected instructions, and CI blocks a change that falls below the pass marks (HAR-034).

## Before you start

With the scripted model, the run only tells you the harness works. Run it against Bedrock before a
release to see how the real model does.

There's a finished, tested version of this folder in `poc-strands-docker-harness-full/evals/`, next to this repo. Copy from it rather than starting from scratch. [HARNESS_GUIDE.md](../HARNESS_GUIDE.md) has the full folder map and the order to add things in.

## What the requirements say

Here's the wording from the requirements document, so you can check the work in this folder
without having to open it.

### HAR-034: Evaluation

Agent quality and safety must be measured before release and continuously after changes. Priority P0: has to be done before going live.

**What to build:** Build datasets for routing, tool selection, parameter accuracy, SQL correctness, groundedness, refusal, PHI leakage and injection resistance; set pass thresholds.

**How you know it's done:** CI blocks releases below thresholds; results are reproducible and versioned by prompt, model, agent and tool version.
